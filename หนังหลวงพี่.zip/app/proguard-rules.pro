
-optimizations !code/simplification/arithmetic,!field/*,!class/merging/*
-allowaccessmodification
-repackageclasses ''


-dontpreverify
-dontwarn okhttp3.**
-dontwarn org.jsoup.**
-dontwarn javax.annotation.**
-dontwarn kotlin.**


-keep class com.example.animeapp.activities.** { *; }


-keep class com.example.animeapp.models.** { *; }


-keep class com.example.animeapp.parser.NativeParseBridge { *; }


-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}


-keep public class * extends com.bumptech.glide.module.AppGlideModule
-keep class com.bumptech.glide.GeneratedAppGlideModuleImpl


-dontwarn androidx.media3.**


-keep class com.google.android.gms.cast.framework.** { *; }


-keep class androidx.work.** { *; }
-dontwarn androidx.work.**


-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
    public static *** w(...);
}
