#include "native_common.h"
#include <cstdint>
#include <sstream>

namespace {
std::vector<uint16_t> utf8_to_utf16(const std::string& input) {
    std::vector<uint16_t> out;
    for (size_t i = 0; i < input.size();) {
        uint32_t cp = static_cast<unsigned char>(input[i++]);
        if ((cp & 0x80) == 0) {
        } else if ((cp & 0xE0) == 0xC0 && i < input.size()) {
            cp = ((cp & 0x1F) << 6) | (static_cast<unsigned char>(input[i++]) & 0x3F);
        } else if ((cp & 0xF0) == 0xE0 && i + 1 < input.size()) {
            const uint32_t c1 = static_cast<unsigned char>(input[i++]) & 0x3F;
            const uint32_t c2 = static_cast<unsigned char>(input[i++]) & 0x3F;
            cp = ((cp & 0x0F) << 12) | (c1 << 6) | c2;
        } else if ((cp & 0xF8) == 0xF0 && i + 2 < input.size()) {
            const uint32_t c1 = static_cast<unsigned char>(input[i++]) & 0x3F;
            const uint32_t c2 = static_cast<unsigned char>(input[i++]) & 0x3F;
            const uint32_t c3 = static_cast<unsigned char>(input[i++]) & 0x3F;
            cp = ((cp & 0x07) << 18) | (c1 << 12) | (c2 << 6) | c3;
        } else {
            cp = 0xFFFD;
        }
        if (cp <= 0xFFFF) out.push_back(static_cast<uint16_t>(cp));
        else {
            cp -= 0x10000;
            out.push_back(static_cast<uint16_t>(0xD800 + (cp >> 10)));
            out.push_back(static_cast<uint16_t>(0xDC00 + (cp & 0x3FF)));
        }
    }
    return out;
}
std::string utf16_to_utf8(const jchar* data, jsize length) {
    std::string out;
    for (jsize i = 0; i < length; ++i) {
        uint32_t cp = data[i];
        if (cp >= 0xD800 && cp <= 0xDBFF && i + 1 < length) {
            uint32_t low = data[i + 1];
            if (low >= 0xDC00 && low <= 0xDFFF) { cp = 0x10000 + ((cp - 0xD800) << 10) + (low - 0xDC00); ++i; }
        }
        if (cp <= 0x7F) out.push_back(static_cast<char>(cp));
        else if (cp <= 0x7FF) {
            out.push_back(static_cast<char>(0xC0 | (cp >> 6)));
            out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
        } else if (cp <= 0xFFFF) {
            out.push_back(static_cast<char>(0xE0 | (cp >> 12)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
        } else {
            out.push_back(static_cast<char>(0xF0 | (cp >> 18)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 12) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
        }
    }
    return out;
}
jstring make_java_string(JNIEnv* env, const std::string& value) {
    const auto chars = utf8_to_utf16(value);
    return env->NewString(reinterpret_cast<const jchar*>(chars.data()), static_cast<jsize>(chars.size()));
}
jmethodID method(JNIEnv* env, jobject obj, const char* name, const char* signature) {
    if (!obj) return nullptr;
    jclass cls = env->GetObjectClass(obj);
    if (!cls) return nullptr;
    jmethodID id = env->GetMethodID(cls, name, signature);
    env->DeleteLocalRef(cls);
    return id;
}
std::string object_string(JNIEnv* env, jobject object) {
    if (!object) return {};
    jstring value = static_cast<jstring>(object);
    const jsize length = env->GetStringLength(value);
    const jchar* chars = env->GetStringChars(value, nullptr);
    if (!chars) return {};
    std::string out = utf16_to_utf8(chars, length);
    env->ReleaseStringChars(value, chars);
    env->DeleteLocalRef(value);
    return out;
}
void clear_exception(JNIEnv* env) {
    if (env->ExceptionCheck()) env->ExceptionClear();
}
}

namespace anime_native {
std::string from_jstring(JNIEnv* env, jstring value) { return object_string(env, value); }
jstring to_jstring(JNIEnv* env, const std::string& value) { return make_java_string(env, value); }
std::string text(JNIEnv* env, jobject element) {
    if (!element) return {};
    jmethodID id = method(env, element, "text", "()Ljava/lang/String;");
    if (!id) { clear_exception(env); return {}; }
    jobject result = env->CallObjectMethod(element, id);
    if (env->ExceptionCheck()) { clear_exception(env); return {}; }
    return object_string(env, result);
}
std::string own_text(JNIEnv* env, jobject element) {
    if (!element) return {};
    jmethodID id = method(env, element, "ownText", "()Ljava/lang/String;");
    if (!id) { clear_exception(env); return {}; }
    jobject result = env->CallObjectMethod(element, id);
    if (env->ExceptionCheck()) { clear_exception(env); return {}; }
    return object_string(env, result);
}
std::string attr(JNIEnv* env, jobject element, const char* name) {
    if (!element) return {};
    jmethodID id = method(env, element, "attr", "(Ljava/lang/String;)Ljava/lang/String;");
    if (!id) { clear_exception(env); return {}; }
    jstring key = make_java_string(env, name);
    jobject result = env->CallObjectMethod(element, id, key);
    env->DeleteLocalRef(key);
    if (env->ExceptionCheck()) { clear_exception(env); return {}; }
    return object_string(env, result);
}
std::string abs_url(JNIEnv* env, jobject element, const char* name) {
    if (!element) return {};
    jmethodID id = method(env, element, "absUrl", "(Ljava/lang/String;)Ljava/lang/String;");
    if (!id) { clear_exception(env); return {}; }
    jstring key = make_java_string(env, name);
    jobject result = env->CallObjectMethod(element, id, key);
    env->DeleteLocalRef(key);
    if (env->ExceptionCheck()) { clear_exception(env); return {}; }
    return object_string(env, result);
}
bool has_attr(JNIEnv* env, jobject element, const char* name) {
    if (!element) return false;
    jmethodID id = method(env, element, "hasAttr", "(Ljava/lang/String;)Z");
    if (!id) { clear_exception(env); return false; }
    jstring key = make_java_string(env, name);
    jboolean result = env->CallBooleanMethod(element, id, key);
    env->DeleteLocalRef(key);
    if (env->ExceptionCheck()) { clear_exception(env); return false; }
    return result == JNI_TRUE;
}
jobject select_first(JNIEnv* env, jobject node, const char* css) {
    if (!node) return nullptr;
    jmethodID id = method(env, node, "selectFirst", "(Ljava/lang/String;)Lorg/jsoup/nodes/Element;");
    if (!id) { clear_exception(env); return nullptr; }
    jstring selector = make_java_string(env, css);
    jobject result = env->CallObjectMethod(node, id, selector);
    env->DeleteLocalRef(selector);
    if (env->ExceptionCheck()) { clear_exception(env); return nullptr; }
    return result;
}
std::vector<jobject> select(JNIEnv* env, jobject node, const char* css) {
    std::vector<jobject> result;
    if (!node) return result;
    jmethodID select_id = method(env, node, "select", "(Ljava/lang/String;)Lorg/jsoup/select/Elements;");
    if (!select_id) { clear_exception(env); return result; }
    jstring selector = make_java_string(env, css);
    jobject elements = env->CallObjectMethod(node, select_id, selector);
    env->DeleteLocalRef(selector);
    if (env->ExceptionCheck() || !elements) { clear_exception(env); return result; }
    jmethodID size_id = method(env, elements, "size", "()I");
    jmethodID get_id = method(env, elements, "get", "(I)Ljava/lang/Object;");
    if (!size_id || !get_id) { clear_exception(env); env->DeleteLocalRef(elements); return result; }
    jint size = env->CallIntMethod(elements, size_id);
    for (jint i = 0; i < size && !env->ExceptionCheck(); ++i) {
        jobject item = env->CallObjectMethod(elements, get_id, i);
        if (item) result.push_back(item);
    }
    if (env->ExceptionCheck()) clear_exception(env);
    env->DeleteLocalRef(elements);
    return result;
}
std::string base_uri(JNIEnv* env, jobject document) {
    if (!document) return {};
    jmethodID id = method(env, document, "baseUri", "()Ljava/lang/String;");
    if (!id) { clear_exception(env); return {}; }
    jobject result = env->CallObjectMethod(document, id);
    if (env->ExceptionCheck()) { clear_exception(env); return {}; }
    return object_string(env, result);
}
std::string json_quote(const std::string& value) {
    std::string out = "\"";
    static const char hex[] = "0123456789abcdef";
    for (unsigned char c : value) {
        switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\b': out += "\\b"; break;
            case '\f': out += "\\f"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (c < 0x20) { out += "\\u00"; out += hex[c >> 4]; out += hex[c & 15]; }
                else out.push_back(static_cast<char>(c));
        }
    }
    out.push_back('"');
    return out;
}
std::string json_array(const std::vector<std::string>& items) {
    std::string out = "[";
    for (size_t i = 0; i < items.size(); ++i) { if (i) out.push_back(','); out += items[i]; }
    out.push_back(']');
    return out;
}
std::string json_object(const std::vector<std::pair<std::string, std::string>>& fields) {
    std::string out = "{";
    for (size_t i = 0; i < fields.size(); ++i) {
        if (i) out.push_back(',');
        out += json_quote(fields[i].first); out.push_back(':'); out += fields[i].second;
    }
    out.push_back('}');
    return out;
}
std::string json_number(int value) { return std::to_string(value); }
std::string json_bool(bool value) { return value ? "true" : "false"; }
std::string dispatch(JNIEnv* env, const std::string& source, jobject doc, int operation,
                     const std::string& referer, int episode_number) {
    if (source == "animemoji") return parse_animemoji(env, doc, operation, referer, episode_number);
    if (source == "fixmono") return parse_fixmono(env, doc, operation, referer, episode_number);
    if (source == "goseries4k") return parse_goseries4k(env, doc, operation, referer, episode_number);
    if (source == "hdd1112") return parse_hdd1112(env, doc, operation, referer, episode_number);
    if (source == "movie24hd") return parse_movie24hd(env, doc, operation, referer, episode_number);
    if (source == "hdmedia") return parse_hdmedia(env, doc, operation, referer, episode_number);
    if (source == "movie123") return parse_movie123(env, doc, operation, referer, episode_number);
    if (source == "seriesday") return parse_seriesday(env, doc, operation, referer, episode_number);
    if (source == "watchlakorn") return parse_watchlakorn(env, doc, operation, referer, episode_number);
    if (source == "wowdrama") return parse_wowdrama(env, doc, operation, referer, episode_number);
    return operation == 2 ? "[]" : (operation == 3 ? "{\"url\":\"\"}" : "{\"title\":\"\",\"url\":\"\",\"imageUrl\":\"\",\"episodes\":[],\"animeItems\":[],\"pageItems\":[]}");
}
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_animeapp_parser_NativeParseBridge_nativeParse(
        JNIEnv* env, jclass, jstring source_value, jint operation, jobject document,
        jstring referer_value, jint episode_number) {
    using namespace anime_native;
    const std::string source = from_jstring(env, source_value);
    const std::string referer = from_jstring(env, referer_value);
    if (!document) return to_jstring(env, "{}");
    std::string output;
    try { output = dispatch(env, source, document, operation, referer, episode_number); }
    catch (...) { output = operation == 2 ? "[]" : (operation == 3 ? "{\"url\":\"\"}" : "{}"); }
    return to_jstring(env, output);
}
