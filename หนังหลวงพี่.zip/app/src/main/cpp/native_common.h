#pragma once
#include <jni.h>
#include <string>
#include <utility>
#include <vector>

namespace anime_native {
std::string from_jstring(JNIEnv* env, jstring value);
jstring to_jstring(JNIEnv* env, const std::string& value);
std::string text(JNIEnv* env, jobject element);
std::string own_text(JNIEnv* env, jobject element);
std::string attr(JNIEnv* env, jobject element, const char* name);
std::string abs_url(JNIEnv* env, jobject element, const char* name);
bool has_attr(JNIEnv* env, jobject element, const char* name);
jobject select_first(JNIEnv* env, jobject node, const char* css);
std::vector<jobject> select(JNIEnv* env, jobject node, const char* css);
std::string base_uri(JNIEnv* env, jobject document);
std::string json_quote(const std::string& value);
inline std::string json_string(const std::string& value) { return json_quote(value); }
std::string json_array(const std::vector<std::string>& raw_json_items);
std::string json_object(const std::vector<std::pair<std::string, std::string>>& key_raw_json_value);
std::string json_number(int value);
std::string json_bool(bool value);
std::string dispatch(JNIEnv* env, const std::string& source, jobject document, int operation,
                     const std::string& referer, int episode_number);
}
using namespace anime_native;

std::string parse_animemoji(JNIEnv*, jobject, int, const std::string&, int);
std::string parse_fixmono(JNIEnv*, jobject, int, const std::string&, int);
std::string parse_goseries4k(JNIEnv*, jobject, int, const std::string&, int);
std::string parse_hdd1112(JNIEnv*, jobject, int, const std::string&, int);
std::string parse_movie24hd(JNIEnv*, jobject, int, const std::string&, int);
std::string parse_hdmedia(JNIEnv*, jobject, int, const std::string&, int);
std::string parse_movie123(JNIEnv*, jobject, int, const std::string&, int);
std::string parse_seriesday(JNIEnv*, jobject, int, const std::string&, int);
std::string parse_watchlakorn(JNIEnv*, jobject, int, const std::string&, int);
std::string parse_wowdrama(JNIEnv*, jobject, int, const std::string&, int);
