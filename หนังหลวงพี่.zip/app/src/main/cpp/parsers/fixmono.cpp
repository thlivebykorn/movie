#include "../native_common.h"

#include <cctype>
#include <regex>
#include <string>
#include <vector>

namespace {
using anime_native::json_array;
using anime_native::json_bool;
using anime_native::json_number;
using anime_native::json_object;
using anime_native::json_string;
using anime_native::select;
using anime_native::select_first;
using anime_native::text;
using anime_native::attr;
using anime_native::abs_url;
using anime_native::has_attr;
using anime_native::base_uri;

std::string episode_json(const std::string& title, const std::string& info_url,
                         const std::string& image_url, const std::string& video_url,
                         const std::string& referer, int number, const std::string& data_id) {
    return json_object({
        {"title", json_string(title)}, {"infoUrl", json_string(info_url)},
        {"imageUrl", json_string(image_url)}, {"videoUrl", json_string(video_url)},
        {"referer", json_string(referer)}, {"episodeNumber", json_number(number)},
        {"dataId", json_string(data_id)}
    });
}

std::vector<std::string> extract_episodes(JNIEnv* env, jobject doc, const std::string& referer,
                                          const std::string& image_url) {
    std::vector<std::string> result;
    // Preserve the Java selector and document order: episode spans first, then mp buttons.
    const auto elements = select(env, doc, "span.episode[episode-id], .mp-ep-btn[data-id]");
    int number = 0;
    for (jobject element : elements) {
        ++number;
        std::string id = attr(env, element, "episode-id");
        if (id.empty()) id = attr(env, element, "data-id");
        const std::string fake_url = referer + "?episode-id=" + id;
        result.push_back(episode_json("ตอนที่ " + std::to_string(number), fake_url,
                                      image_url, "", referer, number, ""));
        if (element) env->DeleteLocalRef(element);
    }
    return result;
}

bool numeric(const std::string& s) {
    if (s.empty()) return false;
    for (unsigned char c : s) if (!std::isdigit(c)) return false;
    return true;
}

std::string direct_video_url(const std::string& value) {
    static const std::regex pattern(R"((https?://[^\s"']+\.(?:m3u8|mp4|mkv|webm)))", std::regex::icase);
    for (std::sregex_iterator it(value.begin(), value.end(), pattern), end; it != end; ++it) {
        const std::string url = (*it)[1].str();
        if (url.find("localhost") == std::string::npos && url.find("127.0.0.1") == std::string::npos)
            return url;
    }
    return "";
}

std::string script_video_url(JNIEnv* env, jobject doc) {
    static const std::regex json_pattern(R"rx("(?:file|url|src)"\s*:\s*"([^"]+\.(?:m3u8|mp4))")rx", std::regex::icase);
    static const std::regex js_pattern(R"rx((?:videoSources|sources|jwplayer\().*?file.*?"(https?:\\/\\/[^"]+)")rx", std::regex::icase | std::regex::ECMAScript);
    const auto scripts = select(env, doc, "script");
    for (jobject script : scripts) {
        const std::string contents = text(env, script);
        std::smatch match;
        if (std::regex_search(contents, match, json_pattern)) {
            std::string url = match[1].str();
            size_t pos = 0;
            while ((pos = url.find("\\/", pos)) != std::string::npos) url.replace(pos, 2, "/");
            if (script) env->DeleteLocalRef(script);
            return url;
        }
        if (std::regex_search(contents, match, js_pattern)) {
            std::string url = match[1].str();
            size_t pos = 0;
            while ((pos = url.find("\\/", pos)) != std::string::npos) url.replace(pos, 2, "/");
            if (script) env->DeleteLocalRef(script);
            return url;
        }
        if (script) env->DeleteLocalRef(script);
    }
    return "";
}

std::string make_episode_array(JNIEnv* env, jobject doc, const std::string& ref, const std::string& image) {
    return json_array(extract_episodes(env, doc, ref, image));
}
}

std::string parse_fixmono(JNIEnv* env, jobject doc, int operation,
                          const std::string& referer, int episode_number) {
    (void)episode_number;
    try {
        if (!doc) {
            if (operation == 2) return "[]";
            if (operation == 3) return json_object({{"url", json_string("")}});
            if (operation == 4) return json_object({{"animeItems", "[]"}, {"pageItems", "[]"}});
            return json_object({{"title", json_string("")}, {"url", json_string("")},
                                {"imageUrl", json_string("")}, {"episodes", "[]"}});
        }

        const std::string doc_url = base_uri(env, doc);
        const std::string effective_referer = doc_url.empty() ? referer : doc_url;

        if (operation == 1) {
            jobject title_meta = select_first(env, doc, "meta[property=og:title]");
            jobject image_meta = select_first(env, doc, "meta[property=og:image]");
            std::string title = title_meta ? attr(env, title_meta, "content") : "";
            std::string image = image_meta ? attr(env, image_meta, "content") : "";
            // Java removes each [, ], ., and : then trims surrounding whitespace.
            title.erase(std::remove_if(title.begin(), title.end(), [](char c) {
                return c == '[' || c == ']' || c == '.' || c == ':';
            }), title.end());
            const auto first = title.find_first_not_of(" \t\r\n");
            if (first == std::string::npos) title.clear();
            else title = title.substr(first, title.find_last_not_of(" \t\r\n") - first + 1);
            if (title_meta) env->DeleteLocalRef(title_meta);
            if (image_meta) env->DeleteLocalRef(image_meta);
            return json_object({{"title", json_string(title)}, {"url", json_string(doc_url)},
                                {"imageUrl", json_string(image)},
                                {"episodes", make_episode_array(env, doc, effective_referer, image)}});
        }

        if (operation == 2)
            return make_episode_array(env, doc, effective_referer, "");

        if (operation == 3) {
            std::string url = "";
            // Java first requests admin-ajax.php (action=mix_get_player, post_id=episode-id),
            // then makes network requests for backup servers/iframes and resolves stream tokens.
            // These requests must remain in Java; the supplied document alone cannot provide
            // their responses. Only extract a URL already present in supplied HTML here.
            const std::string doc_text = text(env, doc);
            url = direct_video_url(doc_text);
            if (url.empty()) url = script_video_url(env, doc);
            if (url.empty()) {
                jobject iframe = select_first(env, doc, "iframe[src]");
                if (iframe) {
                    const std::string src = attr(env, iframe, "src");
                    if (src.rfind("//", 0) == 0) url = "https:" + src;
                    else if (src.find("http://") == 0 || src.find("https://") == 0) url = src;
                    else url = abs_url(env, iframe, "src");
                    env->DeleteLocalRef(iframe);
                }
            }
            // TODO(network): implement AJAX action mix_get_player and resolver requests in Java;
            // native operation receives only the episode HTML and must not call the network.
            return json_object({{"url", json_string(url)}});
        }

        if (operation == 4) {
            std::vector<std::string> anime_items;
            const auto articles = select(env, doc, "article");
            for (jobject article : articles) {
                jobject link = select_first(env, article, "a[rel=bookmark]");
                if (link) {
                    const std::string title = attr(env, link, "title");
                    const std::string url = attr(env, link, "href");
                    jobject img = select_first(env, link, "img.wp-post-image");
                    std::string image;
                    if (img) {
                        if (has_attr(env, img, "data-src")) image = abs_url(env, img, "data-src");
                        else if (has_attr(env, img, "src")) image = abs_url(env, img, "src");
                        env->DeleteLocalRef(img);
                    }
                    jobject dub = select_first(env, article, "span.lang-22-color");
                    const std::string dub_text = dub ? text(env, dub) : "";
                    if (!title.empty() && !url.empty()) {
                        anime_items.push_back(json_object({{"title", json_string(title)},
                            {"url", json_string(url)}, {"imageUrl", json_string(image)},
                            {"dubText", json_string(dub_text)}, {"latestEpisode", json_string("")}}));
                    }
                    if (dub) env->DeleteLocalRef(dub);
                    env->DeleteLocalRef(link);
                }
                if (article) env->DeleteLocalRef(article);
            }

            std::vector<std::string> page_items;
            const auto links = select(env, doc, "div.pagination a.page-link:not(.dots)");
            for (jobject link : links) {
                std::string number = text(env, link);
                const auto first = number.find_first_not_of(" \t\r\n");
                if (first == std::string::npos) number.clear();
                else number = number.substr(first, number.find_last_not_of(" \t\r\n") - first + 1);
                const std::string url = attr(env, link, "href");
                if (numeric(number) && !url.empty())
                    page_items.push_back(json_object({{"pageNumber", json_string(number)},
                        {"url", json_string(url)}, {"isCurrent", json_bool(false)}}));
                if (link) env->DeleteLocalRef(link);
            }
            jobject active = select_first(env, doc, "div.pagination li.active a.page-link");
            if (!active) active = select_first(env, doc, "div.pagination .page-item.active .page-link");
            if (active) {
                std::string number = text(env, active);
                const auto first = number.find_first_not_of(" \t\r\n");
                if (first == std::string::npos) number.clear();
                else number = number.substr(first, number.find_last_not_of(" \t\r\n") - first + 1);
                if (numeric(number)) page_items.push_back(json_object({{"pageNumber", json_string(number)},
                    {"url", json_string(attr(env, active, "href"))}, {"isCurrent", json_bool(true)}}));
                env->DeleteLocalRef(active);
            }
            return json_object({{"animeItems", json_array(anime_items)}, {"pageItems", json_array(page_items)}});
        }
    } catch (...) {
        // Never allow a C++ exception to cross the JNI boundary.
    }
    if (operation == 2) return "[]";
    if (operation == 3) return json_object({{"url", json_string("")}});
    if (operation == 4) return json_object({{"animeItems", "[]"}, {"pageItems", "[]"}});
    return json_object({{"title", json_string("")}, {"url", json_string("")},
                        {"imageUrl", json_string("")}, {"episodes", "[]"}});
}
