#include "../native_common.h"

#include <regex>
#include <string>
#include <vector>

namespace {
using anime_native::abs_url;
using anime_native::attr;
using anime_native::base_uri;
using anime_native::has_attr;
using anime_native::json_array;
using anime_native::json_bool;
using anime_native::json_number;
using anime_native::json_object;
using anime_native::json_string;
using anime_native::select;
using anime_native::select_first;
using anime_native::text;

std::string episode_json(const std::string& title, const std::string& info_url,
                         const std::string& image, const std::string& video,
                         const std::string& referer, int number) {
    return json_object({{"title", json_string(title)}, {"infoUrl", json_string(info_url)},
                        {"imageUrl", json_string(image)}, {"videoUrl", json_string(video)},
                        {"referer", json_string(referer)}, {"episodeNumber", json_number(number)},
                        {"dataId", json_string("")}});
}

std::string item_json(const std::string& title, const std::string& url,
                      const std::string& image, const std::string& dub) {
    return json_object({{"title", json_string(title)}, {"url", json_string(url)},
                        {"imageUrl", json_string(image)}, {"dubText", json_string(dub)},
                        {"latestEpisode", json_string("")}});
}

std::string page_json(const std::string& number, const std::string& url) {
    return json_object({{"pageNumber", json_string(number)}, {"url", json_string(url)},
                        {"isCurrent", json_bool(false)}});
}

std::string empty_detail() {
    return json_object({{"title", json_string("")}, {"url", json_string("")},
                        {"imageUrl", json_string("")}, {"episodes", json_array({})}});
}

std::string document_html(JNIEnv* env, jobject doc) {
    if (!doc) return "";
    jclass cls = env->GetObjectClass(doc);
    if (!cls) return "";
    jmethodID mid = env->GetMethodID(cls, "html", "()Ljava/lang/String;");
    std::string result;
    if (mid) {
        jstring value = static_cast<jstring>(env->CallObjectMethod(doc, mid));
        if (value) {
            result = anime_native::from_jstring(env, value);
            env->DeleteLocalRef(value);
        }
    }
    env->DeleteLocalRef(cls);
    if (env->ExceptionCheck()) env->ExceptionClear();
    return result;
}

std::string unescape_slashes(std::string value) {
    std::size_t pos = 0;
    while ((pos = value.find("\\/", pos)) != std::string::npos) value.replace(pos, 2, "/");
    return value;
}

std::string video_from_html(const std::string& html) {
    std::smatch match;
    const std::regex direct(R"((https?:\/\/[^\s"']+\.(?:m3u8|mp4|mkv|webm)))", std::regex::icase);
    for (auto it = std::sregex_iterator(html.begin(), html.end(), direct); it != std::sregex_iterator(); ++it) {
        std::string candidate = (*it)[1].str();
        if (candidate.find("localhost") == std::string::npos && candidate.find("127.0.0.1") == std::string::npos)
            return candidate;
    }
    const std::regex jw(R"rx(sources:\s*\[\s*\{\s*file:\s*"([^"]+\.m3u8)")rx", std::regex::icase);
    if (std::regex_search(html, match, jw)) return unescape_slashes(match[1].str());
    const std::regex jw_json(R"rx("sources"\s*:\s*\[\s*\{\s*"file"\s*:\s*"([^"]+\.m3u8)")rx", std::regex::icase);
    if (std::regex_search(html, match, jw_json)) return unescape_slashes(match[1].str());
    const std::regex json_url(R"rx("(?:file|url|src)"\s*:\s*"([^"]+\.(?:m3u8|mp4))")rx", std::regex::icase);
    if (std::regex_search(html, match, json_url)) return unescape_slashes(match[1].str());
    const std::regex js_url(R"rx((?:videoSources|sources|jwplayer\()[\s\S]*?file[\s\S]*?"(https?:\\/\\/[^"]+)")rx", std::regex::icase | std::regex::ECMAScript);
    if (std::regex_search(html, match, js_url)) return unescape_slashes(match[1].str());

    // HTML may only contain an iframe/embed reference; resolving it requires HTTP.
    return "";
}

std::vector<std::string> parse_episodes(JNIEnv* env, jobject doc, const std::string& image) {
    std::vector<std::string> episodes;
    const std::string page_url = base_uri(env, doc);
    const auto elements = select(env, doc, "div.miru-ep-btn[data-ep-id], span.episode[episode-id], .mp-ep-btn[data-id]");
    for (std::size_t i = 0; i < elements.size(); ++i) {
        jobject ep = elements[i];
        std::string id = attr(env, ep, "data-ep-id");
        if (id.empty()) id = attr(env, ep, "episode-id");
        if (id.empty()) id = attr(env, ep, "data-id");
        if (id.empty()) { if (ep) env->DeleteLocalRef(ep); continue; }
        std::string ep_title = attr(env, ep, "title");
        if (ep_title.empty()) {
            jobject title_node = select_first(env, ep, ".miru-ep-title");
            if (title_node) {
                ep_title = text(env, title_node);
                env->DeleteLocalRef(title_node);
            }
        }
        if (ep_title.empty()) ep_title = "ตอนที่ " + std::to_string(i + 1);
        episodes.push_back(episode_json(ep_title, page_url + "?episode-id=" + id, image, "", page_url, static_cast<int>(i + 1)));
        if (ep) env->DeleteLocalRef(ep);
    }
    return episodes;
}
}

std::string parse_wowdrama(JNIEnv* env, jobject doc, int operation,
                           const std::string& referer, int episode_number) {
    (void)episode_number;
    try {
        if (!doc) {
            if (operation == 4) return json_object({{"animeItems", json_array({})}, {"pageItems", json_array({})}});
            if (operation == 3) return json_object({{"url", json_string("")}});
            if (operation == 2) return json_array({});
            return empty_detail();
        }
        const std::string page_url = base_uri(env, doc);
        if (operation == 2) return json_array(parse_episodes(env, doc, referer));
        if (operation == 1) {
            jobject node = select_first(env, doc, "meta[property=og:title]");
            std::string title = node ? attr(env, node, "content") : "";
            if (node) env->DeleteLocalRef(node);
            title = std::regex_replace(title, std::regex(R"([\[\].:])"), "");
            // Java trim() behavior for ordinary ASCII whitespace.
            const auto first = title.find_first_not_of(" \t\r\n");
            title = first == std::string::npos ? "" : title.substr(first, title.find_last_not_of(" \t\r\n") - first + 1);
            node = select_first(env, doc, "meta[property=og:image]");
            std::string image = node ? attr(env, node, "content") : "";
            if (node) env->DeleteLocalRef(node);
            return json_object({{"title", json_string(title)}, {"url", json_string(page_url)},
                                {"imageUrl", json_string(image)}, {"episodes", json_array(parse_episodes(env, doc, image))}});
        }
        if (operation == 3) {
            // TODO(network): primary playback depends on POST /wp-admin/admin-ajax.php (miru_get_api_player_url), nonce and server_idx; iframe hosts (including Getplay/Torbo) also require HTTP/API token resolution. Never fabricate a stream without those responses.
            return json_object({{"url", json_string(video_from_html(document_html(env, doc)))}});
        }
        if (operation == 4) {
            std::vector<std::string> items, pages;
            for (jobject movie : select(env, doc, "div.-movie")) {
                jobject link = select_first(env, movie, "div.pic a");
                jobject img = select_first(env, movie, "div.pic img");
                jobject title_node = select_first(env, movie, "h2.entry-title a");
                if (link && img && title_node) {
                    const std::string item_url = attr(env, link, "href");
                    const std::string item_title = text(env, title_node);
                    const std::string image = has_attr(env, img, "data-src") ? attr(env, img, "data-src") : attr(env, img, "src");
                    jobject sub = select_first(env, movie, "div.imdb");
                    const std::string dub = sub ? text(env, sub) : "";
                    items.push_back(item_json(item_title, item_url, image, dub));
                    if (sub) env->DeleteLocalRef(sub);
                }
                if (link) env->DeleteLocalRef(link);
                if (img) env->DeleteLocalRef(img);
                if (title_node) env->DeleteLocalRef(title_node);
                if (movie) env->DeleteLocalRef(movie);
            }
            jobject prev = select_first(env, doc, "div.content-pagination a.prev.page-numbers");
            if (prev) {
                pages.push_back(page_json("«", attr(env, prev, "href")));
                env->DeleteLocalRef(prev);
            }
            for (jobject link : select(env, doc, "div.content-pagination a.page-numbers:not(.prev):not(.next)")) {
                pages.push_back(page_json(text(env, link), attr(env, link, "href")));
                if (link) env->DeleteLocalRef(link);
            }
            jobject next = select_first(env, doc, "div.content-pagination a.next.page-numbers");
            if (next) {
                pages.push_back(page_json("»", attr(env, next, "href")));
                env->DeleteLocalRef(next);
            }
            return json_object({{"animeItems", json_array(items)}, {"pageItems", json_array(pages)}});
        }
    } catch (...) {
        // Keep native exceptions inside this JNI boundary and return operation-shaped JSON.
    }
    if (operation == 4) return json_object({{"animeItems", json_array({})}, {"pageItems", json_array({})}});
    if (operation == 3) return json_object({{"url", json_string("")}});
    if (operation == 2) return json_array({});
    return empty_detail();
}
