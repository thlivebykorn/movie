#include "../native_common.h"

#include <algorithm>
#include <cctype>
#include <regex>
#include <string>
#include <unordered_set>
#include <vector>

namespace {
using anime_native::attr;
using anime_native::base_uri;
using anime_native::json_array;
using anime_native::json_bool;
using anime_native::json_number;
using anime_native::json_object;
using anime_native::json_string;
using anime_native::select;
using anime_native::select_first;
using anime_native::text;

std::string trim(std::string value) {
    const auto first = std::find_if_not(value.begin(), value.end(), [](unsigned char c) {
        return std::isspace(c) != 0;
    });
    const auto last = std::find_if_not(value.rbegin(), value.rend(), [](unsigned char c) {
        return std::isspace(c) != 0;
    }).base();
    if (first >= last) return "";
    return std::string(first, last);
}

bool parse_int(const std::string& value, int& result) {
    const std::string cleaned = trim(value);
    if (cleaned.empty()) return false;
    try {
        size_t consumed = 0;
        const int parsed = std::stoi(cleaned, &consumed);
        if (consumed != cleaned.size()) return false;
        result = parsed;
        return true;
    } catch (...) {
        return false;
    }
}

std::string episode_json(const std::string& title, const std::string& info_url,
                         const std::string& image_url, const std::string& episode_referer,
                         int episode_number) {
    return json_object({
        {"title", json_string(title)}, {"infoUrl", json_string(info_url)},
        {"imageUrl", json_string(image_url)}, {"videoUrl", json_string("")},
        {"referer", json_string(episode_referer)},
        {"episodeNumber", json_number(episode_number)}, {"dataId", json_string("")}
    });
}

std::vector<std::string> parse_movie_episodes(JNIEnv* env, jobject doc,
                                              const std::string& image_url,
                                              const std::string& page_url,
                                              const std::string& main_title) {
    std::vector<std::string> result;
    std::unordered_set<int> seen;
    for (jobject server : select(env, doc, "li.halim-episode span.halim-btn")) {
        if (!server) continue;
        if (attr(env, server, "data-server") != "1000") {
            int number = 0;
            if (parse_int(attr(env, server, "data-episode"), number) && seen.insert(number).second) {
                result.push_back(episode_json(main_title.empty() ? "ดูหนัง" : main_title,
                                              page_url, image_url, page_url, number));
            }
        }
        env->DeleteLocalRef(server);
    }
    return result;
}

std::vector<std::string> parse_episodes(JNIEnv* env, jobject doc,
                                        const std::string& image_url,
                                        const std::string& page_url) {
    std::string main_title;
    jobject download_server = select_first(env, doc, "span[data-server='1000']");
    if (download_server) {
        main_title = trim(attr(env, download_server, "data-title"));
        env->DeleteLocalRef(download_server);
    }

    jobject sequel_select = select_first(env, doc, "select[name=Sequel_select]");
    if (sequel_select) {
        const auto options = select(env, sequel_select, "option");
        bool number_based = false;
        std::vector<int> numbers;
        std::unordered_set<int> unique;
        for (jobject option : options) {
            if (!option) continue;
            int number = 0;
            if (parse_int(attr(env, option, "value"), number)) {
                number_based = true;
                if (unique.insert(number).second) numbers.push_back(number);
            }
            env->DeleteLocalRef(option);
        }
        env->DeleteLocalRef(sequel_select);
        if (number_based) {
            std::vector<std::string> result;
            for (int number : numbers) {
                const std::string title = (main_title.empty() ? "" : main_title + " ") +
                                          "ตอนที่ " + std::to_string(number);
                result.push_back(episode_json(title, page_url, image_url, page_url, number));
            }
            return result;
        }
    }
    return parse_movie_episodes(env, doc, image_url, page_url, main_title);
}

bool is_numeric_text(const std::string& value, int& number) {
    return parse_int(value, number);
}

std::string empty_result(int operation) {
    if (operation == 2) return "[]";
    if (operation == 3) return json_object({{"url", json_string("")}});
    if (operation == 4) return json_object({{"animeItems", "[]"}, {"pageItems", "[]"}});
    return json_object({{"title", json_string("")}, {"url", json_string("")},
                        {"imageUrl", json_string("")}, {"episodes", "[]"}});
}
} // namespace

std::string parse_movie24hd(JNIEnv* env, jobject doc, int operation,
                            const std::string& referer, int episode_number) {
    (void)episode_number;
    try {
        if (!doc) return empty_result(operation);
        const std::string page_url = base_uri(env, doc);

        if (operation == 1) {
            jobject title_meta = select_first(env, doc, "meta[property=og:title]");
            jobject image_meta = select_first(env, doc, "meta[property=og:image]");
            const std::string title = title_meta ? attr(env, title_meta, "content") : "";
            const std::string image = image_meta ? attr(env, image_meta, "content") : "";
            const auto episodes = parse_episodes(env, doc, image, page_url);
            if (title_meta) env->DeleteLocalRef(title_meta);
            if (image_meta) env->DeleteLocalRef(image_meta);
            return json_object({{"title", json_string(title)}, {"url", json_string(page_url)},
                                {"imageUrl", json_string(image)}, {"episodes", json_array(episodes)}});
        }
        if (operation == 2) return json_array(parse_episodes(env, doc, referer, page_url));
        if (operation == 3) {
            // TODO(network): Java POSTs halim_ajax_player with nonce, episode, postid,
            // server and language, then parses the response iframe. The AJAX response
            // is not present in this Document. Do not issue HTTP or fabricate a URL here.
            const std::string page_text = text(env, doc);
            if (page_text.find("Cloudflare") != std::string::npos ||
                page_text.find("Access Denied") != std::string::npos) {
                return json_object({{"url", json_string("")}});
            }
            return json_object({{"url", json_string("")}});
        }
        if (operation == 4) {
            std::vector<std::string> anime_items;
            const auto grids = select(env, doc, "div.grid-movie");
            jobject target_grid = nullptr;
            if (grids.size() > 1) target_grid = grids[1];
            else if (!grids.empty()) target_grid = grids[0];
            for (jobject grid : grids) {
                if (grid != target_grid) env->DeleteLocalRef(grid);
            }
            if (target_grid) {
                for (jobject item : select(env, target_grid, "div.box")) {
                    jobject link = select_first(env, item, "a");
                    if (link) {
                        const std::string url = attr(env, link, "href");
                        jobject title_element = select_first(env, item, "div.p2");
                        const std::string title = title_element ? text(env, title_element) : "";
                        jobject img = select_first(env, link, "img");
                        std::string image_url = img ? attr(env, img, "data-lazy-src") : "";
                        if (image_url.empty() && img) image_url = attr(env, img, "src");
                        jobject info_element = select_first(env, item, "div.p1");
                        const std::string info = info_element ? text(env, info_element) : "";
                        jobject rating_element = select_first(env, item, "span.info1");
                        const std::string rating = rating_element ? text(env, rating_element) : "";
                        anime_items.push_back(json_object({
                            {"title", json_string(title)}, {"url", json_string(url)},
                            {"imageUrl", json_string(image_url)},
                            {"dubText", json_string(info + " | " + rating)},
                            {"latestEpisode", json_string("")}
                        }));
                        if (title_element) env->DeleteLocalRef(title_element);
                        if (img) env->DeleteLocalRef(img);
                        if (info_element) env->DeleteLocalRef(info_element);
                        if (rating_element) env->DeleteLocalRef(rating_element);
                        env->DeleteLocalRef(link);
                    }
                    env->DeleteLocalRef(item);
                }
                env->DeleteLocalRef(target_grid);
            }

            std::vector<std::string> page_items;
            jobject pagination = select_first(env, doc, "nav.navigation.pagination");
            if (pagination) {
                for (jobject link : select(env, pagination, "a.page-numbers:not(.prev):not(.next)")) {
                    const std::string number_text = trim(text(env, link));
                    int number = 0;
                    if (is_numeric_text(number_text, number)) {
                        page_items.push_back(json_object({
                            {"pageNumber", json_number(number)}, {"url", json_string(attr(env, link, "href"))},
                            {"isCurrent", json_bool(false)}
                        }));
                    }
                    env->DeleteLocalRef(link);
                }
                jobject current = select_first(env, pagination, "span.page-numbers.current");
                if (current) {
                    const std::string number_text = trim(text(env, current));
                    int number = 0;
                    if (is_numeric_text(number_text, number)) {
                        page_items.push_back(json_object({
                            {"pageNumber", json_number(number)}, {"url", json_string("")},
                            {"isCurrent", json_bool(true)}
                        }));
                    }
                    env->DeleteLocalRef(current);
                }
                env->DeleteLocalRef(pagination);
            }
            return json_object({{"animeItems", json_array(anime_items)},
                                {"pageItems", json_array(page_items)}});
        }
        return empty_result(operation);
    } catch (...) {
        return empty_result(operation);
    }
}
