#include "../native_common.h"

#include <algorithm>
#include <cctype>
#include <regex>
#include <string>
#include <vector>

namespace {
std::string trim_copy(const std::string& value) {
    const auto first = std::find_if_not(value.begin(), value.end(), [](unsigned char c) { return std::isspace(c) != 0; });
    const auto last = std::find_if_not(value.rbegin(), value.rend(), [](unsigned char c) { return std::isspace(c) != 0; }).base();
    return first >= last ? std::string() : std::string(first, last);
}

bool starts_with_http(const std::string& value) { return value.rfind("http", 0) == 0; }

std::string origin_of(const std::string& url) {
    const auto scheme = url.find("://");
    if (scheme == std::string::npos) return "";
    const auto end = url.find('/', scheme + 3);
    return end == std::string::npos ? url : url.substr(0, end);
}

bool numeric(const std::string& value) {
    if (value.empty()) return false;
    try {
        std::size_t used = 0;
        (void)std::stoi(value, &used);
        return used == value.size();
    } catch (...) { return false; }
}

int parse_int_or(const std::string& value, int fallback) {
    const auto trimmed = trim_copy(value);
    if (!numeric(trimmed)) return fallback;
    try { return std::stoi(trimmed); } catch (...) { return fallback; }
}

int episode_number_from_title(const std::string& title, int fallback) {
    static const std::regex pattern("EP[\\s-]*(\\d+)", std::regex_constants::icase);
    std::smatch match;
    return std::regex_search(title, match, pattern) ? parse_int_or(match[1].str(), fallback) : fallback;
}

std::string episode_json(const std::string& title, const std::string& info_url,
                         const std::string& image_url, const std::string& ep_referer,
                         int number) {
    return json_object({{"title", json_string(title)}, {"infoUrl", json_string(info_url)},
                        {"imageUrl", json_string(image_url)}, {"videoUrl", json_string("")},
                        {"referer", json_string(ep_referer)}, {"episodeNumber", json_number(number)},
                        {"dataId", json_string("")}});
}

std::vector<std::string> parse_table(JNIEnv* env, jobject table, const std::string& image_url) {
    std::vector<std::string> result;
    const auto rows = select(env, table, "tbody tr");
    for (std::size_t i = 0; i < rows.size(); ++i) {
        jobject row = rows[i];
        jobject link = select_first(env, row, "td a");
        if (link) {
            const std::string title = trim_copy(text(env, link));
            const std::string url = abs_url(env, link, "href");
            const auto tds = select(env, row, "td");
            const int number = tds.size() >= 2 ? parse_int_or(text(env, tds[1]), static_cast<int>(i) + 1) : static_cast<int>(i) + 1;
            result.push_back(episode_json(title, url, image_url, url, number));
            for (jobject td : tds) env->DeleteLocalRef(td);
            env->DeleteLocalRef(link);
        }
        env->DeleteLocalRef(row);
    }
    return result;
}

std::vector<std::string> parse_dropdown(JNIEnv* env, jobject dropdown, jobject doc,
                                        const std::string& image_url) {
    std::vector<std::string> result;
    const std::string page_url = base_uri(env, doc);
    const auto options = select(env, dropdown, "option");
    for (std::size_t i = 0; i < options.size(); ++i) {
        jobject option = options[i];
        const std::string title = trim_copy(text(env, option));
        std::string url = attr(env, option, "value");
        // Exact Java fallback: concatenate baseUri directly for any non-http value.
        if (!starts_with_http(url)) url = page_url + url;
        result.push_back(episode_json(title, url, image_url, url,
                                      episode_number_from_title(title, static_cast<int>(i) + 1)));
        env->DeleteLocalRef(option);
    }
    return result;
}

std::vector<std::string> parse_standard(JNIEnv* env, jobject doc, const std::string& image_url) {
    std::vector<std::string> result;
    const std::string page_url = base_uri(env, doc);
    for (jobject server_list : select(env, doc, "div.list-eps-ajax")) {
        const auto episodes = select(env, server_list, "li.halim-episode");
        for (jobject episode : episodes) {
            jobject span = select_first(env, episode, "span.halim-btn");
            if (span) {
                const std::string title = attr(env, span, "data-title");
                const std::string data_episode = attr(env, span, "data-episode");
                const int number = data_episode.empty() ? 1 : parse_int_or(data_episode, 1);
                result.push_back(episode_json(title, page_url, image_url, page_url, number));
                env->DeleteLocalRef(span);
            }
            env->DeleteLocalRef(episode);
        }
        env->DeleteLocalRef(server_list);
    }
    if (result.empty()) {
        jobject meta = select_first(env, doc, "meta[property=og:title]");
        const std::string title = meta ? attr(env, meta, "content") : "Movie";
        if (meta) env->DeleteLocalRef(meta);
        result.push_back(episode_json(title, page_url, image_url, page_url, 1));
    }
    return result;
}

std::vector<std::string> parse_episodes(JNIEnv* env, jobject doc, const std::string& image_url) {
    jobject table = select_first(env, doc, "table#Sequel");
    if (table) {
        auto episodes = parse_table(env, table, image_url);
        env->DeleteLocalRef(table);
        if (!episodes.empty()) return episodes;
    }
    jobject dropdown = select_first(env, doc, "select[name=Sequel_select]");
    if (dropdown) {
        auto episodes = parse_dropdown(env, dropdown, doc, image_url);
        env->DeleteLocalRef(dropdown);
        if (!episodes.empty()) return episodes;
    }
    return parse_standard(env, doc, image_url);
}

std::vector<std::string> parse_anime_items(JNIEnv* env, jobject doc) {
    std::vector<std::string> result;
    const std::string base_url = base_uri(env, doc);
    const std::string origin = origin_of(base_url);
    const auto movie_items = select(env, doc, "article.halim-item, div.halim-item, [class*=halim-item]");
    for (jobject item : movie_items) {
        jobject link = select_first(env, item, "a.halim-thumb");
        if (link) {
            const std::string url = attr(env, link, "href");
            jobject title_element = select_first(env, item, "h2.entry-title");
            const std::string title = title_element ? text(env, title_element) : attr(env, link, "title");
            jobject img = select_first(env, link, "img.lazyload");
            std::string image_url = img ? attr(env, img, "data-src") : "";
            if (!starts_with_http(image_url) && !image_url.empty()) image_url = origin + image_url;
            jobject sound = select_first(env, item, "span.soundsub");
            jobject status = select_first(env, item, "span.status");
            const std::string sound_info = sound ? text(env, sound) : "";
            const std::string status_text = status ? text(env, status) : "";
            result.push_back(json_object({{"title", json_string(title)}, {"url", json_string(url)},
                                          {"imageUrl", json_string(image_url)},
                                          {"dubText", json_string(sound_info + " " + status_text)},
                                          {"latestEpisode", json_string("")}}));
            if (title_element) env->DeleteLocalRef(title_element);
            if (img) env->DeleteLocalRef(img);
            if (sound) env->DeleteLocalRef(sound);
            if (status) env->DeleteLocalRef(status);
            env->DeleteLocalRef(link);
        }
        env->DeleteLocalRef(item);
    }
    return result;
}

std::vector<std::string> parse_page_items(JNIEnv* env, jobject doc) {
    std::vector<std::string> result;
    const auto links = select(env, doc, "ul.page-numbers a.page-numbers:not(.prev):not(.next)");
    for (jobject link : links) {
        const std::string number = trim_copy(text(env, link));
        if (numeric(number)) {
            result.push_back(json_object({{"pageNumber", json_string(number)},
                                          {"url", json_string(attr(env, link, "href"))},
                                          {"isCurrent", json_bool(false)}}));
        }
        env->DeleteLocalRef(link);
    }
    jobject current = select_first(env, doc, "span.page-numbers.current");
    if (current) {
        const std::string number = trim_copy(text(env, current));
        if (numeric(number)) result.push_back(json_object({{"pageNumber", json_string(number)},
                                                            {"url", json_string("")},
                                                            {"isCurrent", json_bool(true)}}));
        env->DeleteLocalRef(current);
    }
    return result;
}

std::string empty_result(int operation) {
    if (operation == 2) return "[]";
    if (operation == 3) return json_object({{"url", json_string("")}});
    if (operation == 4) return json_object({{"animeItems", "[]"}, {"pageItems", "[]"}});
    return json_object({{"title", json_string("")}, {"url", json_string("")},
                        {"imageUrl", json_string("")}, {"episodes", "[]"}});
}
} // namespace

std::string parse_movie123(JNIEnv* env, jobject doc, int operation,
                           const std::string& referer, int episode_number) {
    (void)episode_number;
    try {
        if (!doc) return empty_result(operation);
        const std::string page_url = base_uri(env, doc);
        if (operation == 1) {
            jobject title_meta = select_first(env, doc, "meta[property=og:title]");
            jobject image_meta = select_first(env, doc, "meta[property=og:image]");
            const std::string title = title_meta ? attr(env, title_meta, "content") : "";
            const std::string image = image_meta ? attr(env, image_meta, "content") : "";
            const auto episodes = parse_episodes(env, doc, image);
            if (title_meta) env->DeleteLocalRef(title_meta);
            if (image_meta) env->DeleteLocalRef(image_meta);
            return json_object({{"title", json_string(title)}, {"url", json_string(page_url)},
                                {"imageUrl", json_string(image)}, {"episodes", json_array(episodes)}});
        }
        if (operation == 2) return json_array(parse_episodes(env, doc, referer));
        if (operation == 3) {
            jobject active = select_first(env, doc, "span.halim-btn.active");
            if (!active) active = select_first(env, doc, "span.halim-btn");
            if (active) {
                // Capture original AJAX inputs to document the dependency, but the supplied
                // HTML lacks the remote /api/get.php response needed for the iframe URL.
                const std::string post_id = attr(env, active, "data-post-id");
                const std::string server = attr(env, active, "data-server");
                const std::string episode = attr(env, active, "data-episode");
                (void)post_id; (void)server; (void)episode; (void)referer;
                env->DeleteLocalRef(active);
            }
            // TODO: Java POSTs action=halim_ajax_player&nonce=...&episode=...&postid=...&server=...
            // to https://<Movie123 host>/api/get.php, reads an iframe src, and changes id=...
            // to PLAY_API + id/id.m3u8. Network is forbidden here; return empty, not a guess.
            return json_object({{"url", json_string("")}});
        }
        if (operation == 4) {
            return json_object({{"animeItems", json_array(parse_anime_items(env, doc))},
                                {"pageItems", json_array(parse_page_items(env, doc))}});
        }
        return empty_result(operation);
    } catch (...) {
        return empty_result(operation);
    }
}
