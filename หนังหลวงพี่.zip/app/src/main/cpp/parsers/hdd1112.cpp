#include "../native_common.h"

#include <algorithm>
#include <cctype>
#include <regex>
#include <string>
#include <utility>
#include <vector>

namespace {

std::string trim_copy(const std::string& s) {
    const auto b = std::find_if_not(s.begin(), s.end(), [](unsigned char c) { return std::isspace(c); });
    if (b == s.end()) return "";
    const auto e = std::find_if_not(s.rbegin(), s.rend(), [](unsigned char c) { return std::isspace(c); }).base();
    return std::string(b, e);
}

std::string unescape_slashes(std::string s) {
    std::size_t p = 0;
    while ((p = s.find("\\/", p)) != std::string::npos) s.replace(p, 2, "/");
    return s;
}

std::string balanced_object(const std::string& s, std::size_t start) {
    if (start >= s.size() || s[start] != '{') return "";
    int depth = 0;
    bool quoted = false, escaped = false;
    for (std::size_t i = start; i < s.size(); ++i) {
        const char c = s[i];
        if (quoted) {
            if (escaped) escaped = false;
            else if (c == '\\') escaped = true;
            else if (c == '"') quoted = false;
        } else if (c == '"') quoted = true;
        else if (c == '{') ++depth;
        else if (c == '}' && --depth == 0) return s.substr(start, i - start + 1);
    }
    return "";
}

std::string object_for_key(const std::string& json, const std::string& key) {
    const std::regex key_re("\\\"" + key + "\\\"\\s*:");
    std::smatch m;
    if (!std::regex_search(json, m, key_re)) return "";
    const std::size_t pos = static_cast<std::size_t>(m.position() + m.length());
    const std::size_t brace = json.find('{', pos);
    if (brace == std::string::npos) return "";
    return balanced_object(json, brace);
}

std::string string_for_key(const std::string& json, const std::string& key) {
    const std::regex key_re("\\\"" + key + "\\\"\\s*:\\s*\\\"((?:\\\\.|[^\\\"])*)\\\"");
    std::smatch m;
    if (!std::regex_search(json, m, key_re)) return "";
    std::string value = m[1].str();
    value = std::regex_replace(value, std::regex("\\\\\""), "\"");
    value = std::regex_replace(value, std::regex("\\\\n"), "\n");
    return unescape_slashes(value);
}

std::string episode_json(const std::string& title, const std::string& info,
                         const std::string& image, const std::string& video,
                         const std::string& ep_referer, int number,
                         const std::string& data_id = "") {
    return json_object({{"title", json_string(title)}, {"infoUrl", json_string(info)},
                        {"imageUrl", json_string(image)}, {"videoUrl", json_string(video)},
                        {"referer", json_string(ep_referer)}, {"episodeNumber", json_number(number)},
                        {"dataId", json_string(data_id)}});
}

std::string extract_torbo_embed(const std::string& input) {
    static const std::regex re("(https?://[^/]+/(?:embed|play)/[A-Za-z0-9]{32})", std::regex_constants::icase);
    std::smatch m;
    const std::string s = unescape_slashes(input);
    return std::regex_search(s, m, re) ? m[1].str() : "";
}

std::string extract_torbo_stream(const std::string& input) {
    static const std::regex re("(https?://[^/]+)/(?:embed|play)/([A-Za-z0-9]{32})", std::regex_constants::icase);
    std::smatch m;
    const std::string s = unescape_slashes(input);
    if (!std::regex_search(s, m, re)) return "";
    return m[1].str() + "/api/stream/" + m[2].str() + "/index.m3u8";
}

std::vector<std::string> episodes_from_meta(const std::string& meta, const std::string& image,
                                           const std::string& page_referer) {
    std::vector<std::string> out;
    const std::string series = object_for_key(meta, "series");
    if (series.empty()) return out;
    const std::string videos = object_for_key(series, "videos");
    if (videos.empty()) return out;
    for (const char* version : {"th", "sub"}) {
        const std::string version_obj = object_for_key(videos, version);
        if (version_obj.empty()) continue;
        const std::string list = object_for_key(version_obj, "list");
        if (list.empty()) continue;
        int total = 0;
        const std::string total_value = [&]() {
            std::smatch m;
            if (std::regex_search(version_obj, m, std::regex("\\\"total_ep\\\"\\s*:\\s*(\\d+)"))) return m[1].str();
            return std::string("0");
        }();
        try { total = std::stoi(total_value); } catch (...) { total = 0; }
        if (total <= 0) {
            const std::regex ep_key("\\\"ep_\\d+\\\"\\s*:");
            total = static_cast<int>(std::distance(std::sregex_iterator(list.begin(), list.end(), ep_key), std::sregex_iterator()));
        }
        for (int i = 1; i <= total; ++i) {
            const std::string ep = object_for_key(list, "ep_" + std::to_string(i));
            if (ep.empty()) continue;
            std::string video_url = string_for_key(object_for_key(ep, "server_1"), "url");
            if (video_url.empty()) video_url = string_for_key(object_for_key(ep, "server_2"), "url");
            if (video_url.empty()) continue;
            const std::string embed = extract_torbo_embed(video_url);
            const std::string stream = extract_torbo_stream(video_url);
            if (!stream.empty()) video_url = stream;
            out.push_back(episode_json("EP." + std::to_string(i), video_url, image, "",
                                       embed.empty() ? page_referer : embed, i));
        }
        if (!out.empty()) break;
    }
    return out;
}

std::vector<std::string> parse_episodes(JNIEnv* env, jobject doc, const std::string& image,
                                        const std::string& page_referer) {
    std::vector<std::string> episodes;
    for (jobject script : select(env, doc, "script")) {
        const std::string source = text(env, script);
        const std::string marker = "window.cjPlayerMeta";
        const auto marker_pos = source.find(marker);
        if (marker_pos == std::string::npos) continue;
        const auto eq = source.find('=', marker_pos + marker.size());
        if (eq == std::string::npos) continue;
        const std::string rhs = trim_copy(source.substr(eq + 1));
        std::string meta;
        if (!rhs.empty() && rhs[0] == '{') meta = balanced_object(rhs, 0);
        // TODO: Encoded cjPlayerMeta requires Base64 + RC4 + MD5 decryption. Do not fabricate episodes.
        if (meta.empty()) continue;
        episodes = episodes_from_meta(meta, image, page_referer);
        if (!episodes.empty()) break;
    }
    return episodes;
}

std::string page_script_video(const std::string& html) {
    static const std::regex jw("sources\\s*:\\s*\\[\\s*\\{\\s*file\\s*:\\s*\"([^\"]+\\.m3u8[^\"]*)\"", std::regex_constants::ECMAScript);
    std::smatch m;
    if (html.find("sources") != std::string::npos && html.find("file") != std::string::npos && std::regex_search(html, m, jw))
        return unescape_slashes(m[1].str());

    static const std::regex server_re("\\\"videoServer\\\":\\\"(\\d+)\\\"");
    static const std::regex file_re("\\\"videoSources\\\":\\s*\\[\\s*\\{\\s*\\\"file\\\":\\\"([^\"]+)\\\"");
    static const std::regex hosts_re("\\\"hostList\\\":(\\{.*?\\})");
    std::smatch server, file, hosts;
    if (html.find("videoSources") == std::string::npos ||
        !std::regex_search(html, server, server_re) || !std::regex_search(html, file, file_re) ||
        !std::regex_search(html, hosts, hosts_re)) return "";
    const std::string domain_list = object_for_key(hosts[1].str(), server[1].str());
    std::smatch domain_match;
    if (!std::regex_search(domain_list, domain_match, std::regex("\\\"?([^\\\"'\\[\\],]+)\\\"?"))) return "";
    std::string domain = trim_copy(domain_match[1].str());
    std::string result = file[1].str();
    result = std::regex_replace(result, std::regex(R"(https:\\\\/\\\\/\\d+\\\\/cdn\\\\/hls\\\\/)"), "https://" + domain + "/api/files/");
    return unescape_slashes(result);
}

std::string parse_video(JNIEnv* env, jobject doc) {
    const std::string page_url = base_uri(env, doc);
    const std::string torbo = extract_torbo_stream(page_url);
    if (!torbo.empty()) return torbo;
    jobject iframe = select_first(env, doc, "iframe[src]");
    if (iframe) {
        std::string iframe_url = abs_url(env, iframe, "src");
        if (iframe_url.empty()) iframe_url = attr(env, iframe, "src");
        if (!iframe_url.empty()) return iframe_url;
    }
    const std::string lower = [&]() { std::string s = page_url; std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); }); return s; }();
    if (lower.find("online225.com") != std::string::npos || lower.find("oklive-1.xyz") != std::string::npos ||
        lower.find("mycdn-hd.xyz") != std::string::npos || lower.find("ok-nah.com") != std::string::npos ||
        lower.find("play-heyhd.com") != std::string::npos) {
        // TODO: Java fetches these player pages before extracting iframe/JWPlayer/videoSources; native receives only supplied HTML and must not perform HTTP.
        for (jobject script : select(env, doc, "script")) {
            const std::string found = page_script_video(text(env, script));
            if (!found.empty()) return found;
        }
    }
    return page_url;
}

std::string empty_result(int operation) {
    if (operation == 2) return "[]";
    if (operation == 3) return "{\"url\":\"\"}";
    if (operation == 4) return "{\"animeItems\":[],\"pageItems\":[]}";
    return "{\"title\":\"\",\"url\":\"\",\"imageUrl\":\"\",\"episodes\":[]}";
}

std::string parse_list_page(JNIEnv* env, jobject doc) {
    std::vector<std::string> anime_items;
    for (jobject article : select(env, doc, "div.post-item")) {
        jobject link = select_first(env, article, "a");
        if (!link) continue;

        jobject title_element = select_first(env, link, "h3.post-grid-title");
        jobject image_element = select_first(env, link, "img");
        jobject info_element = select_first(env, link, "div.flex span");
        anime_items.push_back(json_object({
            {"title", json_string(title_element ? text(env, title_element) : "")},
            {"url", json_string(attr(env, link, "href"))},
            {"imageUrl", json_string(image_element ? attr(env, image_element, "src") : "")},
            {"dubText", json_string(info_element ? text(env, info_element) : "")},
            {"latestEpisode", json_string("")}
        }));
    }

    std::vector<std::string> page_items;
    jobject pagination = select_first(env, doc, ".cj-pagination");
    if (pagination) {
        jobject prev_link = select_first(env, pagination, "a.prev.page-numbers");
        if (prev_link) {
            page_items.push_back(json_object({
                {"pageNumber", json_string("«")},
                {"url", json_string(attr(env, prev_link, "href"))},
                {"isCurrent", json_bool(false)}
            }));
        }

        for (jobject item : select(env, pagination, "ul.page-numbers > li:not(:has(a.prev, a.next))")) {
            jobject link = select_first(env, item, "a.page-numbers");
            jobject current_page = select_first(env, item, "span.page-numbers.current");
            jobject dots = select_first(env, item, "span.page-numbers.dots");
            (void)current_page;
            (void)dots;
            if (!link) continue;
            const std::string number = trim_copy(text(env, link));
            if (number.empty()) continue;
            page_items.push_back(json_object({
                {"pageNumber", json_string(number)},
                {"url", json_string(attr(env, link, "href"))},
                {"isCurrent", json_bool(false)}
            }));
        }

        jobject next_link = select_first(env, pagination, "a.next.page-numbers");
        if (next_link) {
            page_items.push_back(json_object({
                {"pageNumber", json_string("»")},
                {"url", json_string(attr(env, next_link, "href"))},
                {"isCurrent", json_bool(false)}
            }));
        }
    }
    return json_object({{"animeItems", json_array(anime_items)},
                        {"pageItems", json_array(page_items)}});
}

} // namespace

std::string parse_hdd1112(JNIEnv* env, jobject doc, int operation,
                          const std::string& referer, int episode_number) {
    (void)episode_number;
    try {
        if (!doc) return empty_result(operation);
        switch (operation) {
            case 1: {
                const std::string page = base_uri(env, doc);
                std::string host = page;
                const auto scheme = host.find("://");
                if (scheme != std::string::npos) host.erase(0, scheme + 3);
                const auto slash = host.find('/');
                if (slash != std::string::npos) host.resize(slash);
                std::string configured_host;
                static const std::regex host_re("^https?://([^/]+)");
                std::smatch host_match;
                if (std::regex_search(referer, host_match, host_re)) configured_host = host_match[1].str();
                // Match Java's allowed host suffixes (configured domain is not available as a native helper).
                const bool allowed = host == "1112hdss.com" || host == "1112hdc.com" ||
                                     (host.size() >= 13 && host.compare(host.size() - 13, 13, "1112hdss.com") == 0) ||
                                     (host.size() >= 10 && host.compare(host.size() - 10, 10, "1112hdc.com") == 0);
                (void)configured_host;
                if (!allowed) return empty_result(1);
                jobject title_meta = select_first(env, doc, "meta[property=og:title]");
                jobject image_meta = select_first(env, doc, "meta[property=og:image]");
                const std::string title = title_meta ? attr(env, title_meta, "content") : "";
                std::string image = image_meta ? attr(env, image_meta, "content") : "";
                if (image.empty()) image = "https://" + host + "/wp-content/themes/cj/assets/images/default-poster.jpg";
                const auto eps = parse_episodes(env, doc, image, page);
                return json_object({{"title", json_string(title)}, {"url", json_string(page)},
                                    {"imageUrl", json_string(image)}, {"episodes", json_array(eps)}});
            }
            case 2:
                return json_array(parse_episodes(env, doc, referer, base_uri(env, doc)));
            case 3:
                return json_object({{"url", json_string(parse_video(env, doc))}});
            case 4:
                return parse_list_page(env, doc);
            default:
                return empty_result(operation);
        }
    } catch (...) {
        return empty_result(operation);
    }
}
