#include "../native_common.h"

#include <algorithm>
#include <cctype>
#include <regex>
#include <string>
#include <vector>

namespace {
using anime_native::abs_url;
using anime_native::attr;
using anime_native::base_uri;
using anime_native::has_attr;
using anime_native::json_array;
using anime_native::json_bool;
using anime_native::json_number;
using anime_native::json_object;
using anime_native::json_string;
using anime_native::select;
using anime_native::select_first;
using anime_native::text;

std::string episode_json(const std::string& title, const std::string& info_url,
                         const std::string& image_url, const std::string& video_url,
                         const std::string& referer, int number, const std::string& data_id) {
    return json_object({{"title", json_string(title)}, {"infoUrl", json_string(info_url)},
                        {"imageUrl", json_string(image_url)}, {"videoUrl", json_string(video_url)},
                        {"referer", json_string(referer)}, {"episodeNumber", json_number(number)},
                        {"dataId", json_string(data_id)}});
}

std::vector<std::string> extract_episodes(JNIEnv* env, jobject doc, const std::string& ref,
                                          const std::string& image) {
    std::vector<std::string> result;
    const auto elements = select(env, doc, "span.episode[episode-id], .mp-ep-btn[data-id]");
    int number = 0;
    for (jobject ep : elements) {
        ++number;
        std::string id = attr(env, ep, "episode-id");
        if (id.empty()) id = attr(env, ep, "data-id");
        result.push_back(episode_json("ตอนที่ " + std::to_string(number),
            ref + "?episode-id=" + id, image, "", ref, number, ""));
        if (ep) env->DeleteLocalRef(ep);
    }
    return result;
}

std::string decode_slashes(std::string value) {
    size_t pos = 0;
    while ((pos = value.find("\\/", pos)) != std::string::npos) value.replace(pos, 2, "/");
    return value;
}

std::string direct_video_url(const std::string& html) {
    static const std::regex re(R"((https?://[^\s"']+\.(?:m3u8|mp4|mkv|webm)))", std::regex::icase);
    for (std::sregex_iterator it(html.begin(), html.end(), re), end; it != end; ++it) {
        const std::string url = (*it)[1].str();
        if (url.find("localhost") == std::string::npos && url.find("127.0.0.1") == std::string::npos)
            return url;
    }
    return "";
}

std::string iframe_from_html(const std::string& html) {
    static const std::regex re(R"(<iframe[^>]+src=["']([^"']+)["'])", std::regex::icase);
    std::smatch match;
    return std::regex_search(html, match, re) ? match[1].str() : "";
}

std::string script_video_url(JNIEnv* env, jobject doc) {
    static const std::regex json_re(R"rx("(?:file|url|src)"\s*:\s*"([^"]+\.(?:m3u8|mp4))")rx", std::regex::icase);
    static const std::regex js_re(R"rx((?:videoSources|sources|jwplayer\().*?file.*?"(https?:\\/\\/[^\"]+)")rx", std::regex::icase);
    for (jobject script : select(env, doc, "script")) {
        const std::string contents = text(env, script);
        std::smatch match;
        std::string result;
        if (std::regex_search(contents, match, json_re) || std::regex_search(contents, match, js_re))
            result = decode_slashes(match[1].str());
        if (script) env->DeleteLocalRef(script);
        if (!result.empty()) return result;
    }
    return "";
}

std::string normalize_iframe(std::string url, JNIEnv* env, jobject doc) {
    if (url.rfind("//", 0) == 0) return "https:" + url;
    if (url.rfind("http://", 0) == 0 || url.rfind("https://", 0) == 0) return url;
    // Jsoup's absUrl applies the same document base URL resolution used for element src.
    (void)env;
    (void)doc;
    return url;
}

std::string empty_list_result() {
    return json_object({{"animeItems", "[]"}, {"pageItems", "[]"}});
}

std::string trim_copy(std::string value) {
    const auto first = value.find_first_not_of(" \t\r\n\f\v");
    if (first == std::string::npos) return "";
    const auto last = value.find_last_not_of(" \t\r\n\f\v");
    return value.substr(first, last - first + 1);
}

bool is_numeric_page(const std::string& value) {
    const std::string trimmed = trim_copy(value);
    if (trimmed.empty()) return false;
    try {
        size_t consumed = 0;
        (void)std::stoi(trimmed, &consumed);
        return consumed == trimmed.size();
    } catch (...) {
        return false;
    }
}

std::string extract_list_page(JNIEnv* env, jobject doc) {
    std::vector<std::string> anime_items;
    for (jobject movie : select(env, doc, "div.-movie")) {
        jobject link = select_first(env, movie, "div.pic a");
        jobject img = select_first(env, movie, "div.pic img");
        jobject title_element = select_first(env, movie, "h2.entry-title a");

        if (link && img && title_element) {
            const std::string url = attr(env, link, "href");
            const std::string title = text(env, title_element);
            const std::string data_src = has_attr(env, img, "data-src")
                ? attr(env, img, "data-src") : attr(env, img, "src");
            jobject subtitle = select_first(env, movie, "div.qa-label.qa-bg");
            const std::string subtitle_text = subtitle ? trim_copy(text(env, subtitle)) : "";
            anime_items.push_back(json_object({
                {"title", json_string(title)}, {"url", json_string(url)},
                {"imageUrl", json_string(data_src)}, {"dubText", json_string(subtitle_text)},
                {"latestEpisode", json_string("")}
            }));
            if (subtitle) env->DeleteLocalRef(subtitle);
        }
        if (link) env->DeleteLocalRef(link);
        if (img) env->DeleteLocalRef(img);
        if (title_element) env->DeleteLocalRef(title_element);
        if (movie) env->DeleteLocalRef(movie);
    }

    std::vector<std::string> page_items;
    for (jobject link : select(env, doc,
            "div.content-pagination a.page-numbers:not(.prev):not(.next)")) {
        const std::string number = trim_copy(text(env, link));
        if (is_numeric_page(number)) {
            page_items.push_back(json_object({
                {"pageNumber", json_string(number)},
                {"url", json_string(attr(env, link, "href"))},
                {"isCurrent", json_bool(false)}
            }));
        }
        if (link) env->DeleteLocalRef(link);
    }
    jobject current = select_first(env, doc, "div.content-pagination span.page-numbers.current");
    if (current) {
        const std::string number = trim_copy(text(env, current));
        if (is_numeric_page(number)) {
            page_items.push_back(json_object({
                {"pageNumber", json_string(number)}, {"url", json_string("")},
                {"isCurrent", json_bool(true)}
            }));
        }
        env->DeleteLocalRef(current);
    }
    return json_object({{"animeItems", json_array(anime_items)},
                        {"pageItems", json_array(page_items)}});
}
}

std::string parse_goseries4k(JNIEnv* env, jobject doc, int operation,
                             const std::string& referer, int episode_number) {
    (void)episode_number;
    try {
        if (!doc) {
            if (operation == 2) return "[]";
            if (operation == 3) return json_object({{"url", json_string("")}});
            if (operation == 4) return empty_list_result();
            return json_object({{"title", json_string("")}, {"url", json_string("")},
                                {"imageUrl", json_string("")}, {"episodes", "[]"}});
        }
        const std::string doc_url = base_uri(env, doc);
        const std::string effective_ref = doc_url.empty() ? referer : doc_url;

        if (operation == 1) {
            jobject title_meta = select_first(env, doc, "meta[property=og:title]");
            jobject image_meta = select_first(env, doc, "meta[property=og:image]");
            std::string title = title_meta ? attr(env, title_meta, "content") : "";
            const std::string image = image_meta ? attr(env, image_meta, "content") : "";
            title.erase(std::remove_if(title.begin(), title.end(), [](char c) {
                return c == '[' || c == ']' || c == '.' || c == ':';
            }), title.end());
            const auto first = title.find_first_not_of(" \t\r\n");
            if (first == std::string::npos) title.clear();
            else title = title.substr(first, title.find_last_not_of(" \t\r\n") - first + 1);
            if (title_meta) env->DeleteLocalRef(title_meta);
            if (image_meta) env->DeleteLocalRef(image_meta);
            return json_object({{"title", json_string(title)}, {"url", json_string(doc_url)},
                                {"imageUrl", json_string(image)},
                                {"episodes", json_array(extract_episodes(env, doc, effective_ref, image))}});
        }
        if (operation == 2)
            return json_array(extract_episodes(env, doc, effective_ref, ""));

        if (operation == 3) {
            // Java first POSTs action=miru_custom_player and post_id=<episode-id> to
            // /wp-admin/admin-ajax.php, then may fetch iframe/backup pages and resolve
            // Torbo/Getplay stream tokens. These network-dependent results cannot be
            // recovered from the supplied episode document; networking remains Java-side.
            const std::string html = text(env, doc);
            std::string url = direct_video_url(html);
            if (url.empty()) url = script_video_url(env, doc);
            if (url.empty()) {
                std::string iframe = iframe_from_html(html);
                if (!iframe.empty()) {
                    jobject iframe_el = select_first(env, doc, "iframe[src]");
                    if (iframe_el) {
                        const std::string resolved = abs_url(env, iframe_el, "src");
                        if (!resolved.empty()) iframe = resolved;
                        env->DeleteLocalRef(iframe_el);
                    }
                    url = normalize_iframe(iframe, env, doc);
                }
            }
            // Also retain a direct JWPlayer response extraction without making AJAX calls.
            if (url.empty()) {
                static const std::regex jw(R"rx(sources:\s*\[\s*\{\s*file:\s*"([^"]+\.m3u8)")rx", std::regex::icase);
                std::smatch match;
                if (std::regex_search(html, match, jw)) url = decode_slashes(match[1].str());
            }
            // TODO(network): implement neither AJAX, backup-server fetches, iframe page fetches,
            // nor Torbo/Getplay token resolution here; preserve these in Java networking layer.
            return json_object({{"url", json_string(url)}});
        }

        if (operation == 4) {
            return extract_list_page(env, doc);
        }
    } catch (...) {
        if (operation == 2) return "[]";
        if (operation == 3) return json_object({{"url", json_string("")}});
        if (operation == 4) return empty_list_result();
        return json_object({{"title", json_string("")}, {"url", json_string("")},
                            {"imageUrl", json_string("")}, {"episodes", "[]"}});
    }
    if (operation == 2) return "[]";
    if (operation == 3) return json_object({{"url", json_string("")}});
    if (operation == 4) return empty_list_result();
    return json_object({{"title", json_string("")}, {"url", json_string("")},
                        {"imageUrl", json_string("")}, {"episodes", "[]"}});
}
