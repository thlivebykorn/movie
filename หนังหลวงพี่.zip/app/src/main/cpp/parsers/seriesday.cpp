#include "../native_common.h"

#include <regex>
#include <string>
#include <utility>
#include <vector>

namespace {
using anime_native::abs_url;
using anime_native::attr;
using anime_native::base_uri;
using anime_native::json_array;
using anime_native::json_bool;
using anime_native::json_number;
using anime_native::json_object;
using anime_native::json_string;
using anime_native::select;
using anime_native::select_first;
using anime_native::text;

std::string episode_json(const std::string& title, const std::string& info_url,
                         const std::string& image_url, const std::string& video_url,
                         const std::string& referer, int episode_number,
                         const std::string& data_id = "") {
    return json_object({
        {"title", json_string(title)}, {"infoUrl", json_string(info_url)},
        {"imageUrl", json_string(image_url)}, {"videoUrl", json_string(video_url)},
        {"referer", json_string(referer)}, {"episodeNumber", json_number(episode_number)},
        {"dataId", json_string(data_id)}
    });
}

std::string episodes_json(JNIEnv* env, jobject doc, const std::string& image_url) {
    std::vector<std::string> items;
    const auto options = select(env, doc, "select[name=Sequel_select] option");
    const std::string page_url = base_uri(env, doc);
    for (size_t i = 0; i < options.size(); ++i) {
        jobject option = options[i];
        std::string episode_url = attr(env, option, "value");
        // Java concatenates the configured host even when value is relative; absolute values remain untouched
        if (!episode_url.empty() && episode_url[0] == '/') {
            const std::string origin = page_url.find("https://") == 0 ? page_url.substr(0, page_url.find('/', 8)) :
                                       (page_url.find("http://") == 0 ? page_url.substr(0, page_url.find('/', 7)) : "");
            if (!origin.empty()) episode_url = origin + episode_url;
            else episode_url = "https://" + episode_url.substr(1);
        } else if (episode_url.find("http://") != 0 && episode_url.find("https://") != 0) {
            episode_url = "https://" + episode_url;
        }
        items.push_back(episode_json(text(env, option), episode_url, image_url, "", page_url,
                                     static_cast<int>(i) + 1));
    }
    return json_array(items);
}

std::string operation4(JNIEnv* env, jobject doc) {
    std::vector<std::string> anime_items;
    for (jobject box : select(env, doc, "div.grid-movie > div.box")) {
        jobject link = select_first(env, box, "a");
        if (!link) continue;
        jobject title_node = select_first(env, link, ".p-box .p2");
        jobject img = select_first(env, link, ".box-img img");
        jobject info_node = select_first(env, link, ".p-box .p1");
        anime_items.push_back(json_object({
            {"title", json_string(title_node ? text(env, title_node) : "")},
            {"url", json_string(attr(env, link, "href"))},
            {"imageUrl", json_string(img ? attr(env, img, "data-lazy-src") : "")},
            {"dubText", json_string(info_node ? text(env, info_node) : "")},
            {"latestEpisode", json_string("")}
        }));
    }

    std::vector<std::string> pages;
    for (jobject link : select(env, doc, ".pagination a.page-numbers:not(.next):not(.prev)")) {
        const std::string page_text = text(env, link);
        if (page_text != "<<" && page_text != ">>" && page_text != "...") {
            pages.push_back(json_object({
                {"pageNumber", json_string(page_text)},
                {"url", json_string(attr(env, link, "href"))},
                {"isCurrent", json_bool(false)}
            }));
        }
    }
    jobject prev = select_first(env, doc, ".pagination a.prev.page-numbers");
    if (prev) pages.insert(pages.begin(), json_object({
        {"pageNumber", json_string("«")}, {"url", json_string(attr(env, prev, "href"))},
        {"isCurrent", json_bool(false)}
    }));
    jobject next = select_first(env, doc, ".pagination a.next.page-numbers");
    if (next) pages.push_back(json_object({
        {"pageNumber", json_string("»")}, {"url", json_string(attr(env, next, "href"))},
        {"isCurrent", json_bool(false)}
    }));
    return json_object({{"animeItems", json_array(anime_items)}, {"pageItems", json_array(pages)}});
}

std::string safe_empty(int operation) {
    if (operation == 1) return json_object({{"title", json_string("")}, {"url", json_string("")},
        {"imageUrl", json_string("")}, {"episodes", json_array({})}});
    if (operation == 2) return json_array({});
    if (operation == 3) return json_object({{"url", json_string("")}});
    if (operation == 4) return json_object({{"animeItems", json_array({})}, {"pageItems", json_array({})}});
    return "{}";
}
} // namespace

std::string parse_seriesday(JNIEnv* env, jobject doc, int operation,
                            const std::string& referer, int episode_number) {
    try {
        if (!doc) return safe_empty(operation);
        if (operation == 1) {
            jobject title_node = select_first(env, doc, "meta[property=og:title]");
            jobject image_node = select_first(env, doc, "img.attachment-full.size-full.wp-post-image");
            const std::string title = title_node ? attr(env, title_node, "content") : "";
            const std::string image = image_node ? attr(env, image_node, "data-lazy-src") : "";
            const std::string page = base_uri(env, doc);
            return json_object({{"title", json_string(title)}, {"url", json_string(page)},
                {"imageUrl", json_string(image)}, {"episodes", episodes_json(env, doc, image)}});
        }
        if (operation == 2) return episodes_json(env, doc, referer);
        if (operation == 3) {
            // TODO(network): Java posts action=halim_ajax_player to /api/get.php using nonce=data-type,
            // episode, postid, lang, and server. It retries with server="3" after the selected server.
            // This request depends on remote AJAX response HTML (iframe src), unavailable from the input doc;
            // no network call is made here. The returned video URL therefore remains empty.
            return json_object({{"url", json_string("")}});
        }
        if (operation == 4) return operation4(env, doc);
        (void)referer;
        (void)episode_number;
        return "{}";
    } catch (...) {
        return safe_empty(operation);
    }
}
