#include "../native_common.h"

#include <algorithm>
#include <cctype>
#include <regex>
#include <string>
#include <unordered_set>
#include <utility>
#include <vector>

namespace {

std::string trim_copy(const std::string& value) {
    const auto first = std::find_if_not(value.begin(), value.end(), [](unsigned char c) { return std::isspace(c); });
    if (first == value.end()) return "";
    const auto last = std::find_if_not(value.rbegin(), value.rend(), [](unsigned char c) { return std::isspace(c); }).base();
    return std::string(first, last);
}

std::string first_nonempty(const std::vector<std::string>& values) {
    for (const auto& value : values) {
        const auto trimmed = trim_copy(value);
        if (!trimmed.empty()) return trimmed;
    }
    return "";
}

std::string parse_image_url(JNIEnv* env, jobject link) {
    if (!link) return "";
    jobject img = select_first(env, link, "img");
    if (!img) return "";
    if (has_attr(env, img, "data-src")) {
        std::string value = abs_url(env, img, "data-src");
        if (value.empty()) value = attr(env, img, "data-src");
        if (!value.empty() && value.rfind("data:image", 0) != 0) return value;
    }
    if (has_attr(env, img, "src")) {
        std::string value = abs_url(env, img, "src");
        if (value.empty()) value = attr(env, img, "src");
        if (!value.empty() && value.rfind("data:image", 0) != 0) return value;
    }
    if (has_attr(env, img, "data-srcset")) {
        const std::string srcset = attr(env, img, "data-srcset");
        if (!srcset.empty()) {
            const auto comma = srcset.find(',');
            std::string first = trim_copy(srcset.substr(0, comma));
            const auto space = first.find_first_of(" \t\r\n");
            if (space != std::string::npos) first.resize(space);
            if (!first.empty() && first.rfind("data:image", 0) != 0) return first;
        }
    }
    return "";
}

bool likely_anime_url(const std::string& url) {
    if (url.empty()) return false;
    std::string lower = url;
    std::transform(lower.begin(), lower.end(), lower.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return lower.find("/episode/") == std::string::npos && lower.find("/tag/") == std::string::npos &&
           lower.find("/genre/") == std::string::npos && lower.find("/category/") == std::string::npos &&
           lower.find("/page/") == std::string::npos && (lower.empty() || lower.back() != '#');
}

std::string clean_title(std::string title) {
    const std::string marker = "Image:";
    std::size_t pos = 0;
    while ((pos = title.find(marker, pos)) != std::string::npos) title.erase(pos, marker.size());
    title = std::regex_replace(title, std::regex("\\s+"), " ");
    return trim_copy(title);
}

std::string extract_episode_text(const std::string& value) {
    static const std::regex pattern("(ตอน(?:ที่)?\\s*\\d+|EP\\.?\\s*\\d+|Episode\\s*\\d+)", std::regex_constants::icase);
    std::smatch match;
    return std::regex_search(value, match, pattern) ? trim_copy(match.str(1)) : "";
}

bool numeric(const std::string& value) {
    if (value.empty()) return false;
    return std::all_of(value.begin(), value.end(), [](unsigned char c) { return std::isdigit(c); });
}

std::string episode_json(const std::string& title, const std::string& info_url,
                         const std::string& image_url, const std::string& video_url,
                         const std::string& referer, int number, const std::string& data_id = "") {
    return json_object({{"title", json_string(title)}, {"infoUrl", json_string(info_url)},
                        {"imageUrl", json_string(image_url)}, {"videoUrl", json_string(video_url)},
                        {"referer", json_string(referer)}, {"episodeNumber", json_number(number)},
                        {"dataId", json_string(data_id)}});
}

std::vector<std::string> parse_episodes(JNIEnv* env, jobject doc, const std::string& image) {
    std::vector<std::string> out;
    const auto links = select(env, doc, "div.episode-b a");
    std::string root = base_uri(env, doc);
    const auto ep_pos = root.find("/episode");
    if (ep_pos != std::string::npos) root.resize(ep_pos);
    root += "/";
    for (std::size_t i = 0; i < links.size(); ++i) {
        out.push_back(episode_json("ตอนที่ " + std::to_string(i + 1), attr(env, links[i], "href"),
                                   image, "", root, static_cast<int>(i + 1)));
    }
    return out;
}

std::string parse_video(JNIEnv* env, jobject doc, const std::string& prefix) {
    jobject iframe = select_first(env, doc, "iframe.perfmatters-lazy");
    if (!iframe) return "";
    std::string url = has_attr(env, iframe, "data-src") ? attr(env, iframe, "data-src") : attr(env, iframe, "src");
    static const std::regex id_pattern("embed[0-9]*/([^/?]+)");
    std::smatch match;
    if (!url.empty() && std::regex_search(url, match, id_pattern)) {
        return prefix + match.str(1) + "/video.mp4/playlist.m3u8";
    }
    return "";
}

std::string parse_list(JNIEnv* env, jobject doc) {
    std::vector<std::string> anime_items;
    std::unordered_set<std::string> seen_urls;
    const auto articles = select(env, doc, "article.ez-postthumb");
    for (jobject article : articles) {
        try {
            jobject link = select_first(env, article, "a.ez-pt-link");
            if (!link) continue;
            const std::string title = has_attr(env, link, "title") ? attr(env, link, "title") : "";
            const std::string url = has_attr(env, link, "href") ? attr(env, link, "href") : "";
            const std::string image = parse_image_url(env, link);
            std::string subtitle;
            const auto spans = select(env, article, "span.ez-index-tag");
            for (jobject span : spans) {
                if (select_first(env, span, "i.fa.fa-bolt")) {
                    subtitle = trim_copy(own_text(env, span));
                    break;
                }
            }
            if (!title.empty() && !url.empty() && seen_urls.insert(url).second) {
                anime_items.push_back(json_object({{"title", json_string(title)}, {"url", json_string(url)},
                    {"imageUrl", json_string(image)}, {"dubText", json_string(subtitle)}, {"latestEpisode", json_string("")}}));
            }
        } catch (...) { /* Match Java's per-article exception tolerance. */ }
    }

    if (anime_items.empty()) {
        const auto links = select(env, doc, "a[href]:has(img)");
        for (jobject link : links) {
            try {
                std::string url = abs_url(env, link, "href");
                if (url.empty()) url = attr(env, link, "href");
                if (!likely_anime_url(url) || !seen_urls.insert(url).second) continue;
                jobject img = select_first(env, link, "img");
                std::string title = first_nonempty({attr(env, link, "title"), img ? attr(env, img, "alt") : "", text(env, link)});
                title = clean_title(title);
                if (title.empty()) continue;
                const std::string image = parse_image_url(env, link);
                // The shared helper contract exposes CSS selection but not parent traversal;
                // link text remains the available input to the same episode-label regex.
                const std::string subtitle = extract_episode_text(text(env, link));
                anime_items.push_back(json_object({{"title", json_string(title)}, {"url", json_string(url)},
                    {"imageUrl", json_string(image)}, {"dubText", json_string(subtitle)}, {"latestEpisode", json_string("")}}));
            } catch (...) { /* Match Java's per-link exception tolerance. */ }
        }
    }

    std::vector<std::string> page_items;
    std::unordered_set<std::string> seen_pages;
    const auto page_links = select(env, doc, ".wp-pagenavi a.page, a.page-numbers, .pagination a, nav a[href*=/page/]");
    for (jobject link : page_links) {
        const std::string number = trim_copy(text(env, link));
        std::string url = abs_url(env, link, "href");
        if (url.empty()) url = attr(env, link, "href");
        if (!number.empty() && !url.empty() && numeric(number) && seen_pages.insert(url).second)
            page_items.push_back(json_object({{"pageNumber", json_string(number)}, {"url", json_string(url)}, {"isCurrent", json_bool(false)}}));
    }
    jobject current = select_first(env, doc, ".wp-pagenavi span.current, span.page-numbers.current, .pagination .current");
    if (current) {
        const std::string number = trim_copy(text(env, current));
        if (numeric(number)) page_items.push_back(json_object({{"pageNumber", json_string(number)}, {"url", json_string("")}, {"isCurrent", json_bool(true)}}));
    }
    return json_object({{"animeItems", json_array(anime_items)}, {"pageItems", json_array(page_items)}});
}

} // namespace

std::string parse_animemoji(JNIEnv* env, jobject doc, int operation,
                            const std::string& referer, int episode_number) {
    (void)referer;
    (void)episode_number;
    try {
        switch (operation) {
            case 1: {
                jobject og_title = select_first(env, doc, "meta[property=og:title]");
                std::string title = og_title ? attr(env, og_title, "content") : "";
                title = trim_copy(std::regex_replace(title, std::regex("[-–]\\s*AnimeMoji.*$"), ""));
                std::string image;
                jobject img = select_first(env, doc, "div.post-thumnail.ez-p-thum.mx-auto img");
                if (img) image = has_attr(env, img, "data-src") ? attr(env, img, "data-src") : attr(env, img, "src");
                const std::string url = base_uri(env, doc);
                return json_object({{"title", json_string(title)}, {"url", json_string(url)},
                                    {"imageUrl", json_string(image)}, {"episodes", json_array(parse_episodes(env, doc, image))}});
            }
            case 2:
                return json_array(parse_episodes(env, doc, referer));
            case 3:
                return json_object({{"url", json_string(parse_video(env, doc, referer))}});
            case 4:
                return parse_list(env, doc);
            default:
                return operation == 2 ? "[]" : operation == 3 ? "{\"url\":\"\"}" :
                       operation == 4 ? "{\"animeItems\":[],\"pageItems\":[]}" :
                       "{\"title\":\"\",\"url\":\"\",\"imageUrl\":\"\",\"episodes\":[]}";
        }
    } catch (...) {
        switch (operation) {
            case 2: return "[]";
            case 3: return "{\"url\":\"\"}";
            case 4: return "{\"animeItems\":[],\"pageItems\":[]}";
            default: return "{\"title\":\"\",\"url\":\"\",\"imageUrl\":\"\",\"episodes\":[]}";
        }
    }
}
