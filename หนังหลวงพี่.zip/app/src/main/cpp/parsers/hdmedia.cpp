#include "../native_common.h"

#include <algorithm>
#include <cctype>
#include <regex>
#include <string>
#include <vector>

namespace {

std::string trim(std::string value) {
    const auto first = std::find_if_not(value.begin(), value.end(), [](unsigned char c) { return std::isspace(c); });
    if (first == value.end()) return "";
    const auto last = std::find_if_not(value.rbegin(), value.rend(), [](unsigned char c) { return std::isspace(c); }).base();
    return std::string(first, last);
}

std::string episode_json(const std::string& title, const std::string& info_url,
                         const std::string& image_url, const std::string& video_url,
                         const std::string& referer, int number) {
    return json_object({{"title", json_string(title)}, {"infoUrl", json_string(info_url)},
                        {"imageUrl", json_string(image_url)}, {"videoUrl", json_string(video_url)},
                        {"referer", json_string(referer)}, {"episodeNumber", json_number(number)},
                        {"dataId", json_string("")}});
}

std::string meta_content(JNIEnv* env, jobject doc, const char* selector) {
    jobject el = select_first(env, doc, selector);
    return el ? attr(env, el, "content") : "";
}

int episode_number(const std::string& label, int fallback) {
    static const std::regex pattern(R"((?:EP|ตอน)[.\s]*(\d+))", std::regex_constants::icase);
    std::smatch match;
    if (std::regex_search(label, match, pattern)) {
        try { return std::stoi(match[1].str()); } catch (...) {}
    }
    return fallback;
}

// Exact parser selector order and fallback behavior from HdMediaParser.java.
std::string find_box_player_embed(JNIEnv* env, jobject doc) {
    jobject iframe = select_first(env, doc, "iframe[name=box-player]");
    if (iframe) {
        const std::string value = has_attr(env, iframe, "data-src") ? attr(env, iframe, "data-src") : attr(env, iframe, "src");
        if (!value.empty()) return value.rfind("//", 0) == 0 ? "https:" + value : value;
    }
    jobject link = select_first(env, doc, "a.player-1-btn-link");
    if (link) {
        const std::string value = attr(env, link, "href");
        if (!value.empty()) return value.rfind("//", 0) == 0 ? "https:" + value : value;
    }
    return "";
}

std::vector<std::string> extract_episodes(JNIEnv* env, jobject doc, const std::string& image) {
    std::vector<std::string> result;
    const std::string page = base_uri(env, doc);
    auto buttons = select(env, doc, "button.swicth-ep.mov_source");
    if (buttons.empty()) {
        if (!find_box_player_embed(env, doc).empty()) {
            std::string title = meta_content(env, doc, "meta[property=og:title]");
            if (title.empty()) title = "movie";
            result.push_back(episode_json(title, page, image, "", page, 1));
        }
        return result;
    }
    for (size_t i = 0; i < buttons.size(); ++i) {
        jobject button = buttons[i];
        const std::string label = trim(text(env, button));
        const std::string embed = attr(env, button, "data-link");
        if (!label.empty() && !embed.empty())
            result.push_back(episode_json(label, page, image, "", page,
                                           episode_number(label, static_cast<int>(i + 1))));
        if (button) env->DeleteLocalRef(button);
    }
    return result;
}

std::string playlist_url(JNIEnv* env, jobject doc, int requested_episode) {
    auto buttons = select(env, doc, "button.swicth-ep.mov_source");
    std::string embed;
    if (!buttons.empty()) {
        int target = requested_episode - 1;
        if (target < 0) target = 0;
        if (target < static_cast<int>(buttons.size())) embed = attr(env, buttons[static_cast<size_t>(target)], "data-link");
    }
    for (jobject button : buttons) if (button) env->DeleteLocalRef(button);
    if (embed.empty()) embed = find_box_player_embed(env, doc);
    if (embed.empty()) return "";
    if (embed.find(".m3u8") != std::string::npos) return embed;
    static const std::regex pattern(R"(/(?:embed|e)/([A-Za-z0-9_-]+))");
    std::smatch match;
    if (std::regex_search(embed, match, pattern)) return "https://vdohls.com/" + match[1].str() + "/playlist.m3u8";
    return "";
}

std::string base64_decode(const std::string& input) {
    static const std::string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string out;
    int value = 0, bits = -8;
    for (unsigned char c : input) {
        if (std::isspace(c)) continue;
        if (c == '=') break;
        const auto pos = chars.find(static_cast<char>(c));
        if (pos == std::string::npos) return "";
        value = (value << 6) + static_cast<int>(pos);
        bits += 6;
        if (bits >= 0) { out.push_back(static_cast<char>((value >> bits) & 0xff)); bits -= 8; }
    }
    return out;
}

std::string card_image(JNIEnv* env, jobject card) {
    jobject css_node = select_first(env, card, "[data-vip24hd-css]");
    if (!css_node) return "";
    const std::string css = base64_decode(attr(env, css_node, "data-vip24hd-css"));
    static const std::regex pattern(R"(background-image\s*:\s*url\(["']?([^"')]+)["']?\))");
    std::smatch match;
    if (!std::regex_search(css, match, pattern)) return "";
    std::string image = trim(match[1].str());
    return image.rfind("//", 0) == 0 ? "https:" + image : image;
}

std::string origin_of(const std::string& url) {
    const size_t scheme = url.find("://");
    if (scheme == std::string::npos) return "";
    const size_t end = url.find('/', scheme + 3);
    return end == std::string::npos ? url : url.substr(0, end);
}

std::string parse_list(JNIEnv* env, jobject doc) {
    std::vector<std::string> items, pages;
    const std::string page_url = base_uri(env, doc);
    const std::string site_base = origin_of(page_url);
    if (page_url.find("?s=") == std::string::npos) {
        int current_page = 1;
        static const std::regex page_pattern(R"(/page/(\d+)/)");
        std::smatch match;
        if (std::regex_search(page_url, match, page_pattern)) {
            try { current_page = std::stoi(match[1].str()); } catch (...) {}
        }
        int max_page = 0;
        auto page_links = select(env, doc, "a.page-numbers");
        for (jobject link : page_links) {
            const std::string href = abs_url(env, link, "href");
            auto begin = std::sregex_iterator(href.begin(), href.end(), page_pattern);
            for (auto it = begin; it != std::sregex_iterator(); ++it) {
                try { max_page = std::max(max_page, std::stoi((*it)[1].str())); } catch (...) {}
            }
            if (link) env->DeleteLocalRef(link);
        }
        if (max_page > 0) {
            std::string base = std::regex_replace(page_url, std::regex(R"(/page/\d+/)"), "");
            if (page_url.find("/category/") != std::string::npos) {
                if (base.empty() || base.back() != '/') base += '/';
            } else base = site_base + "/";
            for (int p = 1; p <= max_page; ++p) {
                const std::string url = p == 1 ? base : base + "page/" + std::to_string(p) + "/";
                pages.push_back(json_object({{"pageNumber", json_string(std::to_string(p))},
                    {"url", json_string(url)}, {"isCurrent", json_bool(p == current_page)}}));
            }
        }
    }

    auto cards = select(env, doc, "article.elementor-post");
    for (jobject card : cards) {
        std::string url, title;
        jobject post_title = select_first(env, card, "h3.elementor-post__title a");
        if (post_title) {
            url = abs_url(env, post_title, "href");
            title = trim(text(env, post_title));
        }
        if (url.empty()) {
            jobject link = select_first(env, card, "a[href]");
            if (link) {
                std::string candidate = abs_url(env, link, "href");
                if (!candidate.empty() && candidate.rfind(site_base + "/category/", 0) != 0) url = candidate;
            }
        }
        if (title.empty()) {
            auto headings = select(env, card, "div.elementor-heading-title");
            if (!headings.empty()) title = trim(text(env, headings.back()));
            for (jobject heading : headings) if (heading) env->DeleteLocalRef(heading);
        }
        if (!url.empty() && url.rfind(site_base + "/category/", 0) != 0 && !title.empty()) {
            items.push_back(json_object({{"title", json_string(title)}, {"url", json_string(url)},
                {"imageUrl", json_string(card_image(env, card))}, {"dubText", json_string("")},
                {"latestEpisode", json_string("")}}));
        }
        if (post_title) env->DeleteLocalRef(post_title);
        if (card) env->DeleteLocalRef(card);
    }
    return json_object({{"animeItems", json_array(items)}, {"pageItems", json_array(pages)}});
}

std::string empty_for(int operation) {
    if (operation == 2) return "[]";
    if (operation == 3) return json_object({{"url", json_string("")}});
    if (operation == 4) return json_object({{"animeItems", "[]"}, {"pageItems", "[]"}});
    return json_object({{"title", json_string("")}, {"url", json_string("")},
                        {"imageUrl", json_string("")}, {"episodes", "[]"}});
}

} // namespace

std::string parse_hdmedia(JNIEnv* env, jobject doc, int operation,
                          const std::string& referer, int episode_number) {
    try {
        if (!doc) return empty_for(operation);
        if (operation == 1) {
            std::string title = meta_content(env, doc, "meta[property=og:title]");
            if (title.empty()) title = "24HD Media";
            const std::string image = meta_content(env, doc, "meta[property=og:image]");
            return json_object({{"title", json_string(title)}, {"url", json_string(base_uri(env, doc))},
                {"imageUrl", json_string(image)}, {"episodes", json_array(extract_episodes(env, doc, image))}});
        }
        if (operation == 2) return json_array(extract_episodes(env, doc, referer));
        if (operation == 3) return json_object({{"url", json_string(playlist_url(env, doc, episode_number))}});
        if (operation == 4) {
            // WordPress REST post/category/media requests remain Java networking; this parses only supplied HTML.
            return parse_list(env, doc);
        }
    } catch (...) {
        // Never propagate C++ exceptions through JNI.
    }
    return empty_for(operation);
}
