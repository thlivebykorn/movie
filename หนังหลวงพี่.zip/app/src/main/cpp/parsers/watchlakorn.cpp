#include "../native_common.h"

#include <regex>
#include <string>
#include <vector>

namespace {
using anime_native::json_array;
using anime_native::json_bool;
using anime_native::json_number;
using anime_native::json_object;
using anime_native::json_string;
using anime_native::select;
using anime_native::select_first;
using anime_native::text;
using anime_native::attr;
using anime_native::abs_url;
using anime_native::base_uri;
using anime_native::has_attr;

const std::string kFallbackDomain = "www.watchlakorn.org";
const std::string kHome = "https://www.watchlakorn.org/";

std::string item_json(const std::string& title, const std::string& url,
                      const std::string& image, const std::string& dub,
                      const std::string& latest) {
    return json_object({{"title", json_string(title)}, {"url", json_string(url)},
                        {"imageUrl", json_string(image)}, {"dubText", json_string(dub)},
                        {"latestEpisode", json_string(latest)}});
}
std::string page_json(const std::string& number, const std::string& url, bool current) {
    return json_object({{"pageNumber", json_string(number)}, {"url", json_string(url)},
                        {"isCurrent", json_bool(current)}});
}
std::string episode_json(const std::string& title, const std::string& info,
                         const std::string& image, const std::string& video,
                         const std::string& ref, int number, const std::string& data = "") {
    return json_object({{"title", json_string(title)}, {"infoUrl", json_string(info)},
                        {"imageUrl", json_string(image)}, {"videoUrl", json_string(video)},
                        {"referer", json_string(ref)}, {"episodeNumber", json_number(number)},
                        {"dataId", json_string(data)}});
}
std::string empty_list() {
    return json_object({{"animeItems", json_array({})}, {"pageItems", json_array({})}});
}
std::vector<std::string> legacy_episodes(JNIEnv* env, jobject doc, const std::string& image) {
    std::vector<std::string> out;
    const std::string url = base_uri(env, doc);
    std::smatch match;
    if (std::regex_search(url, match, std::regex("-cm-([0-9]+)"))) {
        // TODO(network): Java loads ajax.php?module=movie_select (including every st= page).
        // The supplied Document is only the original page, so episode-grid results cannot be fabricated.
        return out;
    }
    jobject og = select_first(env, doc, "meta[property=og:title]");
    std::string title = og ? attr(env, og, "content") : "";
    if (title.empty()) title = "วิดีโอ";
    out.push_back(episode_json(title, url, image, "", kHome, 1));
    return out;
}
std::string old_video(JNIEnv* env, jobject doc) {
    jobject meta = select_first(env, doc, "meta[itemprop=contentUrl]");
    if (meta) {
        std::string content = attr(env, meta, "content");
        if (!content.empty()) {
            if (content.rfind("http", 0) == 0) return content;
            std::string sd = "https://" + kFallbackDomain + "/" + content;
            std::string hd = sd;
            const std::string token = "c2Q=/master.m3u8";
            const std::string replacement = "aGQ=/master.m3u8";
            auto pos = hd.find(token);
            if (pos != std::string::npos) {
                hd.replace(pos, token.size(), replacement);
                // TODO(network): original checks HD with HEAD; no network probe in native parser.
            }
            return sd;
        }
    }
    meta = select_first(env, doc, "meta[name=file]");
    if (meta) {
        std::string file = attr(env, meta, "content");
        if (!file.empty()) return file.rfind("http", 0) == 0 ? file : "https://" + kFallbackDomain + "/" + file;
    }
    // Parsing Document's HTML is kept local; regexes mirror the legacy player fallback.
    jclass cls = env->GetObjectClass(doc);
    jmethodID html_mid = cls ? env->GetMethodID(cls, "html", "()Ljava/lang/String;") : nullptr;
    std::string html;
    if (html_mid) html = anime_native::from_jstring(env, static_cast<jstring>(env->CallObjectMethod(doc, html_mid)));
    if (cls) env->DeleteLocalRef(cls);
    std::smatch m;
    if (std::regex_search(html, m, std::regex("\\\"file\\\"\\s*:\\s*\\\"([^\\\"]+\\.m3u8)\\\"", std::regex::icase))) {
        std::string value = m[1].str();
        std::size_t p = 0; while ((p = value.find("\\/", p)) != std::string::npos) value.replace(p, 2, "/");
        return value;
    }
    if (std::regex_search(html, m, std::regex("sources:\\s*\\[\\s*\\{\\s*file:\\s*\\\"([^\\\"]+\\.m3u8)\\\"", std::regex::icase))) {
        std::string value = m[1].str();
        std::size_t p = 0; while ((p = value.find("\\/", p)) != std::string::npos) value.replace(p, 2, "/");
        return value;
    }
    if (std::regex_search(html, m, std::regex("(https?://[^\\s\\\"']+\\.m3u8[^\\s\\\"']*)", std::regex::icase))) return m[1].str();
    return "";
}
}

std::string parse_watchlakorn(JNIEnv* env, jobject doc, int operation,
                              const std::string& referer, int episode_number) {
    try {
        if (!doc) {
            if (operation == 4) return empty_list();
            if (operation == 3) return json_object({{"url", json_string("")}});
            if (operation == 2) return json_array({});
            return json_object({{"title", json_string("")}, {"url", json_string("")},
                                {"imageUrl", json_string("")}, {"episodes", json_array({})}});
        }
        const std::string url = base_uri(env, doc);
        if (operation == 3) {
            // New API get_player and content_jw6 require HTTP/JSON fetches; keep no fabricated stream.
            if (url.find("api.php?action=get_player") != std::string::npos || url.find("content_jw6.php") != std::string::npos) {
                // TODO(network): Java fetches API/JWPlayer playlist, resolves stream aliases and probes HLS.
                return json_object({{"url", json_string("")}});
            }
            return json_object({{"url", json_string(old_video(env, doc))}});
        }
        if (operation == 2) return json_array(legacy_episodes(env, doc, referer));
        if (operation == 1) {
            // TODO(network): get_series_detail/get_player HTML-base URLs are fetched as JSON in Java.
            std::string title, image;
            jobject node = select_first(env, doc, "meta[property=og:title]");
            if (node) title = attr(env, node, "content");
            node = select_first(env, doc, "meta[property=og:image]");
            if (node) image = attr(env, node, "content");
            return json_object({{"title", json_string(title)}, {"url", json_string(url)},
                                {"imageUrl", json_string(image)},
                                {"episodes", json_array(legacy_episodes(env, doc, image))}});
        }
        if (operation == 4) {
            std::vector<jobject> grids = select(env, doc, "div.grids");
            if (grids.empty()) grids = select(env, doc, "div[id^=vid_view_]");
            if (grids.empty()) grids = select(env, doc, "div[id^=vid_wrap_]");
            std::vector<std::string> items, pages;
            for (jobject grid : grids) {
                jobject link = select_first(env, grid, "div.view_thumb a, div.vid_thumb a");
                if (!link) continue;
                std::string item_url = abs_url(env, link, "href");
                if (item_url.empty()) continue;
                jobject img = select_first(env, link, "img");
                std::string image;
                if (img) image = has_attr(env, img, "data-src") ? abs_url(env, img, "data-src") : abs_url(env, img, "src");
                if (image.rfind("//", 0) == 0) image = "https:" + image;
                jobject title_link = select_first(env, grid, "div.view_info_wrap h2.title a, div.vid_info_wrap h2.title a");
                std::string item_title;
                if (title_link) {
                    item_title = text(env, title_link);
                    jobject span = select_first(env, title_link, "span.title");
                    if (span) item_title = text(env, span);
                }
                if (!item_title.empty()) items.push_back(item_json(item_title, item_url, image, "", ""));
            }
            jobject load = select_first(env, doc, "#loadmore");
            if (load && !grids.empty()) {
                std::string onclick = attr(env, load, "onclick");
                std::smatch sm;
                if (onclick.find("&st=") != std::string::npos && items.size() > 0) {
                    int next_st = 0, current_st = 0;
                    if (std::regex_search(onclick, sm, std::regex("&st=([0-9]+)"))) next_st = std::stoi(sm[1].str());
                    std::string name, group;
                    if (std::regex_search(onclick, sm, std::regex("loadshows\\(\\s*'([^']+)'") )) name = sm[1].str();
                    if (std::regex_search(onclick, sm, std::regex("loadshows\\(\\s*'[^']+'\\s*,\\s*'([^']+)'") )) group = sm[1].str();
                    if (std::regex_search(url, sm, std::regex("st=([0-9]+)"))) current_st = std::stoi(sm[1].str());
                    if (items.size() >= 25) {
                        int known_pages = next_st / 25 + 1;
                        for (int p = 0; p < known_pages; ++p) {
                            int st = p * 25;
                            std::string page_url = "https://" + kFallbackDomain + "/ajax.php?module=loadshows&name=" + name + "&group=" + group + "&category=&searchby=&st=" + std::to_string(st);
                            pages.push_back(page_json(std::to_string(p + 1), page_url, st == current_st));
                        }
                    }
                }
            }
            return json_object({{"animeItems", json_array(items)}, {"pageItems", json_array(pages)}});
        }
    } catch (...) {
        // Never allow native exceptions to cross the JNI boundary.
    }
    if (operation == 4) return empty_list();
    if (operation == 3) return json_object({{"url", json_string("")}});
    if (operation == 2) return json_array({});
    return json_object({{"title", json_string("")}, {"url", json_string("")},
                        {"imageUrl", json_string("")}, {"episodes", json_array({})}});
}
