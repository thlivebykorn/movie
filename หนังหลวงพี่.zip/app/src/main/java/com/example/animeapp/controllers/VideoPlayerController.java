package com.example.animeapp.controllers;

import android.content.Context;
import android.media.audiofx.LoudnessEnhancer;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageButton;
import android.widget.Toast;
import android.widget.TextView;

import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;
import androidx.media3.exoplayer.hls.HlsMediaSource;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.ui.PlayerView;

import com.example.animeapp.R;
import com.example.animeapp.activities.VideoPlayerActivity;
import com.example.animeapp.audio.AudioEffectManager;
import com.example.animeapp.domain.DomainConfig;
import com.example.animeapp.models.Episode;
import com.example.animeapp.network.AnimeApiClient;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class VideoPlayerController {

    private ExoPlayer            player;
    private DefaultTrackSelector trackSelector;
    private AudioEffectManager   audioEffectManager;
   
    private LoudnessEnhancer     loudnessEnhancer;
    private PlayerView           playerView;
    private Context              context;
    private List<Episode>        episodes;
    private int                  currentEpisodeIndex;
    private ImageButton          prevEpisodeButton;
    private ImageButton          nextEpisodeButton;
    private TextView             videoTitleView;
    private android.widget.ProgressBar bufferProgressBar;
    private EpisodeChangeListener episodeChangeListener;
    private final Handler         mainHandler = new Handler(Looper.getMainLooper());

    private boolean hasStarted        = false;
    private boolean shouldLoadPos     = true;
    private String  currentEpisodeUrl = "";

    
    private static final int VOLUME_BOOST_GAIN_MB = 1500;

    public interface EpisodeChangeListener {
        void onEpisodeChanged(int newEpisodeIndex);
    }

    public void setEpisodeChangeListener(EpisodeChangeListener listener) {
        this.episodeChangeListener = listener;
    }

    public void setBufferProgressBar(android.widget.ProgressBar bar) {
        this.bufferProgressBar = bar;
    }

    private final Player.Listener bufferListener = new Player.Listener() {
        @Override
        public void onPlaybackStateChanged(int state) {
            if (bufferProgressBar == null) return;
            mainHandler.post(() -> bufferProgressBar.setVisibility(
                state == Player.STATE_BUFFERING
                    ? android.view.View.VISIBLE
                    : android.view.View.GONE));
        }
    };

    private boolean eqInitialized = false;

    private final Player.Listener permanentListener = new Player.Listener() {
        @Override
        public void onPlaybackStateChanged(int state) {
            if (state == Player.STATE_READY && !hasStarted) {
                hasStarted = true;

               
                if (!eqInitialized) {
                    int sessionId = player.getAudioSessionId();
                    if (sessionId != 0) {
                        eqInitialized = true;

                      
                        audioEffectManager = new AudioEffectManager(context);
                        audioEffectManager.init(sessionId);

                       
                        applyVolumeBoost(sessionId);
                    }
                }

                android.content.SharedPreferences sp2 = context.getSharedPreferences(
                    "AnimeAppPrefs", android.content.Context.MODE_PRIVATE);
                boolean resume = sp2.getBoolean("resume_playback", true);

               
                int skipIntroSec = sp2.getInt("skip_intro_seconds", 0);
                if (skipIntroSec > 0) {
                    long skipMs = skipIntroSec * 1000L;
                  
                    if (!resume || !shouldLoadPos) {
                        player.seekTo(skipMs);
                    } else {
                       
                        mainHandler.postDelayed(() -> {
                            if (player != null) {
                                long pos = player.getCurrentPosition();
                                if (pos < skipMs) player.seekTo(skipMs);
                            }
                        }, 200);
                    }
                }

                if (resume && shouldLoadPos && context instanceof VideoPlayerActivity) {
                    ((VideoPlayerActivity) context)
                        .loadPlaybackPositionForEpisode(currentEpisodeUrl);
                }
                player.play();
                if (context instanceof VideoPlayerActivity) {
                    ((VideoPlayerActivity) context).scheduleControllerAutoHide();
                }
            }
            if (state == Player.STATE_ENDED) {
                android.content.SharedPreferences sp = context.getSharedPreferences(
                    "AnimeAppPrefs", android.content.Context.MODE_PRIVATE);
                boolean autoNext = sp.getBoolean("auto_next_episode", true);
                int next = currentEpisodeIndex + 1;
                if (autoNext && episodes != null && next < episodes.size()) {
                    mainHandler.post(() -> changeEpisode(next, false));
                }
            }
        }
        @Override
        public void onIsPlayingChanged(boolean isPlaying) {
            if (context instanceof VideoPlayerActivity) {
                ((VideoPlayerActivity) context).updatePipActions();
            }
        }
    };

  
    public VideoPlayerController(Context context, PlayerView playerView,
                                 List<Episode> episodes, int currentEpisodeIndex) {
        this.context             = context;
        this.playerView          = playerView;
        this.episodes            = episodes;
        this.currentEpisodeIndex = currentEpisodeIndex;

        trackSelector = new DefaultTrackSelector(context);

       
        android.content.SharedPreferences sp = context.getSharedPreferences(
            "AnimeAppPrefs", android.content.Context.MODE_PRIVATE);
        boolean hwAccel = sp.getBoolean("hardware_accel", true);

        DefaultRenderersFactory renderersFactory = new DefaultRenderersFactory(context)
            .setExtensionRendererMode(
                hwAccel
                    ? DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER
                    : DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF);

        player = new ExoPlayer.Builder(context, renderersFactory)
            .setTrackSelector(trackSelector)
            .setAudioAttributes(
                new AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                true)
            .setHandleAudioBecomingNoisy(true)
            .build();

        playerView.setPlayer(player);
        player.addListener(permanentListener);
        player.addListener(bufferListener);

        audioEffectManager = new AudioEffectManager(context);
    }

    public ExoPlayer            getPlayer()             { return player; }
    public DefaultTrackSelector getTrackSelector()      { return trackSelector; }
    public AudioEffectManager   getAudioEffectManager() { return audioEffectManager; }

   
    private void applyVolumeBoost(int audioSessionId) {
        android.content.SharedPreferences sp = context.getSharedPreferences(
            "AnimeAppPrefs", android.content.Context.MODE_PRIVATE);
        boolean boost = sp.getBoolean("volume_boost", false);

        try {
            if (loudnessEnhancer != null) {
                loudnessEnhancer.release();
                loudnessEnhancer = null;
            }
            loudnessEnhancer = new LoudnessEnhancer(audioSessionId);
            if (boost) {
                loudnessEnhancer.setTargetGain(VOLUME_BOOST_GAIN_MB);
                loudnessEnhancer.setEnabled(true);
            } else {
                loudnessEnhancer.setEnabled(false);
            }
        } catch (Exception e) {
           
            loudnessEnhancer = null;
        }
    }

  
    public void setVolumeBoost(boolean enabled) {
        if (loudnessEnhancer == null) return;
        try {
            if (enabled) {
                loudnessEnhancer.setTargetGain(VOLUME_BOOST_GAIN_MB);
                loudnessEnhancer.setEnabled(true);
            } else {
                loudnessEnhancer.setEnabled(false);
            }
        } catch (Exception ignored) {}
    }

   
    public void initializePlayer(Episode episode) {
        initializePlayer(episode, true);
    }

    public void initializePlayer(Episode episode, boolean loadPosition) {
        hasStarted        = false;
        eqInitialized     = false;   
        shouldLoadPos     = loadPosition;
        currentEpisodeUrl = episode.getInfoUrl();

       
        android.content.SharedPreferences sp = context.getSharedPreferences(
            "AnimeAppPrefs", android.content.Context.MODE_PRIVATE);

       
        float speed = sp.getFloat("default_playback_speed", 1.0f);
        if (player != null) player.setPlaybackSpeed(speed);

       
        if (context instanceof android.app.Activity) {
            android.view.Window win = ((android.app.Activity) context).getWindow();
            if (sp.getBoolean("keep_screen_on", true))
                win.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else
                win.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
        
        String videoUrl = episode.getVideoUrl();
        String referer = episode.getReferer();

        if (videoUrl != null && isConfiguredGetplayStreamUrl(videoUrl)) {
            String id = extractGetplayId(videoUrl);
            if (id != null) {
                referer = "https://getplay-cdn.com/embed/" + id;
            }
        }

        if (videoUrl != null && videoUrl.contains("getplay-cdn.com/api/stream/")) {
            java.util.regex.Matcher m =
                    java.util.regex.Pattern.compile("getplay-cdn\\.com/api/stream/([A-Za-z0-9_-]+)")
                            .matcher(videoUrl);
            if (m.find()) {
                referer = "https://getplay-cdn.com/embed/" + m.group(1);
            }
        }

        if (videoUrl != null && videoUrl.contains("ok-hd.com/api/stream/")) {
            java.util.regex.Matcher m =
                    java.util.regex.Pattern.compile("ok-hd\\.com/api/stream/([A-Za-z0-9_-]+)")
                            .matcher(videoUrl);
            if (m.find()) {
                referer = "https://ok-hd.com/embed/" + m.group(1);
            }
        }

        if (videoUrl != null && videoUrl.contains("moddepp.com/api/stream/")) {
            java.util.regex.Matcher m =
                    java.util.regex.Pattern.compile("moddepp\\.com/api/stream/([A-Za-z0-9_-]+)")
                            .matcher(videoUrl);
            if (m.find()) {
                referer = "https://moddepp.com/embed/" + m.group(1);
            }
        }

        if (videoUrl != null && videoUrl.contains("torbo007.com/api/stream/")) {
            java.util.regex.Matcher m =
                    java.util.regex.Pattern.compile("torbo007\\.com/api/stream/([A-Za-z0-9]{20,})")
                            .matcher(videoUrl);

            if (m.find()) {
                referer = "https://torbo007.com/embed/" + m.group(1);
            }
        }

        if (videoUrl != null && videoUrl.contains("vdohls.com")) {
           
            referer = "https://player77hdfree.xyz/";
        }

        
        DefaultHttpDataSource.Factory dsFactory = new DefaultHttpDataSource.Factory();
        Map<String, String> headers = new HashMap<>();
        headers.put("Referer", referer != null ? referer : "");
        headers.put("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36");
        dsFactory.setDefaultRequestProperties(headers);

        MediaItem mediaItem = new MediaItem.Builder().setUri(videoUrl).build();
        MediaSource mediaSource = (videoUrl.contains(".m3u8") || videoUrl.contains(".txt"))
            ? new HlsMediaSource.Factory(dsFactory).createMediaSource(mediaItem)
            : new ProgressiveMediaSource.Factory(dsFactory).createMediaSource(mediaItem);

        player.pause();
        player.setMediaSource(mediaSource);
        player.prepare();
    }

    private String getConfiguredStreamHost() {
        try {
            return java.net.URI.create(DomainConfig.ApiUrl.GETPLAY_STREAM_API()).getHost();
        } catch (Exception e) {
            return "";
        }
    }

    private String extractGetplayId(String videoUrl) {
        String marker = DomainConfig.ApiUrl.GETPLAY_STREAM_API();
        int start = videoUrl.indexOf(marker);
        if (start < 0) return null;
        start += marker.length();
        int end = videoUrl.indexOf('/', start);
        if (end <= start) return null;
        return videoUrl.substring(start, end);
    }

    private boolean isConfiguredGetplayStreamUrl(String videoUrl) {
        String streamApi = DomainConfig.ApiUrl.GETPLAY_STREAM_API();
        return videoUrl.startsWith(streamApi);
    }

   
    private void changeEpisode(int newIndex, boolean shouldLoadPosition) {
        if (newIndex < 0 || newIndex >= episodes.size()) return;
        if (newIndex == currentEpisodeIndex) return;
        saveCurrentPosition();
        currentEpisodeIndex = newIndex;
        if (episodeChangeListener != null)
            episodeChangeListener.onEpisodeChanged(currentEpisodeIndex);
        loadAndPlay(currentEpisodeIndex, shouldLoadPosition);
    }

    private void loadAndPlay(int index, boolean shouldLoadPosition) {
        Episode episode = episodes.get(index);
        updateNavigationButtons();
        if (videoTitleView != null) videoTitleView.setText(episode.getTitle());

        String currentUrl = episode.getVideoUrl();
        if (currentUrl != null && !currentUrl.isEmpty()
                && !AnimeApiClient.isGetplayStreamWithoutToken(currentUrl)) {
            initializePlayer(episode, shouldLoadPosition);
            return;
        }

        Toast.makeText(context, "กำลังโหลดลิงก์วิดีโอ...", Toast.LENGTH_SHORT).show();
        final boolean finalLoad = shouldLoadPosition;
        final int     thisIndex = index;

        new Thread(() -> {
            try {
                String sourceUrl = (currentUrl != null && !currentUrl.isEmpty())
                        ? currentUrl : episode.getInfoUrl();
                String videoUrl = AnimeApiClient.fetchVideoUrl(
                    sourceUrl, episode.getReferer(), episode.getEpisodeNumber());
                mainHandler.post(() -> {
                    if (currentEpisodeIndex != thisIndex) return;
                    if (videoUrl != null && !videoUrl.isEmpty()) {
                        episode.setVideoUrl(videoUrl);
                        initializePlayer(episode, finalLoad);
                        updateNavigationButtons();
                        if (videoTitleView != null) videoTitleView.setText(episode.getTitle());
                    } else {
                        Toast.makeText(context, "ไม่สามารถดึงลิงก์วิดีโอได้", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                mainHandler.post(() ->
                    Toast.makeText(context, "เกิดข้อผิดพลาดในการโหลดลิงก์", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    public void playNextEpisode() {
        if (episodes == null || currentEpisodeIndex >= episodes.size() - 1) {
            Toast.makeText(context, "ไม่มีตอนถัดไป", Toast.LENGTH_SHORT).show(); return;
        }
        changeEpisode(currentEpisodeIndex + 1, false);
    }

    public void playPreviousEpisode() {
        if (currentEpisodeIndex <= 0) {
            Toast.makeText(context, "ไม่มีตอนก่อนหน้า", Toast.LENGTH_SHORT).show(); return;
        }
        changeEpisode(currentEpisodeIndex - 1, false);
    }

    public void playEpisode(int index)              { changeEpisode(index, true); }
    public void playEpisode(int index, boolean load){ changeEpisode(index, load); }

   
    private void saveCurrentPosition() {
        if (player == null || currentEpisodeIndex < 0 || currentEpisodeIndex >= episodes.size()) return;
        long pos = player.getCurrentPosition();
        if (pos <= 0) return;
        Episode ep = episodes.get(currentEpisodeIndex);
        if (context instanceof VideoPlayerActivity)
            ((VideoPlayerActivity) context).savePlaybackPositionDirect(ep.getInfoUrl(), pos);
    }

  
    public void setupNavigationButtons(ImageButton prev, ImageButton next, TextView title) {
        this.prevEpisodeButton = prev;
        this.nextEpisodeButton = next;
        this.videoTitleView    = title;
        updateNavigationButtons();
    }

    private void updateNavigationButtons() {
        if (prevEpisodeButton == null || nextEpisodeButton == null) return;
        boolean hasPrev = currentEpisodeIndex > 0;
        boolean hasNext = episodes != null && currentEpisodeIndex < episodes.size() - 1;
        prevEpisodeButton.setImageResource(hasPrev
            ? R.drawable.ic_skip_previous : R.drawable.ic_prev_episode_inactive);
        prevEpisodeButton.setEnabled(hasPrev);
        prevEpisodeButton.setAlpha(hasPrev ? 1f : 0.5f);
        nextEpisodeButton.setImageResource(hasNext
            ? R.drawable.ic_skip_next : R.drawable.ic_next_episode_inactive);
        nextEpisodeButton.setEnabled(hasNext);
        nextEpisodeButton.setAlpha(hasNext ? 1f : 0.5f);
    }

  
    public long getSeekDurationMs() {
        android.content.SharedPreferences sp = context.getSharedPreferences(
            "AnimeAppPrefs", android.content.Context.MODE_PRIVATE);
        return sp.getInt("seek_duration_sec", 10) * 1000L;
    }
    public void seekBackward(long ms) { if (player != null) player.seekTo(Math.max(0, player.getCurrentPosition() - ms)); }
    public void seekForward(long ms)  { if (player != null) player.seekTo(player.getCurrentPosition() + ms); }
    public void pausePlayer()         { if (player != null && player.isPlaying()) player.pause(); }

   
    public void releasePlayer() {
        mainHandler.removeCallbacksAndMessages(null);
        if (audioEffectManager != null) audioEffectManager.release();
       
        try {
            if (loudnessEnhancer != null) {
                loudnessEnhancer.release();
                loudnessEnhancer = null;
            }
        } catch (Exception ignored) {}
        if (player != null) {
            player.removeListener(permanentListener);
            player.removeListener(bufferListener);
            player.stop();
            player.release();
            player = null;
        }
    }

    public void detachFromActivity() {}

    public void attachToActivity() {
        if (player != null) playerView.setPlayer(player);
    }
}
