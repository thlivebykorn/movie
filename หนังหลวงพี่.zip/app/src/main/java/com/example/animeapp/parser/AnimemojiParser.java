package com.example.animeapp.parser;

import org.jsoup.nodes.Document;
import com.example.animeapp.models.Anime;
import java.util.List;
import com.example.animeapp.models.Episode;
import com.example.animeapp.network.OkHttpClientFactory;
import java.io.IOException;
import java.util.ArrayList;
import org.jsoup.select.Elements;
import org.jsoup.nodes.Element;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

import org.json.JSONArray;
import org.json.JSONObject;

import okhttp3.OkHttpClient;
import com.example.animeapp.domain.DomainConfig;

public class AnimemojiParser implements AnimeParser {
    
    private final OkHttpClient client;
    
    public AnimemojiParser() {
        this.client = OkHttpClientFactory.getClientWithDoH();
    }
    
    @Override
    public Anime parseAnimeDetail(Document doc) {
        return com.example.animeapp.parser.NativeParseBridge.parseAnimeDetail("animemoji", doc);
    }

    @Override
    public List<Episode> parseEpisodes(Document doc, String imageUrl) {
        return com.example.animeapp.parser.NativeParseBridge.parseEpisodes("animemoji", doc, imageUrl);
    }

    @Override
    public String parseVideoUrl(Document epDoc, String referer, int episodeNumber) throws IOException {
        return com.example.animeapp.parser.NativeParseBridge.parseVideoUrl("animemoji", epDoc, referer, episodeNumber);
    }
}
