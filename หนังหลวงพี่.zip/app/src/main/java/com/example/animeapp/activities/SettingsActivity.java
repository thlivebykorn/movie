package com.example.animeapp.activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.WindowCompat;

import com.example.animeapp.R;
import com.example.animeapp.auth.SessionManager;
import com.example.animeapp.database.DatabaseHelper;
import com.example.animeapp.domain.DomainConfig;
import com.example.animeapp.model.Source;
import com.example.animeapp.network.ServerApiClient;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.switchmaterial.SwitchMaterial;

import java.io.File;
import java.util.List;

public class SettingsActivity extends AppCompatActivity {

    public static final String PREFS = "AnimeAppPrefs";

    
    public static final String KEY_DEFAULT_SPEED     = "default_playback_speed";
    public static final String KEY_AUTO_NEXT          = "auto_next_episode";
    public static final String KEY_RESUME_PLAYBACK    = "resume_playback";
    public static final String KEY_GRID_COLUMNS       = "grid_columns";
    public static final String KEY_EPISODE_SORT       = "episode_sort_desc";
    public static final String KEY_SHOW_EPISODE_NUM   = "show_episode_number";
    public static final String KEY_PLAYER_GESTURE     = "player_gesture";
    public static final String KEY_SEEK_DURATION      = "seek_duration_sec";
    public static final String KEY_NOTIFY_NEW_EP      = "notify_new_episode";
    public static final String KEY_CACHE_SIZE_MB      = "cache_size_mb";
    public static final String KEY_USE_DOH            = "use_doh";
    public static final String KEY_KEEP_SCREEN_ON     = "keep_screen_on";
    public static final String KEY_HARDWARE_ACCEL     = "hardware_accel";
    public static final String KEY_PIP_AUTO           = "pip_auto";
    public static final String KEY_SHOW_HISTORY        = "show_history_section";
    public static final String KEY_SKIP_INTRO         = "skip_intro_seconds";

    private SharedPreferences prefs;
    private DatabaseHelper dbHelper;
    private LinearLayout container;

    public static void start(Context context) {
        context.startActivity(new Intent(context, SettingsActivity.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_settings);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        dbHelper = new DatabaseHelper(this);
        container = findViewById(R.id.settings_container);

        buildModernSettings();
    }

    private void buildModernSettings() {
        container.removeAllViews();

       
        addSectionHeader("🌐 แหล่งข้อมูล");
        addDefaultSourceSetting();

       
        addSectionHeader("🎬 การเล่นวิดีโอ");
        addSpeedSetting();
        addSeekDurationSetting();
        addSkipIntroSetting();
        addSwitchRow("เล่นตอนถัดไปอัตโนมัติ", "เมื่อจบตอนจะข้ามไปตอนถัดไปทันที", KEY_AUTO_NEXT, true);
        addSwitchRow("จำตำแหน่งการเล่น", "ดูต่อจากจุดเดิมที่ค้างไว้", KEY_RESUME_PLAYBACK, true);
        addSwitchRow("PIP อัตโนมัติ", "เปิดหน้าจอเล็กเมื่อกดปุ่ม Home", KEY_PIP_AUTO, true);
        addSwitchRow("ควบคุมด้วยการปัด (Gesture)", "ปัดเพื่อปรับเสียง/แสง/กรอวิดีโอ", KEY_PLAYER_GESTURE, true);
        addSwitchRow("หน้าจอไม่ดับขณะดู", "ป้องกันจอพักระหว่างเล่นวิดีโอ", KEY_KEEP_SCREEN_ON, true);
        addSwitchRow("Hardware Acceleration", "ใช้ GPU เร่งความเร็ววิดีโอ", KEY_HARDWARE_ACCEL, true);

       
        addSectionHeader("🎨 การแสดงผล");
        addGridColumnsSetting();
        addSwitchRow("แสดงประวัติในหน้าหลัก", "แสดงแถบ 'ดูต่อ' ด้านบนสุด", KEY_SHOW_HISTORY, false);
        addSwitchRow("แสดงเลขตอนบนปก", "แสดงหมายเลขตอนบนภาพหน้าปก", KEY_SHOW_EPISODE_NUM, true);
        addSwitchRow("เรียงตอนใหม่ไปเก่า", "เอาตอนล่าสุดไว้ด้านบนสุด", KEY_EPISODE_SORT, false);

       
        addSectionHeader("🔔 การแจ้งเตือน");
        addSwitchRow("แจ้งเตือนตอนใหม่", "รับแจ้งเตือนเมื่อรายการโปรดมีตอนใหม่", KEY_NOTIFY_NEW_EP, true);
        addBatteryOptSetting();

      
        addSectionHeader("⚙️ ระบบและเครือข่าย");
        addSwitchRowWithCallback("DNS over HTTPS (DoH)", "ช่วยให้โหลดข้อมูลได้เสถียรขึ้น", KEY_USE_DOH, true, checked -> {
            com.example.animeapp.network.OkHttpClientFactory.resetClients();
            Toast.makeText(this, checked ? "✅ เปิด DoH แล้ว" : "❌ ปิด DoH แล้ว", Toast.LENGTH_SHORT).show();
        });
        addCacheSizeSetting();

       
        addSectionHeader("🗂️ การจัดการข้อมูล");
        addActionRow("🗑️ ล้างประวัติการดู", "ลบประวัติการเล่นทั้งหมดถาวร", this::confirmClearHistory);
        addActionRow("💾 ล้าง Cache", "ลบไฟล์ขยะชั่วคราวเพื่อให้แอปเบาขึ้น", this::confirmClearCache);

       
        addSectionHeader("👤 บัญชี");
        addActionRow("🚪 ออกจากระบบ", "ออกจากระบบและกลับไปหน้าเข้าสู่ระบบ", this::confirmLogout);

      
        addSectionHeader("ℹ️ เกี่ยวกับแอป");
        addInfoRow("เวอร์ชันแอป", getAppVersion());
        addInfoRow("ผู้พัฒนา", "หลวงพี่");
    }

    private void addSectionHeader(String title) {
        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextColor(Color.parseColor("#B88EF5"));
        tv.setTextSize(14f);
        tv.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(8), dp(24), dp(8), dp(8));
        tv.setLayoutParams(lp);
        container.addView(tv);
    }

    private void addSwitchRow(String title, String sub, String key, boolean def) {
        addSwitchRowWithCallback(title, sub, key, def, null);
    }

    private void addSwitchRowWithCallback(String title, String sub, String key, boolean def, BoolCallback callback) {
        MaterialCardView card = createItemCard();
        LinearLayout layout = createItemBaseLayout();
        LinearLayout textGroup = createTextGroup(title, sub);
        
        SwitchMaterial sw = new SwitchMaterial(this);
        sw.setChecked(prefs.getBoolean(key, def));
        sw.setClickable(false);
        sw.setFocusable(false);

        layout.addView(textGroup);
        layout.addView(sw);
        card.addView(layout);

        card.setOnClickListener(v -> {
            boolean newVal = !sw.isChecked();
            sw.setChecked(newVal);
            prefs.edit().putBoolean(key, newVal).apply();
            if (callback != null) callback.onChanged(newVal);
        });

        container.addView(card);
    }

    private void addDefaultSourceSetting() {
        List<Source> sources = DomainConfig.getSources();
        if (sources == null || sources.isEmpty()) return;

        String savedId = prefs.getString("default_source_id", sources.get(0).getId());
        String currentName = "ไม่ระบุ";
        for (Source s : sources) {
            if (s.getId().equals(savedId)) { currentName = s.getName(); break; }
        }

        String[] names = new String[sources.size()];
        int selectedIdx = 0;
        for (int i = 0; i < sources.size(); i++) {
            names[i] = sources.get(i).getName();
            if (sources.get(i).getId().equals(savedId)) selectedIdx = i;
        }

        final int finalSelectedIdx = selectedIdx;
        addSelectionRow("เว็บหน้าแรก", "เลือกเว็บที่จะแสดงเมื่อเปิดแอป", "default_source_id", names, currentName, (idx) -> {
            prefs.edit().putString("default_source_id", sources.get(idx).getId()).apply();
            buildModernSettings();
        }, finalSelectedIdx);
    }

    private void addSpeedSetting() {
        final float[] speeds = {0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f, 3.0f};
        final String[] labels = {"0.5x", "0.75x", "1.0x (ปกติ)", "1.25x", "1.5x", "2.0x", "3.0x"};
        float saved = prefs.getFloat(KEY_DEFAULT_SPEED, 1.0f);
        int currentIdx = 2;
        for (int i = 0; i < speeds.length; i++) {
            if (Math.abs(speeds[i] - saved) < 0.01f) { currentIdx = i; break; }
        }
        
        addSelectionRow("ความเร็วเริ่มต้น", "ตั้งความเร็วเล่นวิดีโอถาวร", KEY_DEFAULT_SPEED, labels, labels[currentIdx], (idx) -> {
            prefs.edit().putFloat(KEY_DEFAULT_SPEED, speeds[idx]).apply();
            buildModernSettings();
        }, currentIdx);
    }

    private void addSeekDurationSetting() {
        final int[] secs = {5, 10, 15, 20, 30};
        final String[] labels = {"5 วินาที", "10 วินาที", "15 วินาที", "20 วินาที", "30 วินาที"};
        int saved = prefs.getInt(KEY_SEEK_DURATION, 10);
        int currentIdx = 1;
        for (int i = 0; i < secs.length; i++) {
            if (secs[i] == saved) { currentIdx = i; break; }
        }
        addSelectionRow("ระยะเวลากรอ", "เวลาที่ข้ามเมื่อกดปุ่มกรอ", KEY_SEEK_DURATION, labels, labels[currentIdx], (idx) -> {
            prefs.edit().putInt(KEY_SEEK_DURATION, secs[idx]).apply();
            buildModernSettings();
        }, currentIdx);
    }

    private void addSkipIntroSetting() {
        final int[] opts = {0, 30, 60, 90, 120};
        final String[] labels = {"ปิด", "30 วินาที", "60 วินาที", "90 วินาที", "120 วินาที"};
        int saved = prefs.getInt(KEY_SKIP_INTRO, 0);
        int currentIdx = 0;
        for (int i = 0; i < opts.length; i++) {
            if (opts[i] == saved) { currentIdx = i; break; }
        }
        addSelectionRow("ข้าม Intro อัตโนมัติ", "กรอข้ามช่วงต้นตอนอัตโนมัติ", KEY_SKIP_INTRO, labels, labels[currentIdx], (idx) -> {
            prefs.edit().putInt(KEY_SKIP_INTRO, opts[idx]).apply();
            buildModernSettings();
        }, currentIdx);
    }

    private void addGridColumnsSetting() {
        final String[] labels = {"2 คอลัมน์", "3 คอลัมน์", "4 คอลัมน์"};
        int saved = prefs.getInt(KEY_GRID_COLUMNS, 2) - 2;
        addSelectionRow("จำนวนคอลัมน์", "ปรับขนาดรายการในหน้าหลัก", KEY_GRID_COLUMNS, labels, labels[saved], (idx) -> {
            prefs.edit().putInt(KEY_GRID_COLUMNS, idx + 2).apply();
            buildModernSettings();
        }, saved);
    }

    private void addCacheSizeSetting() {
        final int[] sizes = {100, 200, 500, 1000};
        final String[] labels = {"100 MB", "200 MB", "500 MB", "1 GB"};
        int saved = prefs.getInt(KEY_CACHE_SIZE_MB, 200);
        int currentIdx = 1;
        for (int i = 0; i < sizes.length; i++) {
            if (sizes[i] == saved) { currentIdx = i; break; }
        }
        addSelectionRow("ขนาด Cache", "จำกัดพื้นที่เก็บข้อมูลชั่วคราว", KEY_CACHE_SIZE_MB, labels, labels[currentIdx], (idx) -> {
            prefs.edit().putInt(KEY_CACHE_SIZE_MB, sizes[idx]).apply();
            buildModernSettings();
        }, currentIdx);
    }

    private void addBatteryOptSetting() {
        boolean ok = isIgnoringBatteryOptimizations();
        String status = ok ? "✅ พร้อมแจ้งเตือน" : "⚠️ อาจไม่ทำงานบางเครื่อง";
        addActionRow("Battery Optimization", status, () -> {
             if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                try {
                    startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", getPackageName(), null)));
                }
            }
        });
    }

    private void addSelectionRow(String title, String sub, String key, String[] options, String currentLabel, SelectionCallback callback, int selectedIdx) {
        MaterialCardView card = createItemCard();
        LinearLayout layout = createItemBaseLayout();
        layout.addView(createTextGroup(title, sub));
        
        TextView valueTv = new TextView(this);
        valueTv.setText(currentLabel);
        valueTv.setTextColor(Color.parseColor("#A89BC8"));
        valueTv.setTextSize(13f);
        layout.addView(valueTv);
        
        card.addView(layout);
        card.setOnClickListener(v -> {
            new AlertDialog.Builder(this, R.style.MaterialAlertDialog)
                    .setTitle(title)
                    .setSingleChoiceItems(options, selectedIdx, (dialog, which) -> {
                        callback.onSelected(which);
                        dialog.dismiss();
                    })
                    .show();
        });
        container.addView(card);
    }

    private void addActionRow(String title, String sub, Runnable action) {
        MaterialCardView card = createItemCard();
        LinearLayout layout = createItemBaseLayout();
        layout.addView(createTextGroup(title, sub));
        card.addView(layout);
        card.setOnClickListener(v -> action.run());
        container.addView(card);
    }

    private void addInfoRow(String title, String value) {
        MaterialCardView card = createItemCard();
        LinearLayout layout = createItemBaseLayout();
        layout.addView(createTextGroup(title, value));
        card.addView(layout);
        card.setClickable(false);
        card.setFocusable(false);
        container.addView(card);
    }

    private MaterialCardView createItemCard() {
        MaterialCardView card = new MaterialCardView(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(4), 0, dp(4));
        card.setLayoutParams(lp);
        card.setRadius(dp(12));
        card.setCardElevation(0);
        card.setClickable(true);
        card.setFocusable(true);
        card.setBackgroundResource(R.drawable.bg_setting_item);
        
        card.setOnFocusChangeListener((v, hasFocus) -> {
            v.animate().scaleX(hasFocus ? 1.02f : 1f).scaleY(hasFocus ? 1.02f : 1f).setDuration(150).start();
        });
        return card;
    }

    private LinearLayout createItemBaseLayout() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setPadding(dp(16), dp(16), dp(16), dp(16));
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    private LinearLayout createTextGroup(String title, String sub) {
        LinearLayout group = new LinearLayout(this);
        group.setOrientation(LinearLayout.VERTICAL);
        group.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView titleTv = new TextView(this);
        titleTv.setText(title);
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(15f);
        titleTv.setTypeface(null, Typeface.BOLD);

        TextView subTv = new TextView(this);
        subTv.setText(sub);
        subTv.setTextColor(Color.parseColor("#888888"));
        subTv.setTextSize(12f);
        subTv.setPadding(0, dp(2), 0, 0);

        group.addView(titleTv);
        group.addView(subTv);
        return group;
    }

    private void confirmClearHistory() {
        new AlertDialog.Builder(this, R.style.MaterialAlertDialog)
            .setTitle("ล้างประวัติการดู")
            .setMessage("ลบประวัติทั้งหมด? ไม่สามารถกู้คืนได้")
            .setPositiveButton("ล้าง", (d, w) -> {
                dbHelper.clearHistory();
                Toast.makeText(this, "✅ ล้างประวัติแล้ว", Toast.LENGTH_SHORT).show();
            }).setNegativeButton("ยกเลิก", null).show();
    }

    private void confirmClearCache() {
        new AlertDialog.Builder(this, R.style.MaterialAlertDialog)
            .setTitle("ล้าง Cache")
            .setMessage("ลบไฟล์ชั่วคราวทั้งหมด?")
            .setPositiveButton("ล้าง", (d, w) -> {
                try { deleteDir(getCacheDir()); } catch (Exception ignored) {}
                Toast.makeText(this, "✅ ล้าง Cache แล้ว", Toast.LENGTH_SHORT).show();
            }).setNegativeButton("ยกเลิก", null).show();
    }

    private void confirmLogout() {
        String username = SessionManager.getUsername(this);
        String sub = (username != null && !username.isEmpty())
                ? "ออกจากระบบบัญชี \"" + username + "\"?"
                : "ออกจากระบบบัญชีนี้?";
        new AlertDialog.Builder(this, R.style.MaterialAlertDialog)
            .setTitle("ออกจากระบบ")
            .setMessage(sub)
            .setPositiveButton("ออกจากระบบ", (d, w) -> {
                SessionManager.clear(this);
                ServerApiClient.logout(this);
                Toast.makeText(this, "ออกจากระบบแล้ว", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, LoginActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finishAffinity();
            }).setNegativeButton("ยกเลิก", null).show();
    }

    private static boolean deleteDir(File dir) {
        if (dir != null && dir.isDirectory()) {
            String[] children = dir.list();
            if (children != null) {
                for (String child : children) {
                    if (!deleteDir(new File(dir, child))) return false;
                }
            }
        }
        return dir != null && dir.delete();
    }

    private boolean isIgnoringBatteryOptimizations() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        return pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
    }

    private int dp(int px) { return (int) (px * getResources().getDisplayMetrics().density); }

    private String getAppVersion() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                return getPackageManager().getPackageInfo(getPackageName(), 
                    android.content.pm.PackageManager.PackageInfoFlags.of(0)).versionName;
            } else {
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            }
        }
        catch (Exception e) { return "1.0.0"; }
    }

    interface BoolCallback { void onChanged(boolean value); }
    interface SelectionCallback { void onSelected(int index); }

    @Override
    protected void onResume() {
        super.onResume();
        buildModernSettings(); 
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dbHelper != null) dbHelper.close();
    }
}