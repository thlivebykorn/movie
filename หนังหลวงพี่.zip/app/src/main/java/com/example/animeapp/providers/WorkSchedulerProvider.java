package com.example.animeapp.providers;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;

import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import com.example.animeapp.workers.FavoriteCheckWorker;

import java.util.concurrent.TimeUnit;


public class WorkSchedulerProvider extends ContentProvider {

    private static final String TAG = "WorkSchedulerProvider";

    @Override
    public boolean onCreate() {
       
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
            try {
                PeriodicWorkRequest work = new PeriodicWorkRequest.Builder(
                        FavoriteCheckWorker.class, 3, TimeUnit.HOURS, 30, TimeUnit.MINUTES)
                        .build();

                WorkManager.getInstance(getContext()).enqueueUniquePeriodicWork(
                        "favorite_check",
                        ExistingPeriodicWorkPolicy.KEEP,
                        work
                );

                Log.d(TAG, "WorkManager scheduled from ContentProvider");
            } catch (Exception e) {
                Log.e(TAG, "Failed to schedule: " + e.getMessage());
            }
        }, 500);
        return true;
    }

   
    @Override public Cursor query(Uri u, String[] p, String s, String[] sa, String so) { return null; }
    @Override public String getType(Uri u) { return null; }
    @Override public Uri insert(Uri u, ContentValues v) { return null; }
    @Override public int delete(Uri u, String s, String[] sa) { return 0; }
    @Override public int update(Uri u, ContentValues v, String s, String[] sa) { return 0; }
}
