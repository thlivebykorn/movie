package com.example.animeapp.parser;

import com.example.animeapp.models.Anime;
import com.example.animeapp.models.Episode;
import com.example.animeapp.models.HostListModel;
import com.example.animeapp.network.OkHttpClientFactory;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import com.example.animeapp.domain.DomainConfig;
import com.example.animeapp.network.GetplayStreamResolver;

public class WowDramaParser implements AnimeParser {

    private final OkHttpClient client;
    private String referer;
    private String domain;
    private String miruNonce;

    public WowDramaParser() {
        this.client = OkHttpClientFactory.getClientWithDoH();
    }

    @Override
    public Anime parseAnimeDetail(Document doc) {
        this.referer = doc.baseUri();
        this.domain = doc.baseUri().replaceAll("^(https?://)?(www[.])?([^/]+).*$", "$3");
        this.miruNonce = extractMiruNonce(doc);
        return com.example.animeapp.parser.NativeParseBridge.parseAnimeDetail("wowdrama", doc);
    }

    @Override
    public List<Episode> parseEpisodes(Document doc, String imageUrl) {
        return com.example.animeapp.parser.NativeParseBridge.parseEpisodes("wowdrama", doc, imageUrl);
    }

    @Override
    public String parseVideoUrl(Document epDoc, String referer, int episodeNumber) throws IOException {
        
        String baseUri = epDoc.baseUri();
        if (baseUri != null && !baseUri.isEmpty()) {
            this.domain = baseUri.replaceAll("^(https?://)?(www\\.)?([^/:]+).*$", "$3");
        }
        if ((this.domain == null || this.domain.isEmpty()) && this.referer != null) {
            this.domain = this.referer.replaceAll("^(https?://)?(www\\.)?([^/:]+).*$", "$3");
        }
        if ((this.domain == null || this.domain.isEmpty()) && referer != null && !referer.isEmpty()) {
            this.domain = referer.replaceAll("^(https?://)?(www\\.)?([^/:]+).*$", "$3");
        }

        if (referer != null && !referer.isEmpty()) {
            this.referer = referer;
        }
       
        if (this.referer == null || this.referer.isEmpty()) {
            this.referer = epDoc.baseUri().replaceAll("\\?.*", "");
        }

        String url = epDoc.baseUri();
        Pattern pattern = Pattern.compile("episode-id=([^&]+)");
        Matcher matcher = pattern.matcher(url);

        if (!matcher.find()) {
            throw new IOException("ไม่พบ episode-id ใน URL");
        }

        String episodeId = matcher.group(1);
        try {
            return getVideoUrlAjax(episodeId, epDoc);
        } catch (IOException e) {
            System.out.println("วิธีหลักไม่สำเร็จ, ลองวิธีสำรอง: " + e.getMessage());
            return tryAlternativeMethods(episodeId, epDoc);
        }
    }

    private String getVideoUrlAjax(String episodeId, Document epDoc) throws IOException {
        if (domain == null || domain.isEmpty()) {
            throw new IOException("Domain is null or empty");
        }

        String nonce = extractMiruNonce(epDoc);
        if (nonce == null || nonce.isEmpty()) {
            nonce = this.miruNonce;
        }
        if (nonce == null || nonce.isEmpty()) {
            throw new IOException("ไม่พบ nonce ของ player");
        }

        String ajaxUrl = "https://" + domain + "/wp-admin/admin-ajax.php";
        String lastError = null;

        for (int serverIdx = 0; serverIdx < 2; serverIdx++) {
            FormBody formBody = new FormBody.Builder()
                    .add("action", "miru_get_api_player_url")
                    .add("ep_id", episodeId)
                    .add("server_idx", String.valueOf(serverIdx))
                    .add("nonce", nonce)
                    .build();

            Request request = new Request.Builder()
                    .url(ajaxUrl)
                    .post(formBody)
                    .header("User-Agent", "Mozilla/5.0")
                    .header("Referer", referer)
                    .header("Origin", "https://" + domain)
                    .header("X-Requested-With", "XMLHttpRequest")
                    .build();

            try (Response response = client.newCall(request).execute()) {
                if (!response.isSuccessful()) {
                    lastError = "AJAX request failed: " + response.code();
                    continue;
                }

                String responseBody = response.body().string();

                String torboFromResponse = extractTorboStreamUrl(responseBody);
                if (torboFromResponse != null) return torboFromResponse;

                if (responseBody.contains("jwplayer(") || responseBody.contains("sources: [")) {
                    return parseJwPlayerResponse(responseBody);
                }

                try {
                    JsonObject root = JsonParser.parseString(responseBody).getAsJsonObject();
                    if (root.has("success") && !root.get("success").getAsBoolean()) {
                        if (root.has("data") && root.get("data").isJsonObject()
                                && root.getAsJsonObject("data").has("message")) {
                            lastError = root.getAsJsonObject("data").get("message").getAsString();
                        } else {
                            lastError = "API success=false";
                        }
                        continue;
                    }

                    if (root.has("success") && root.get("success").getAsBoolean()) {
                        String urlFromResponse = null;

                        JsonObject player = root.has("player") && root.get("player").isJsonObject()
                                ? root.getAsJsonObject("player") : null;
                        if (player != null && player.has("primary")) {
                            urlFromResponse = player.get("primary").getAsString().replace("\\/", "/");
                        }

                        if (urlFromResponse == null && root.has("data") && root.get("data").isJsonObject()) {
                            JsonObject data = root.getAsJsonObject("data");
                            if (data.has("url")) {
                                urlFromResponse = data.get("url").getAsString().replace("\\/", "/");
                            }
                        }

                        if (urlFromResponse != null) {
                            if (urlFromResponse.endsWith(".m3u8")) return urlFromResponse;
                            String resolved = processIframeUrlFull(urlFromResponse);
                            if (resolved != null) return resolved;
                        }

                        if (player != null && player.has("data")) {
                            JsonObject data = player.getAsJsonObject("data");
                            for (String langKey : data.keySet()) {
                                if (data.get(langKey).isJsonArray()) {
                                    JsonArray servers = data.getAsJsonArray(langKey);
                                    for (JsonElement elem : servers) {
                                        JsonObject server = elem.getAsJsonObject();
                                        if (server.has("url")) {
                                            String videoUrl = server.get("url").getAsString().replace("\\/", "/");
                                            if (videoUrl.endsWith(".m3u8")) return videoUrl;
                                            String resolved = processIframeUrlFull(videoUrl);
                                            if (resolved != null) return resolved;
                                        }
                                    }
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    lastError = e.getMessage();
                }

                Document doc = org.jsoup.Jsoup.parse(responseBody);
                Element iframe = doc.selectFirst("iframe");
                if (iframe != null) {
                    String src = iframe.attr("src");
                    if (src != null && !src.isEmpty()) {
                        String videoUrl = processIframeUrlFull(src);
                        if (videoUrl != null) return videoUrl;
                    }
                }
            }
        }

        throw new IOException("ไม่พบลิงก์วิดีโอจาก ajax response" + (lastError != null ? ": " + lastError : ""));
    }

    private String extractMiruNonce(Document doc) {
        if (doc == null) return null;
        for (Element script : doc.select("script")) {
            String html = script.html();
            if (html == null) continue;
            Matcher matcher = Pattern.compile("miruNonce\\s*=\\s*\"([^\"]+)\"").matcher(html);
            if (matcher.find()) {
                return matcher.group(1);
            }
        }
        return null;
    }

    private String parseJwPlayerResponse(String html) throws IOException {
        Pattern jwPattern = Pattern.compile(
            "sources:\\s*\\[\\s*\\{\\s*file:\\s*\"([^\"]+\\.m3u8)\"",
            Pattern.CASE_INSENSITIVE
        );
        Matcher matcher = jwPattern.matcher(html);
        if (matcher.find()) {
            return matcher.group(1).replace("\\/", "/");
        }
        
        Pattern sourcesPattern = Pattern.compile(
            "\"sources\"\\s*:\\s*\\[\\s*\\{\\s*\"file\"\\s*:\\s*\"([^\"]+\\.m3u8)\"",
            Pattern.CASE_INSENSITIVE
        );
        matcher = sourcesPattern.matcher(html);
        if (matcher.find()) {
            return matcher.group(1).replace("\\/", "/");
        }
        
        throw new IOException("ไม่พบลิงก์วิดีโอใน JW Player response");
    }

    private String tryAlternativeMethods(String episodeId, Document epDoc) throws IOException {
        String directUrl = findDirectVideoUrl(epDoc.html());
        if (directUrl != null) {
            return directUrl;
        }

        String iframeUrl = findIframeUrl(epDoc.html());
        if (iframeUrl != null) {
            try {
                return processIframeUrlFull(iframeUrl);
            } catch (IOException e) {
                System.out.println("การประมวลผล iframe ล้มเหลว: " + e.getMessage());
            }
        }

        String scriptUrl = findVideoUrlInScripts(epDoc);
        if (scriptUrl != null) {
            return scriptUrl;
        }

        Elements servers = epDoc.select("div.mp-s-sl");
        if (!servers.isEmpty()) {
            for (Element server : servers) {
                String serverUrl = server.attr("data-id");
                if (serverUrl != null && !serverUrl.isEmpty()) {
                    try {
                        String videoUrl = extractFromBackupServer(serverUrl);
                        if (videoUrl != null) {
                            return videoUrl;
                        }
                    } catch (IOException e) {
                        System.out.println("ไม่สามารถดึงจากเซิร์ฟเวอร์สำรองได้: " + serverUrl);
                    }
                }
            }
        }

        throw new IOException("ไม่พบลิงก์วิดีโอจากวิธีใดๆ ทั้งหมด");
    }

    private String findDirectVideoUrl(String html) {
        Pattern pattern = Pattern.compile(
            "(https?:\\/\\/[^\\s\"']+\\.(?:m3u8|mp4|mkv|webm))",
            Pattern.CASE_INSENSITIVE
        );
        Matcher matcher = pattern.matcher(html);
        while (matcher.find()) {
            String url = matcher.group(1);
            if (!url.contains("localhost") && !url.contains("127.0.0.1")) {
                return url;
            }
        }
        return null;
    }

    private String findIframeUrl(String html) {
        Pattern iframePattern = Pattern.compile(
            "<iframe[^>]+src=[\"']([^\"']+)[\"']",
            Pattern.CASE_INSENSITIVE
        );
        Matcher iframeMatcher = iframePattern.matcher(html);
        return iframeMatcher.find() ? iframeMatcher.group(1) : null;
    }

    private String findVideoUrlInScripts(Document doc) {
        Elements scripts = doc.select("script");
        for (Element script : scripts) {
            String scriptText = script.html();
            
            String jsonUrl = findJsonVideoUrl(scriptText);
            if (jsonUrl != null) return jsonUrl;
            
            String jsUrl = findJsVideoUrl(scriptText);
            if (jsUrl != null) return jsUrl;
        }
        return null;
    }

    private String findJsonVideoUrl(String text) {
        Pattern jsonPattern = Pattern.compile(
            "\"(?:file|url|src)\"\\s*:\\s*\"([^\"]+\\.(?:m3u8|mp4))\"",
            Pattern.CASE_INSENSITIVE
        );
        Matcher jsonMatcher = jsonPattern.matcher(text);
        return jsonMatcher.find() ? jsonMatcher.group(1).replace("\\/", "/") : null;
    }

    private String findJsVideoUrl(String text) {
        Pattern jsPattern = Pattern.compile(
            "(?:videoSources|sources|jwplayer\\().*?file.*?\"(https?:\\\\/\\\\/[^\"]+)\"",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL
        );
        Matcher jsMatcher = jsPattern.matcher(text);
        return jsMatcher.find() ? jsMatcher.group(1).replace("\\/", "/") : null;
    }

    private String extractFromBackupServer(String serverUrl) throws IOException {
        Request request = new Request.Builder()
            .url(serverUrl)
            .header("User-Agent", "Mozilla/5.0")
            .header("Referer", referer)
            .build();

        try (Response response = client.newCall(request).execute()) {
            String html = response.body().string();
            Document doc = org.jsoup.Jsoup.parse(html);
            
            String directUrl = findDirectVideoUrl(html);
            if (directUrl != null) return directUrl;
            
            String iframeUrl = findIframeUrl(html);
            if (iframeUrl != null) return processIframeUrlFull(iframeUrl);
            
            String scriptUrl = findVideoUrlInScripts(doc);
            if (scriptUrl != null) return scriptUrl;
        }
        return null;
    }

    private String processIframeUrlFull(String iframeUrl) throws IOException {
        iframeUrl = normalizeUrl(iframeUrl);
        
        String torboUrl = buildTorboStreamUrl(iframeUrl);
        if (torboUrl != null) return torboUrl;
        
        String getplayUrl = buildGetplayStreamUrl(iframeUrl);
        if (getplayUrl != null) return getplayUrl;

        try {
            return originalIframeProcessing(iframeUrl);
        } catch (IOException e) {
            System.out.println("วิธีเดิมไม่ทำงานใน iframe, ลองวิธีใหม่: " + e.getMessage());
            
            Request request = new Request.Builder()
                .url(iframeUrl)
                .header("User-Agent", "Mozilla/5.0")
                .header("Referer", referer)
                .build();

            try (Response response = client.newCall(request).execute()) {
                String html = response.body().string();
                
                String directUrl = findDirectVideoUrl(html);
                if (directUrl != null) return directUrl;

                String getplayFromHtml = extractGetplayStreamUrl(html, iframeUrl);
                if (getplayFromHtml != null) return getplayFromHtml;
                
                String nestedIframe = findIframeUrl(html);
                if (nestedIframe != null) return processIframeUrlFull(nestedIframe);
                
                Document doc = org.jsoup.Jsoup.parse(html);
                String scriptUrl = findVideoUrlInScripts(doc);
                if (scriptUrl != null) return scriptUrl;
            }
            
            throw new IOException("ไม่พบวิดีโอใน iframe");
        }
    }

    private String originalIframeProcessing(String iframeUrl) throws IOException {
        Request request = new Request.Builder()
                .url(iframeUrl)
                .header("User-Agent", "Mozilla/5.0")
                .header("Referer", referer)
                .build();

        try (Response response = client.newCall(request).execute()) {
            String html = response.body().string();

            Pattern scriptPattern = Pattern.compile("<script[^>]*>(.*?)</script>", Pattern.DOTALL);
            Matcher scriptMatcher = scriptPattern.matcher(html);

            while (scriptMatcher.find()) {
                String scriptContent = scriptMatcher.group(1);

                if (scriptContent.contains("videoSources")) {
                    Pattern videoServerPattern = Pattern.compile("\"videoServer\":\"(\\d+)\"");
                    Pattern videoSourcesPattern = Pattern.compile("\"videoSources\":\\[\\{\"file\":\"([^\"]+)\"");
                    Pattern hostListPattern = Pattern.compile("\"hostList\":(\\{.*?\\})");

                    Matcher videoServerMatcher = videoServerPattern.matcher(scriptContent);
                    Matcher videoSourcesMatcher = videoSourcesPattern.matcher(scriptContent);
                    Matcher hostListMatcher = hostListPattern.matcher(scriptContent);

                    if (videoServerMatcher.find() && videoSourcesMatcher.find() && hostListMatcher.find()) {
                        String videoServer = videoServerMatcher.group(1);
                        String videoFile = videoSourcesMatcher.group(1);
                        String hostListJson = hostListMatcher.group(1);

                        Gson gson = new Gson();
                        HostListModel hostList = gson.fromJson("{\"hostList\":" + hostListJson + "}", HostListModel.class);

                        List<String> selectedDomainList = hostList.getHostList().get(videoServer);
                        if (selectedDomainList != null && !selectedDomainList.isEmpty()) {
                            String domain = selectedDomainList.get(0)
                                    .replace("[", "")
                                    .replace("]", "")
                                    .replace("'", "")
                                    .trim();

                            String videoUrl = videoFile.replaceAll(
                                    "https:\\\\/\\\\/\\d+\\\\/cdn\\\\/hls\\\\/",
                                    "https://" + domain + "/api/files/");

                            videoUrl = videoUrl.replace("\\/", "/");

                            return videoUrl;
                        }
                    }
                }
            }
        }

        throw new IOException("ไม่พบ video URL ใน iframe script");
    }

    private String normalizeUrl(String url) {
        if (url == null) return "";
        String normalized = url.trim();
        if (normalized.startsWith("//")) {
            normalized = "https:" + normalized;
        }
        return normalized;
    }

    private String getConfiguredStreamHost() {
        try {
            return java.net.URI.create(DomainConfig.ApiUrl.GETPLAY_STREAM_API()).getHost();
        } catch (Exception e) {
            return "";
        }
    }

    private String buildGetplayStreamUrl(String iframeUrl) {
        Matcher matcher = Pattern.compile(
                "https?://(?:getplay-cdn|ok-hd)\\.com/(?:embed|play)/([A-Za-z0-9_-]{20,})",
                Pattern.CASE_INSENSITIVE
        ).matcher(iframeUrl);
        if (matcher.find()) {
            String id = matcher.group(1);
            String cdnHost = matcher.group(0).contains("ok-hd") ? "ok-hd.com" : "getplay-cdn.com";
            return fetchGetplayTokenUrl(id, cdnHost);
        }
        return null;
    }

    private String extractGetplayStreamUrl(String html, String iframeUrl) {
        String fromIframe = buildGetplayStreamUrl(iframeUrl);
        if (fromIframe != null) return fromIframe;

        Matcher pathMatcher = Pattern.compile(
                "(?:getplay-cdn|ok-hd)\\.com/api/stream/([A-Za-z0-9_-]{20,})/index\\.m3u8",
                Pattern.CASE_INSENSITIVE
        ).matcher(html);
        if (pathMatcher.find()) {
            String cdnHost = pathMatcher.group(0).contains("ok-hd") ? "ok-hd.com" : "getplay-cdn.com";
            return fetchGetplayTokenUrl(pathMatcher.group(1), cdnHost);
        }

        Matcher embedMatcher = Pattern.compile(
                "(?:getplay-cdn|ok-hd)\\.com/(?:embed|play)/([A-Za-z0-9_-]{20,})",
                Pattern.CASE_INSENSITIVE
        ).matcher(html);
        if (embedMatcher.find()) {
            String cdnHost = embedMatcher.group(0).contains("ok-hd") ? "ok-hd.com" : "getplay-cdn.com";
            return fetchGetplayTokenUrl(embedMatcher.group(1), cdnHost);
        }
        return null;
    }

    private String fetchGetplayTokenUrl(String id, String cdnHost) {
        try {
            String streamBase = "https://" + cdnHost;
            String parent = this.domain != null && !this.domain.isEmpty()
                    ? this.domain : "wow-drama.com";
            return GetplayStreamResolver.resolve(streamBase, id, parent, client);
        } catch (Exception e) {
            System.out.println("getplay token fetch failed: " + e.getMessage());
        }
        return null;
    }

    private String resolveTorboStream(String id) {
        String streamHost = getConfiguredStreamHost();
        if (streamHost == null || streamHost.isEmpty()) return null;
        String streamBase = "https://" + streamHost;
        String parent = (this.domain != null && !this.domain.isEmpty()) ? this.domain : streamHost;
        return GetplayStreamResolver.resolve(streamBase, id, parent, client);
    }

    private String extractTorboStreamUrl(String text) {
        String unescaped = text.replace("\\/", "/");
        Matcher matcher = Pattern.compile(
            Pattern.quote(getConfiguredStreamHost()) + "/(?:embed|play)/([A-Za-z0-9]{32})",
            Pattern.CASE_INSENSITIVE
        ).matcher(unescaped);
        if (matcher.find()) {
            return resolveTorboStream(matcher.group(1));
        }
        return null;
    }

    private String buildTorboStreamUrl(String url) {
        Matcher matcher = Pattern.compile(
            Pattern.quote(getConfiguredStreamHost()) + "/(?:embed|play)/([A-Za-z0-9]{32})",
            Pattern.CASE_INSENSITIVE
        ).matcher(url);
        if (matcher.find()) {
            return resolveTorboStream(matcher.group(1));
        }
        return null;
    }
}
