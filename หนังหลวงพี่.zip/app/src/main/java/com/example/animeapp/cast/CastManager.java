package com.example.animeapp.cast;

import android.content.Context;
import android.util.Log;

import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaLoadRequestData;
import com.google.android.gms.cast.MediaMetadata;
import com.google.android.gms.cast.framework.CastContext;
import com.google.android.gms.cast.framework.CastSession;
import com.google.android.gms.cast.framework.SessionManagerListener;
import com.google.android.gms.cast.framework.media.RemoteMediaClient;
import com.google.android.gms.common.images.WebImage;

import android.net.Uri;


public class CastManager {

    private static final String TAG = "CastManager";

    private CastContext  castContext;
    private CastSession  currentSession;
    private boolean      isAvailable = false;

  
    public interface CastStateListener {
        void onCastConnected();
        void onCastDisconnected();
    }

    private CastStateListener stateListener;

    private final SessionManagerListener<CastSession> sessionListener =
        new SessionManagerListener<CastSession>() {
            @Override public void onSessionStarted(CastSession session, String id) {
                currentSession = session;
                if (stateListener != null) stateListener.onCastConnected();
                Log.d(TAG, "Cast session started");
            }
            @Override public void onSessionEnded(CastSession session, int error) {
                currentSession = null;
                if (stateListener != null) stateListener.onCastDisconnected();
                Log.d(TAG, "Cast session ended");
            }
            @Override public void onSessionResumed(CastSession session, boolean wasSuspended) {
                currentSession = session;
                if (stateListener != null) stateListener.onCastConnected();
            }
            @Override public void onSessionResuming(CastSession session, String sessionId) {}
            @Override public void onSessionSuspended(CastSession session, int reason) {}
            @Override public void onSessionStarting(CastSession session) {}
            @Override public void onSessionEnding(CastSession session) {}
            @Override public void onSessionStartFailed(CastSession session, int error) {}
            @Override public void onSessionResumeFailed(CastSession session, int error) {}
        };

    public CastManager(Context context) {
        try {
            castContext  = CastContext.getSharedInstance(context);
            isAvailable  = true;
            currentSession = castContext.getSessionManager().getCurrentCastSession();
        } catch (Exception e) {
           
            Log.w(TAG, "Cast not available: " + e.getMessage());
            isAvailable = false;
        }
    }

    public void setCastStateListener(CastStateListener listener) {
        this.stateListener = listener;
    }

    public boolean isAvailable() { return isAvailable; }

    public boolean isConnected() {
        return currentSession != null && currentSession.isConnected();
    }

    public void onResume() {
        if (!isAvailable) return;
        castContext.getSessionManager().addSessionManagerListener(sessionListener, CastSession.class);
        currentSession = castContext.getSessionManager().getCurrentCastSession();
    }

    public void onPause() {
        if (!isAvailable) return;
        castContext.getSessionManager().removeSessionManagerListener(sessionListener, CastSession.class);
    }

  
    public void castVideo(String videoUrl, String title, String imageUrl, long positionMs) {
        if (!isConnected()) {
            Log.w(TAG, "Not connected to Cast device");
            return;
        }

        RemoteMediaClient remoteClient = currentSession.getRemoteMediaClient();
        if (remoteClient == null) return;

       
        MediaMetadata metadata = new MediaMetadata(MediaMetadata.MEDIA_TYPE_MOVIE);
        metadata.putString(MediaMetadata.KEY_TITLE, title != null ? title : "");
        if (imageUrl != null && !imageUrl.isEmpty()) {
            metadata.addImage(new WebImage(Uri.parse(imageUrl)));
        }

      
        String mimeType = videoUrl.contains(".m3u8")
            ? "application/x-mpegURL"
            : "video/mp4";

        MediaInfo mediaInfo = new MediaInfo.Builder(videoUrl)
            .setStreamType(MediaInfo.STREAM_TYPE_BUFFERED)
            .setContentType(mimeType)
            .setMetadata(metadata)
            .build();

        MediaLoadRequestData loadRequest = new MediaLoadRequestData.Builder()
            .setMediaInfo(mediaInfo)
            .setAutoplay(true)
            .setCurrentTime(positionMs)
            .build();

        remoteClient.load(loadRequest);
        Log.d(TAG, "Casting: " + title + " @ " + positionMs + "ms");
    }

  
    public void stopCasting() {
        if (isConnected()) {
            RemoteMediaClient client = currentSession.getRemoteMediaClient();
            if (client != null) client.stop();
        }
    }

   
    public long getRemotePosition() {
        if (!isConnected()) return 0;
        RemoteMediaClient client = currentSession.getRemoteMediaClient();
        return client != null ? client.getApproximateStreamPosition() : 0;
    }

    public CastContext getCastContext() { return castContext; }
}
