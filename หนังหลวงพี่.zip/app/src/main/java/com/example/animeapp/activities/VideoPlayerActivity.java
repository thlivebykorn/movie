package com.example.animeapp.activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Build;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.IntentCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.Tracks;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.DefaultTimeBar;
import androidx.media3.ui.PlayerView;

import com.example.animeapp.R;
import com.example.animeapp.cast.CastManager;
import com.example.animeapp.controllers.PlayerGestureController;
import com.example.animeapp.controllers.VideoPlayerController;
import com.example.animeapp.database.DatabaseHelper;
import com.example.animeapp.databinding.ActivityVideoPlayerBinding;
import com.example.animeapp.dialog.VideoInfoDialog;
import com.example.animeapp.listeners.PlayerEventListener;
import com.example.animeapp.managers.BrightnessVolumeManager;
import com.example.animeapp.models.Episode;
import com.google.android.gms.cast.framework.CastButtonFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class VideoPlayerActivity extends AppCompatActivity implements VideoPlayerController.EpisodeChangeListener{
    private ActivityVideoPlayerBinding binding;
    private VideoPlayerController playerController;
    private BrightnessVolumeManager brightnessVolumeManager;
    private PlayerGestureController gestureController;
    private VideoInfoDialog videoInfoDialog;
    private DatabaseHelper dbHelper;
    
    private List<Episode> episodes;
    private int currentEpisodeIndex;
    private boolean isTelevision;
    private String animeTitle;
    private String animeUrl;
    private CastManager castManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupWindow();
        initializeBinding();
        checkDeviceType();
        initializeManagers();
        retrieveIntentData();
    }

    private void setupWindow() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            WindowManager.LayoutParams layoutParams = getWindow().getAttributes();
            layoutParams.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(layoutParams);
        }
    }

    private void initializeBinding() {
        binding = ActivityVideoPlayerBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
    }
    
    private void saveWatchHistory() {
        if (episodes == null || currentEpisodeIndex < 0 || currentEpisodeIndex >= episodes.size()) {
            return;
        }

        Episode currentEpisode = episodes.get(currentEpisodeIndex);
        
      
        dbHelper.addOrUpdateHistory(
            animeTitle,
            String.valueOf(currentEpisode.getEpisodeNumber()),
            animeUrl,
            currentEpisode.getImageUrl(),
            currentEpisode.getInfoUrl()
        );
    }

    private void checkDeviceType() {
        isTelevision = getPackageManager().hasSystemFeature(PackageManager.FEATURE_LEANBACK);
    }

    private void retrieveIntentData() {
        this.episodes = IntentCompat.getParcelableArrayListExtra(getIntent(), "EPISODES", Episode.class);
        this.currentEpisodeIndex = getIntent().getIntExtra("CURRENT_INDEX", -1);
        this.animeTitle = getIntent().getStringExtra("ANIME_TITLE");
        this.animeUrl = getIntent().getStringExtra("ANIME_URL");

        Episode episode = IntentCompat.getParcelableExtra(getIntent(), "EPISODE", Episode.class);
        if (episode == null && episodes != null && currentEpisodeIndex >= 0) {
            episode = episodes.get(currentEpisodeIndex);
        }

        if (episode != null) {
            initializePlayer(episode);
            setupUI(episode);
            saveWatchHistory();
        } else {
            Toast.makeText(this, "ไม่มีข้อมูลตอนนี้", Toast.LENGTH_SHORT).show();
            finish();
        }
    }
    
    private void initializeManagers() {
        dbHelper = new DatabaseHelper(this);
        brightnessVolumeManager = new BrightnessVolumeManager(this);
        videoInfoDialog = new VideoInfoDialog(this);
        
        LinearLayout brightnessVolumeContainer = findViewById(R.id.brightness_volume_container);
        ImageView brightnessIcon = findViewById(R.id.brightness_icon);
        ImageView volumeIcon = findViewById(R.id.volume_icon);
        TextView brightVolumeTV = findViewById(R.id.brightness_volume_tv);
        
        gestureController = new PlayerGestureController(this, binding.playerView,
                brightnessVolumeManager, brightnessVolumeContainer,
                brightnessIcon, volumeIcon, brightVolumeTV);
        SharedPreferences settingsSp = getSharedPreferences("AnimeAppPrefs", MODE_PRIVATE);
        gestureController.setEnabled(settingsSp.getBoolean("player_gesture", true));
    }

    private void initializePlayer(Episode episode) {
        playerController = new VideoPlayerController(this, binding.playerView, episodes, currentEpisodeIndex);
        playerController.setEpisodeChangeListener(this);

       
        ProgressBar bufferProgressBar = findViewById(R.id.buffer_progressbar);
        playerController.setBufferProgressBar(bufferProgressBar);

        playerController.initializePlayer(episode);

       
        ExoPlayer player = playerController.getPlayer();
        if (player != null) {
            player.addListener(new androidx.media3.common.Player.Listener() {
                @Override
                public void onTracksChanged(Tracks tracks) {
                    selectHighestQuality();
                }
            });
        }

      
        castManager = new CastManager(this);

       
        android.content.IntentFilter pipFilter = new android.content.IntentFilter(PIP_ACTION_BROADCAST);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(pipReceiver, pipFilter, android.content.Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(pipReceiver, pipFilter);
        }
        castManager.setCastStateListener(new CastManager.CastStateListener() {
            @Override
            public void onCastConnected() {
                invalidateOptionsMenu();
               
                castCurrentVideo();
            }
            @Override
            public void onCastDisconnected() {
                invalidateOptionsMenu();
              
                long remotePos = castManager.getRemotePosition();
                if (remotePos > 0 && playerController != null
                        && playerController.getPlayer() != null) {
                    playerController.getPlayer().seekTo(remotePos);
                    playerController.getPlayer().play();
                }
            }
        });
        
        loadPlaybackPosition(episodes.get(currentEpisodeIndex).getInfoUrl());
    }
    
    private void loadPlaybackPosition(String episodeUrl) {
        SharedPreferences prefs = getSharedPreferences("PLAYBACK_POSITIONS", MODE_PRIVATE);
        long position = prefs.getLong(episodeUrl, 0);
        
        if (position > 0 && playerController != null && playerController.getPlayer() != null) {
            playerController.getPlayer().seekTo(position);
        }
    }
    
    public void loadPlaybackPositionForCurrentEpisode() {
        if (episodes != null && currentEpisodeIndex >= 0 && currentEpisodeIndex < episodes.size()) {
            Episode currentEpisode = episodes.get(currentEpisodeIndex);
            loadPlaybackPosition(currentEpisode.getInfoUrl());
        }
    }

    public void loadPlaybackPositionForEpisode(String episodeUrl) {
        SharedPreferences prefs = getSharedPreferences("PLAYBACK_POSITIONS", MODE_PRIVATE);
        long position = prefs.getLong(episodeUrl, 0);

        if (position > 0 && playerController != null && playerController.getPlayer() != null) {
            playerController.getPlayer().seekTo(position);
        }
    }

    private void savePlaybackPosition(String episodeUrl, long position) {
        SharedPreferences prefs = getSharedPreferences("PLAYBACK_POSITIONS", MODE_PRIVATE);
        prefs.edit().putLong(episodeUrl, position).apply();
    }
    
    @Override
    public void onEpisodeChanged(int newEpisodeIndex) {
        this.currentEpisodeIndex = newEpisodeIndex;
        saveWatchHistory();
      
        if (castManager != null && castManager.isConnected()) {
          
            new android.os.Handler(android.os.Looper.getMainLooper())
                .postDelayed(() -> castCurrentVideo(), 500);
        }
    }
    
    
    public void savePlaybackPositionDirect(String episodeUrl, long position) {
        savePlaybackPosition(episodeUrl, position);
    }
    
    public void saveCurrentPlaybackPosition() {
        if (playerController != null && playerController.getPlayer() != null && 
            episodes != null && currentEpisodeIndex >= 0 && currentEpisodeIndex < episodes.size()) {
            Episode currentEpisode = episodes.get(currentEpisodeIndex);
            long position = playerController.getPlayer().getCurrentPosition();
            savePlaybackPosition(currentEpisode.getInfoUrl(), position);
        }
    }

    private void setupUI(Episode episode) {
        setupVideoTitle(episode);
        setupNavigationButtons();
        setupButtonListeners();
        setupResizeModeControls();
        setupPlayerFocusTargets();
        hideSystemUI();
        scheduleControllerAutoHide();
    }

    private void setupPlayerFocusTargets() {
        binding.playerView.setFocusable(true);
        binding.playerView.setFocusableInTouchMode(false);
        binding.playerView.setControllerShowTimeoutMs(2500);

        int[] controlIds = {
                R.id.btnBack,
                R.id.btnDetails,
                R.id.prev_episode,
                R.id.backward_10,
                androidx.media3.ui.R.id.exo_play_pause,
                R.id.forward_10,
                R.id.next_episode,
                R.id.btnPip,
                R.id.btnEqualizer,
                R.id.btnQuality,
                R.id.btnSpeed,
                R.id.btnRotate,
                R.id.btnResize,
                R.id.castButton,
                androidx.media3.ui.R.id.exo_progress
        };

        for (int id : controlIds) {
            View control = binding.playerView.findViewById(id);
            if (control == null) continue;
            makePlayerControlFocusable(control, id);
        }

        if (isTelevision) {
            binding.playerView.showController();
            binding.playerView.postDelayed(() -> {
                View playPause = binding.playerView.findViewById(androidx.media3.ui.R.id.exo_play_pause);
                if (playPause != null && playPause.isEnabled() && playPause.getVisibility() == View.VISIBLE) {
                    playPause.requestFocus();
                }
            }, 250);
        }
    }

    public void scheduleControllerAutoHide() {
        if (binding == null || binding.playerView == null || isInPictureInPictureMode()) return;
        binding.playerView.setUseController(true);
        binding.playerView.setControllerShowTimeoutMs(2500);
        binding.playerView.postDelayed(() -> {
            if (binding == null || binding.playerView == null || isInPictureInPictureMode()) return;
            if (playerController != null && playerController.getPlayer() != null
                    && playerController.getPlayer().isPlaying()) {
                binding.playerView.hideController();
            }
        }, 2600);
    }

    private void makePlayerControlFocusable(View control, int id) {
        control.setFocusable(true);
        control.setFocusableInTouchMode(false);
        control.setClickable(true);

        if (id == androidx.media3.ui.R.id.exo_play_pause) {
            control.setBackgroundResource(R.drawable.play_pause_button_background);
        } else if (id == R.id.backward_10 || id == R.id.forward_10
                || id == R.id.prev_episode || id == R.id.next_episode) {
            control.setBackgroundResource(R.drawable.seek_button_background);
        } else if (!(control instanceof DefaultTimeBar)) {
            control.setBackgroundResource(R.drawable.control_button_background);
        }

        control.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                binding.playerView.showController();
            }
            v.animate()
                    .scaleX(hasFocus ? 1.12f : 1f)
                    .scaleY(hasFocus ? 1.12f : 1f)
                    .setDuration(100)
                    .start();
        });

        control.setOnKeyListener(this::handlePlayerControlKey);
    }

    private boolean handlePlayerControlKey(View view, int keyCode, KeyEvent event) {
        if (event.getAction() != KeyEvent.ACTION_DOWN) return false;

        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) {
            view.performClick();
            return true;
        }

        int direction = keyCodeToFocusDirection(keyCode);
        if (direction == 0) return false;

        View root = binding.playerView.findViewById(R.id.exo_controller);
        View nextFocus = root != null ? view.focusSearch(direction) : null;
        if (nextFocus != null && nextFocus.isShown() && nextFocus.isEnabled()) {
            nextFocus.requestFocus();
            binding.playerView.showController();
            return true;
        }

        return false;
    }

    private int keyCodeToFocusDirection(int keyCode) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
                return View.FOCUS_LEFT;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                return View.FOCUS_RIGHT;
            case KeyEvent.KEYCODE_DPAD_UP:
                return View.FOCUS_UP;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                return View.FOCUS_DOWN;
            default:
                return 0;
        }
    }

    private boolean isPlayerControlFocused() {
        View currentFocus = getCurrentFocus();
        View controller = binding != null && binding.playerView != null
                ? binding.playerView.findViewById(R.id.exo_controller)
                : null;
        return currentFocus != null && controller != null && isDescendantOf(currentFocus, controller);
    }

    private boolean isDescendantOf(View child, View parent) {
        View current = child;
        while (current != null) {
            if (current == parent) return true;
            if (!(current.getParent() instanceof View)) return false;
            current = (View) current.getParent();
        }
        return false;
    }

    private void setupVideoTitle(Episode episode) {
        TextView titleView = binding.playerView.findViewById(R.id.videoTitle);
        titleView.setText(episode.getTitle());
    }

    private void setupNavigationButtons() {
        ImageButton prevButton = findViewById(R.id.prev_episode);
        ImageButton nextButton = findViewById(R.id.next_episode);
        TextView titleView = binding.playerView.findViewById(R.id.videoTitle);
        playerController.setupNavigationButtons(prevButton, nextButton, titleView);
    }

    private void setupButtonListeners() {
        setupSkipButtons();
        setupEpisodeNavigationButtons();
        setupUtilityButtons();
        
        if (isTelevision) {
            setupTVControls();
        }
    }

    private void setupSkipButtons() {
        ImageButton backward10 = findViewById(R.id.backward_10);
        ImageButton forward10 = findViewById(R.id.forward_10);
        
        backward10.setOnClickListener(v -> playerController.seekBackward(playerController.getSeekDurationMs()));
        forward10.setOnClickListener(v -> playerController.seekForward(playerController.getSeekDurationMs()));
    }

    private void setupEpisodeNavigationButtons() {
        ImageButton prevButton = findViewById(R.id.prev_episode);
        ImageButton nextButton = findViewById(R.id.next_episode);
        
        prevButton.setOnClickListener(v -> playerController.playPreviousEpisode());
        nextButton.setOnClickListener(v -> playerController.playNextEpisode());
    }

    private void setupUtilityButtons() {
        ImageButton btnBack = findViewById(R.id.btnBack);
        ImageButton btnDetails = findViewById(R.id.btnDetails);
        ImageButton btnSpeed = findViewById(R.id.btnSpeed);
        ImageButton btnQuality = findViewById(R.id.btnQuality);
        ImageButton btnEqualizer = findViewById(R.id.btnEqualizer);
        ImageButton btnPip = findViewById(R.id.btnPip);
        ImageButton btnLanguage = findViewById(R.id.btnLanguage);

        btnBack.setOnClickListener(v -> finish());
        btnDetails.setOnClickListener(v -> showVideoDetails());
        btnSpeed.setOnClickListener(v -> showSpeedDialog());
        btnQuality.setOnClickListener(v -> showQualityDialog());
        btnEqualizer.setOnClickListener(v -> showEqualizerDialog());
        if (btnLanguage != null) {
            btnLanguage.setOnClickListener(v -> showLanguageDialog());
        }
        if (btnPip != null) {
            btnPip.setOnClickListener(v -> enterPip());
           
            if (!getPackageManager().hasSystemFeature(
                    android.content.pm.PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
                btnPip.setVisibility(android.view.View.GONE);
            }
        }

      
        androidx.mediarouter.app.MediaRouteButton castButton = findViewById(R.id.castButton);
        if (castManager != null && castManager.isAvailable()) {
            CastButtonFactory.setUpMediaRouteButton(getApplicationContext(), castButton);
            castButton.setVisibility(android.view.View.VISIBLE);
        }
    }

    private void setupTVControls() {
        ImageButton backward10 = findViewById(R.id.backward_10);
        ImageButton forward10 = findViewById(R.id.forward_10);
        ImageButton prevButton = findViewById(R.id.prev_episode);
        ImageButton nextButton = findViewById(R.id.next_episode);
        
        backward10.setOnKeyListener(this::handleKeyEvent);
        forward10.setOnKeyListener(this::handleKeyEvent);
        prevButton.setOnKeyListener(this::handleKeyEvent);
        nextButton.setOnKeyListener(this::handleKeyEvent);
    }

    private boolean handleKeyEvent(View v, int keyCode, KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_DPAD_LEFT:
                    if (v.getId() == R.id.backward_10) {
                        playerController.seekBackward(10000);
                        return true;
                    } else if (v.getId() == R.id.prev_episode) {
                        playerController.playPreviousEpisode();
                        return true;
                    }
                    break;
                case KeyEvent.KEYCODE_DPAD_RIGHT:
                    if (v.getId() == R.id.forward_10) {
                        playerController.seekForward(10000);
                        return true;
                    } else if (v.getId() == R.id.next_episode) {
                        playerController.playNextEpisode();
                        return true;
                    }
                    break;
            }
        }
        return false;
    }

    private void setupResizeModeControls() {
        final int[] resizeModes = {
                AspectRatioFrameLayout.RESIZE_MODE_FIT,
                AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH,
                AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT,
                AspectRatioFrameLayout.RESIZE_MODE_FILL
        };
        final String[] resizeLabels = {"พอดี", "เต็มความกว้าง", "เต็มความสูง", "เต็มจอ"};
        final int[] currentModeIndex = {0};

        binding.playerView.findViewById(R.id.btnRotate).setOnClickListener(v -> {
            int currentOrientation = getResources().getConfiguration().orientation;
            if (currentOrientation == android.content.res.Configuration.ORIENTATION_PORTRAIT) {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            } else {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            }
        });

        binding.playerView.findViewById(R.id.btnResize).setOnClickListener(v -> {
            currentModeIndex[0] = (currentModeIndex[0] + 1) % resizeModes.length;
            binding.playerView.setResizeMode(resizeModes[currentModeIndex[0]]);
            Toast.makeText(this, "โหมด: " + resizeLabels[currentModeIndex[0]], Toast.LENGTH_SHORT).show();
        });
    }

    private void showVideoDetails() {
        videoInfoDialog.showVideoDetails(playerController.getPlayer(), episodes, currentEpisodeIndex);
    }
    
  
    private void castCurrentVideo() {
        if (castManager == null || !castManager.isConnected()) return;
        if (episodes == null || currentEpisodeIndex < 0
                || currentEpisodeIndex >= episodes.size()) return;

        Episode episode = episodes.get(currentEpisodeIndex);
        String videoUrl = episode.getVideoUrl();
        if (videoUrl == null || videoUrl.isEmpty()) {
           
            if (playerController != null && playerController.getPlayer() != null) {
                androidx.media3.common.MediaItem item =
                    playerController.getPlayer().getCurrentMediaItem();
                if (item != null && item.localConfiguration != null) {
                    videoUrl = item.localConfiguration.uri.toString();
                }
            }
        }
        if (videoUrl == null || videoUrl.isEmpty()) return;

        long posMs = 0;
        if (playerController != null && playerController.getPlayer() != null) {
            posMs = playerController.getPlayer().getCurrentPosition();
          
            playerController.getPlayer().pause();
        }

        String title = episode.getTitle() != null ? episode.getTitle()
                       : "ตอนที่ " + episode.getEpisodeNumber();
        String imageUrl = episode.getImageUrl();

        castManager.castVideo(videoUrl, title, imageUrl, posMs);
        android.widget.Toast.makeText(this,
            "กำลังส่งไปยัง TV: " + title, android.widget.Toast.LENGTH_SHORT).show();
    }

    private void showSpeedDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.MaterialAlertDialog);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.speed_dialog, null);
        builder.setView(dialogView);

        RadioGroup speedGroup = dialogView.findViewById(R.id.speed_group);

        float currentSpeed = 1.0f;
        if (playerController != null && playerController.getPlayer() != null) {
            currentSpeed = playerController.getPlayer().getPlaybackParameters().speed;
        }

        if (currentSpeed == 0.5f) {
            speedGroup.check(R.id.speed_0_5);
        } else if (currentSpeed == 1.0f) {
            speedGroup.check(R.id.speed_1_0);
        } else if (currentSpeed == 1.25f) {
            speedGroup.check(R.id.speed_1_25);
        } else if (currentSpeed == 1.5f) {
            speedGroup.check(R.id.speed_1_5);
        } else if (currentSpeed == 2.0f) {
            speedGroup.check(R.id.speed_2_0);
        } else if (currentSpeed == 2.5f) {
            speedGroup.check(R.id.speed_2_5);
        } else if (currentSpeed == 3.0f) {
            speedGroup.check(R.id.speed_3_0);
        }

        builder.setPositiveButton("ตกลง", (dialog, which) -> {
            int checkedId = speedGroup.getCheckedRadioButtonId();
            onSpeedSelected(checkedId);
        });

        builder.setNegativeButton("ยกเลิก", null);
        builder.show();
    }
    
  

    private void showEqualizerDialog() {
        com.example.animeapp.audio.AudioEffectManager eq =
            playerController != null ? playerController.getAudioEffectManager() : null;

        if (eq == null) {
            Toast.makeText(this, "ไม่สามารถเข้าถึงตัวปรับแต่งเสียงได้", Toast.LENGTH_SHORT).show();
            return;
        }

        android.view.LayoutInflater inflater = getLayoutInflater();
        android.view.View dialogView = inflater.inflate(R.layout.equalizer_dialog, null);

       
        android.widget.Switch toggle = dialogView.findViewById(R.id.eq_toggle);
        android.widget.TextView enabledLabel = dialogView.findViewById(R.id.eq_enabled_label);
        toggle.setChecked(eq.isEnabled());
        enabledLabel.setText(eq.isEnabled() ? "เปิด" : "ปิด");
        toggle.setOnCheckedChangeListener((btn, checked) -> {
            eq.setEnabled(checked);
            enabledLabel.setText(checked ? "เปิด" : "ปิด");
        });

      
        android.widget.LinearLayout presetContainer = dialogView.findViewById(R.id.preset_container);
        String[] presets = com.example.animeapp.audio.AudioEffectManager.PRESET_NAMES;
        android.widget.TextView[] presetBtns = new android.widget.TextView[presets.length];

        for (int i = 0; i < presets.length; i++) {
            android.widget.TextView chip = new android.widget.TextView(this);
            chip.setText(presets[i]);
            chip.setTextSize(13f);
            chip.setPadding(24, 12, 24, 12);
            android.widget.LinearLayout.LayoutParams lp =
                new android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMarginEnd(8);
            chip.setLayoutParams(lp);
            chip.setBackground(getDrawable(
                eq.getPreset() == i ? R.drawable.page_btn_active_bg : R.drawable.page_btn_bg));
            chip.setTextColor(eq.getPreset() == i ? 0xFFFFFFFF : 0xFFCCCCCC);
            presetBtns[i] = chip;

            final int idx = i;
            chip.setOnClickListener(v -> {
                eq.applyPreset(idx);
               
                for (int j = 0; j < presetBtns.length; j++) {
                    presetBtns[j].setBackground(getDrawable(
                        j == idx ? R.drawable.page_btn_active_bg : R.drawable.page_btn_bg));
                    presetBtns[j].setTextColor(j == idx ? 0xFFFFFFFF : 0xFFCCCCCC);
                }
              
                new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(
                    () -> refreshBandSliders(dialogView, eq), 50);
            });
            presetContainer.addView(chip);
        }

      
        android.widget.LinearLayout bandsContainer = dialogView.findViewById(R.id.bands_container);
        buildBandSliders(bandsContainer, eq, presetBtns);

        
        android.widget.SeekBar bassBar = dialogView.findViewById(R.id.bass_seekbar);
        android.widget.TextView bassVal = dialogView.findViewById(R.id.bass_value);
        bassBar.setProgress(eq.getBassStrength());
        bassVal.setText((eq.getBassStrength() / 10) + "%");
        bassBar.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(android.widget.SeekBar s, int p, boolean u) {
                eq.setBassStrength((short) p);
                bassVal.setText((p / 10) + "%");
            }
            public void onStartTrackingTouch(android.widget.SeekBar s) {}
            public void onStopTrackingTouch(android.widget.SeekBar s) {}
        });

        android.app.Dialog dialog = new android.app.Dialog(this);
        dialog.setContentView(dialogView);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
            
            // Set dialog width to 85% of screen width or a max value
            android.util.DisplayMetrics displayMetrics = new android.util.DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            int displayWidth = displayMetrics.widthPixels;
            int dialogWidth = (int) (displayWidth * 0.85);
            // Cap width at 550dp to prevent it being too wide on tablets/TVs
            int maxDialogWidth = (int) (550 * displayMetrics.density);
            if (dialogWidth > maxDialogWidth) dialogWidth = maxDialogWidth;

            dialog.getWindow().setLayout(
                dialogWidth,
                android.view.WindowManager.LayoutParams.WRAP_CONTENT
            );
        }
        
        dialogView.findViewById(R.id.btn_eq_close).setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void buildBandSliders(android.widget.LinearLayout container,
                                   com.example.animeapp.audio.AudioEffectManager eq,
                                   android.widget.TextView[] presetBtns) {
        container.removeAllViews();
        int bands = eq.getNumBands();
        short[] range = eq.getBandLevelRange();
        int min = range[0], max = range[1];

        for (short b = 0; b < bands; b++) {
            android.widget.LinearLayout col = new android.widget.LinearLayout(this);
            col.setOrientation(android.widget.LinearLayout.VERTICAL);
            col.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
            android.widget.LinearLayout.LayoutParams colLp =
                new android.widget.LinearLayout.LayoutParams(0,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            col.setLayoutParams(colLp);

            android.widget.TextView dbLabel = new android.widget.TextView(this);
            int curLevelMb = eq.getBandLevel(b);
            dbLabel.setText(formatDb(curLevelMb));
            dbLabel.setTextColor(0xFFC084FC);
            dbLabel.setTextSize(11f);
            dbLabel.setGravity(android.view.Gravity.CENTER);
            col.addView(dbLabel);

            android.widget.SeekBar seekBar = new android.widget.SeekBar(this);
            seekBar.setRotation(270f);
            android.widget.LinearLayout.LayoutParams sbLp =
                new android.widget.LinearLayout.LayoutParams(220, 220);
            seekBar.setLayoutParams(sbLp);
            seekBar.setMax(max - min);
            seekBar.setProgress(curLevelMb - min);
            seekBar.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFFC084FC));
            seekBar.setThumbTintList(android.content.res.ColorStateList.valueOf(0xFFC084FC));

            final short band = b;
            final android.widget.TextView lbl = dbLabel;
            final android.widget.TextView[] pBtns = presetBtns;
            
            final boolean[] isUserTracking = {false};

            seekBar.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
                public void onProgressChanged(android.widget.SeekBar s, int p, boolean fromUser) {
                  
                    short level = (short)(p + min);
                    lbl.setText(formatDb(level));
                   
                    if (isUserTracking[0]) {
                        eq.setBandLevel(band, level);
                        for (android.widget.TextView pBtn : pBtns) {
                            pBtn.setBackground(getDrawable(R.drawable.page_btn_bg));
                            pBtn.setTextColor(0xFFCCCCCC);
                        }
                    }
                }
                public void onStartTrackingTouch(android.widget.SeekBar s) {
                    isUserTracking[0] = true;
                }
                public void onStopTrackingTouch(android.widget.SeekBar s) {
                    isUserTracking[0] = false;
                   
                    short level = (short)(s.getProgress() + min);
                    eq.setBandLevel(band, level);
                }
            });
            col.addView(seekBar);

            android.widget.TextView freqLabel = new android.widget.TextView(this);
            freqLabel.setText(eq.getFreqLabel(b));
            freqLabel.setTextColor(0xFF999999);
            freqLabel.setTextSize(11f);
            freqLabel.setGravity(android.view.Gravity.CENTER);
            col.addView(freqLabel);

            container.addView(col);
        }
    }

    private void refreshBandSliders(android.view.View dialogView,
                                     com.example.animeapp.audio.AudioEffectManager eq) {
        android.widget.LinearLayout container = dialogView.findViewById(R.id.bands_container);
        int bands = eq.getNumBands();
        short[] range = eq.getBandLevelRange();
        int min = range[0];
        for (int i = 0; i < container.getChildCount() && i < bands; i++) {
            android.widget.LinearLayout col = (android.widget.LinearLayout) container.getChildAt(i);
            android.widget.TextView lbl = (android.widget.TextView) col.getChildAt(0);
            android.widget.SeekBar sb  = (android.widget.SeekBar) col.getChildAt(1);
            short level = eq.getBandLevel((short) i);
            sb.setProgress(level - min);
            lbl.setText(formatDb(level));
        }
    }

    private String formatDb(int millibels) {
        int db = millibels / 100;
        return (db >= 0 ? "+" : "") + db + " dB";
    }

    private void showLanguageDialog() {
        if (playerController == null || playerController.getPlayer() == null) {
            Toast.makeText(this, "ไม่สามารถเข้าถึงตัวเล่นวิดีโอได้", Toast.LENGTH_SHORT).show();
            return;
        }

        ExoPlayer player = playerController.getPlayer();
        DefaultTrackSelector trackSelector = playerController.getTrackSelector();

        if (trackSelector == null) {
            Toast.makeText(this, "ไม่สามารถเข้าถึงการตั้งค่าภาษาได้", Toast.LENGTH_SHORT).show();
            return;
        }

        Tracks tracks = player.getCurrentTracks();

      
        List<Tracks.Group> audioGroups = new ArrayList<>();
        for (Tracks.Group group : tracks.getGroups()) {
            if (group.getType() == C.TRACK_TYPE_AUDIO) {
                audioGroups.add(group);
            }
        }

        if (audioGroups.isEmpty()) {
            Toast.makeText(this, "ไม่พบตัวเลือกภาษาเสียง", Toast.LENGTH_SHORT).show();
            return;
        }

      
        List<String> labels = new ArrayList<>();
        List<Tracks.Group> groupRefs = new ArrayList<>();
        List<Integer> trackIndices = new ArrayList<>();

        for (Tracks.Group group : audioGroups) {
            for (int i = 0; i < group.length; i++) {
                Format fmt = group.getTrackFormat(i);
                String lang = fmt.language != null ? fmt.language.toUpperCase() : "ไม่ระบุ";
                String label = getAudioLabel(lang, fmt, labels.size() + 1);
                labels.add(label);
                groupRefs.add(group);
                trackIndices.add(i);
            }
        }

       
        int currentIndex = -1;
        for (int i = 0; i < groupRefs.size(); i++) {
            if (groupRefs.get(i).isTrackSelected(trackIndices.get(i))) {
                currentIndex = i;
                break;
            }
        }
        final int selectedIndex = currentIndex;

        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.MaterialAlertDialog);
        builder.setTitle("เลือกภาษาเสียง");

        String[] labelArray = labels.toArray(new String[0]);
        final int[] chosenIndex = {selectedIndex >= 0 ? selectedIndex : 0};

        builder.setSingleChoiceItems(labelArray, chosenIndex[0], (dialog, which) -> {
            chosenIndex[0] = which;
        });

        builder.setPositiveButton("ตกลง", (dialog, which) -> {
            int idx = chosenIndex[0];
            if (idx < 0 || idx >= groupRefs.size()) return;

            Tracks.Group chosenGroup = groupRefs.get(idx);
            int chosenTrack = trackIndices.get(idx);

          
            DefaultTrackSelector.Parameters.Builder params =
                    trackSelector.buildUponParameters().clearOverridesOfType(C.TRACK_TYPE_AUDIO);

            TrackSelectionOverride override = new TrackSelectionOverride(
                    chosenGroup.getMediaTrackGroup(),
                    java.util.Collections.singletonList(chosenTrack));
            params.addOverride(override);
            trackSelector.setParameters(params.build());

            Toast.makeText(this, "เปลี่ยนภาษาเป็น: " + labels.get(idx), Toast.LENGTH_SHORT).show();
        });

        builder.setNegativeButton("ยกเลิก", null);
        builder.show();
    }

    private String getAudioLabel(String lang, Format fmt, int index) {
      
        String name;
        switch (lang.toLowerCase()) {
            case "th":  case "tha": name = "ไทย";      break;
            case "en":  case "eng": name = "อังกฤษ";   break;
            case "zh":  case "zho": case "cmn": name = "จีน"; break;
            case "ja":  case "jpn": name = "ญี่ปุ่น";  break;
            case "ko":  case "kor": name = "เกาหลี";   break;
            case "hi":  case "hin": name = "ฮินดี";    break;
            default:    name = lang.isEmpty() ? "ภาษา " + index : lang;
        }
       
        if (fmt.channelCount > 0) {
            String ch = fmt.channelCount == 1 ? "Mono" :
                        fmt.channelCount == 2 ? "Stereo" :
                        fmt.channelCount + "ch";
            return name + " (" + ch + ")";
        }
        return name;
    }

    private void selectHighestQuality() {
        if (playerController == null || playerController.getPlayer() == null) return;
        DefaultTrackSelector trackSelector = playerController.getTrackSelector();
        if (trackSelector == null) return;

      
        if (!trackSelector.getParameters().overrides.isEmpty()) return;

        Tracks tracks = playerController.getPlayer().getCurrentTracks();
        Format bestFormat = null;
        Tracks.Group bestGroup = null;
        int bestTrackIndex = -1;

        for (Tracks.Group group : tracks.getGroups()) {
            if (group.getType() != C.TRACK_TYPE_VIDEO) continue;
            for (int i = 0; i < group.length; i++) {
                if (!group.isTrackSupported(i)) continue;
                Format fmt = group.getTrackFormat(i);
                if (bestFormat == null || fmt.height > bestFormat.height
                        || (fmt.height == bestFormat.height && fmt.bitrate > bestFormat.bitrate)) {
                    bestFormat = fmt;
                    bestGroup = group;
                    bestTrackIndex = i;
                }
            }
        }

        if (bestGroup != null && bestTrackIndex >= 0) {
            TrackSelectionOverride override = new TrackSelectionOverride(
                    bestGroup.getMediaTrackGroup(),
                    java.util.Collections.singletonList(bestTrackIndex));
            trackSelector.setParameters(
                    trackSelector.buildUponParameters()
                            .clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                            .addOverride(override)
                            .build());
        }
    }

    private void showQualityDialog() {
        if (playerController == null || playerController.getPlayer() == null) {
            Toast.makeText(this, "ไม่สามารถเข้าถึงตัวเล่นวิดีโอได้", Toast.LENGTH_SHORT).show();
            return;
        }

        ExoPlayer player = playerController.getPlayer();
        DefaultTrackSelector trackSelector = playerController.getTrackSelector();
        
        if (trackSelector == null) {
            Toast.makeText(this, "ไม่สามารถเข้าถึงการตั้งค่าคุณภาพได้", Toast.LENGTH_SHORT).show();
            return;
        }

        Tracks tracks = player.getCurrentTracks();
        List<Tracks.Group> videoGroups = new ArrayList<>();
        
        for (Tracks.Group trackGroup : tracks.getGroups()) {
            if (trackGroup.getType() == C.TRACK_TYPE_VIDEO) {
                videoGroups.add(trackGroup);
            }
        }

        if (videoGroups.isEmpty()) {
            Toast.makeText(this, "ไม่พบตัวเลือกคุณภาพวิดีโอ", Toast.LENGTH_SHORT).show();
            return;
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.MaterialAlertDialog);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.quality_dialog, null);
        builder.setView(dialogView);

        RadioGroup qualityGroup = dialogView.findViewById(R.id.quality_group);
        qualityGroup.removeAllViews();

        android.widget.RadioButton autoButton = new android.widget.RadioButton(this);
        autoButton.setText("อัตโนมัติ");
        autoButton.setTextColor(ContextCompat.getColor(this, android.R.color.white));
        autoButton.setTextSize(16);
        autoButton.setPadding(16, 16, 16, 16);
        autoButton.setId(View.generateViewId());
        qualityGroup.addView(autoButton);

        boolean isAutoMode = trackSelector.getParameters().overrides.isEmpty();
        Format currentFormat = getCurrentSelectedFormat(trackSelector, videoGroups);
        
        if (isAutoMode) {
            autoButton.setChecked(true);
        }

        List<Format> formats = new ArrayList<>();
        for (Tracks.Group group : videoGroups) {
            for (int i = 0; i < group.length; i++) {
                Format format = group.getTrackFormat(i);
                if (!formats.contains(format)) {
                    formats.add(format);
                }
            }
        }

        formats.sort((f1, f2) -> Integer.compare(f2.height, f1.height));

        for (int i = 0; i < formats.size(); i++) {
            Format format = formats.get(i);
            String qualityLabel = getQualityLabel(format);
            
            android.widget.RadioButton radioButton = new android.widget.RadioButton(this);
            radioButton.setText(qualityLabel);
            radioButton.setTextColor(ContextCompat.getColor(this, android.R.color.white));
            radioButton.setTextSize(16);
            radioButton.setPadding(16, 16, 16, 16);
            radioButton.setTag(format);
            radioButton.setId(View.generateViewId());
            
            qualityGroup.addView(radioButton);

            if (!isAutoMode && currentFormat != null) {
                if (format.height == currentFormat.height && 
                    Math.abs(format.bitrate - currentFormat.bitrate) < 100000) {
                    radioButton.setChecked(true);
                    autoButton.setChecked(false);
                }
            }
        }

        final int autoButtonId = autoButton.getId();

        builder.setPositiveButton("ตกลง", (dialog, which) -> {
            int selectedId = qualityGroup.getCheckedRadioButtonId();
            
            if (selectedId == autoButtonId) {
                trackSelector.setParameters(
                    trackSelector.buildUponParameters()
                        .clearOverrides()
                        .clearVideoSizeConstraints()
                        .setForceHighestSupportedBitrate(true)
                        .build()
                );
                
                if (playerController != null && playerController.getPlayer() != null) {
                    long currentPosition = playerController.getPlayer().getCurrentPosition();
                    playerController.getPlayer().seekTo(currentPosition);
                }
                
                Toast.makeText(this, "ตั้งค่าเป็นโหมดอัตโนมัติ (คุณภาพสูงสุด)", Toast.LENGTH_SHORT).show();
            } else {
                android.widget.RadioButton selectedButton = dialogView.findViewById(selectedId);
                if (selectedButton != null && selectedButton.getTag() instanceof Format) {
                    Format selectedFormat = (Format) selectedButton.getTag();
                    setVideoQuality(selectedFormat, trackSelector, videoGroups);
                    Toast.makeText(this, "เปลี่ยนคุณภาพเป็น: " + getQualityLabel(selectedFormat), Toast.LENGTH_SHORT).show();
                }
            }
        });

        builder.setNegativeButton("ยกเลิก", null);
        builder.show();
    }

    private Format getCurrentSelectedFormat(DefaultTrackSelector trackSelector, List<Tracks.Group> videoGroups) {
        if (trackSelector.getParameters().overrides.isEmpty()) {
            return null;
        }
        
        if (playerController != null && playerController.getPlayer() != null) {
            Tracks currentTracks = playerController.getPlayer().getCurrentTracks();
            for (Tracks.Group group : currentTracks.getGroups()) {
                if (group.getType() == C.TRACK_TYPE_VIDEO && group.isSelected()) {
                    for (int i = 0; i < group.length; i++) {
                        if (group.isTrackSelected(i)) {
                            return group.getTrackFormat(i);
                        }
                    }
                }
            }
        }
        
        return null;
    }

    private String getQualityLabel(Format format) {
        if (format.height == Format.NO_VALUE) {
            return "ไม่ทราบ";
        }
        
        String resolution = format.height + "p";
        String bitrate = "";
        
        if (format.bitrate != Format.NO_VALUE) {
            int bitrateKbps = format.bitrate / 1000;
            bitrate = String.format(Locale.getDefault(), " (%d kbps)", bitrateKbps);
        }
        
        return resolution + bitrate;
    }

    private void setVideoQuality(Format selectedFormat, DefaultTrackSelector trackSelector, List<Tracks.Group> videoGroups) {
        for (Tracks.Group group : videoGroups) {
            for (int i = 0; i < group.length; i++) {
                Format format = group.getTrackFormat(i);
                
                if (format.height == selectedFormat.height && format.bitrate == selectedFormat.bitrate) {
                    TrackSelectionOverride override = new TrackSelectionOverride(
                        group.getMediaTrackGroup(),
                        i
                    );
                    
                    trackSelector.setParameters(
                        trackSelector.buildUponParameters()
                            .clearOverrides()
                            .clearVideoSizeConstraints()
                            .setOverrideForType(override)
                            .setForceHighestSupportedBitrate(false)
                            .build()
                    );
                    
                    if (playerController != null && playerController.getPlayer() != null) {
                        long currentPosition = playerController.getPlayer().getCurrentPosition();
                        playerController.getPlayer().seekTo(currentPosition);
                    }
                    return;
                }
            }
        }
    }
    
    public void onSpeedSelected(int id) {
        float speed = 1.0f;

        if (id == R.id.speed_0_5) {
            speed = 0.5f;
        } else if (id == R.id.speed_1_0) {
            speed = 1.0f;
        } else if (id == R.id.speed_1_25) {
            speed = 1.25f;
        } else if (id == R.id.speed_1_5) {
            speed = 1.5f;
        } else if (id == R.id.speed_2_0) {
            speed = 2.0f;
        } else if (id == R.id.speed_2_5) {
            speed = 2.5f;
        } else if (id == R.id.speed_3_0) {
            speed = 3.0f;
        }

        if (playerController != null && playerController.getPlayer() != null) {
            playerController.getPlayer().setPlaybackSpeed(speed);
            Toast.makeText(this, "ความเร็ว: " + speed + "x", Toast.LENGTH_SHORT).show();
        }
    }

    private void hideSystemUI() {
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        WindowInsetsControllerCompat controller = new WindowInsetsControllerCompat(getWindow(), getWindow().getDecorView());
        controller.hide(WindowInsetsCompat.Type.systemBars());
        controller.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
    }

   
    private static final int PIP_ACTION_PLAY  = 1;
    private static final int PIP_ACTION_PAUSE = 2;

  
    private android.app.PictureInPictureParams buildPipParams() {
        android.app.PictureInPictureParams.Builder builder =
            new android.app.PictureInPictureParams.Builder();

      
        builder.setAspectRatio(new android.util.Rational(16, 9));

       
        boolean isPlaying = playerController != null
            && playerController.getPlayer() != null
            && playerController.getPlayer().isPlaying();

        int iconRes    = isPlaying ? android.R.drawable.ic_media_pause
                                   : android.R.drawable.ic_media_play;
        int titleRes   = isPlaying ? R.string.pause : R.string.play;
        int requestCode = isPlaying ? PIP_ACTION_PAUSE : PIP_ACTION_PLAY;

        android.app.PendingIntent pipIntent = android.app.PendingIntent.getBroadcast(
            this,
            requestCode,
            new android.content.Intent(PIP_ACTION_BROADCAST).putExtra("action", requestCode),
            android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE
        );

        android.app.RemoteAction action = new android.app.RemoteAction(
            android.graphics.drawable.Icon.createWithResource(this, iconRes),
            getString(titleRes),
            getString(titleRes),
            pipIntent
        );

        builder.setActions(java.util.Collections.singletonList(action));
        return builder.build();
    }

    private static final String PIP_ACTION_BROADCAST = "com.example.animeapp.PIP_ACTION";

    
    private final android.content.BroadcastReceiver pipReceiver =
        new android.content.BroadcastReceiver() {
            @Override
            public void onReceive(android.content.Context ctx, android.content.Intent intent) {
                if (intent == null || playerController == null
                        || playerController.getPlayer() == null) return;
                int action = intent.getIntExtra("action", 0);
                if (action == PIP_ACTION_PLAY) {
                    playerController.getPlayer().play();
                } else if (action == PIP_ACTION_PAUSE) {
                    playerController.getPlayer().pause();
                }
               
                updatePipActions();
            }
        };

   
    public void updatePipActions() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O
                && isInPictureInPictureMode()) {
            setPictureInPictureParams(buildPipParams());
        }
    }

  
    private void enterPip() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            enterPictureInPictureMode(buildPipParams());
        }
    }

    @Override
    public void onPictureInPictureModeChanged(boolean isInPiP,
            android.content.res.Configuration config) {
        super.onPictureInPictureModeChanged(isInPiP, config);
        if (isInPiP) {
            pipActive = true;
            binding.playerView.setUseController(false);
        } else {
           
            binding.playerView.setUseController(true);
            scheduleControllerAutoHide();
            hideSystemUI();
        }
    }

  
   
    private boolean pipActive = false;
   
    private boolean resumedAfterPip = false;

    @Override
    protected void onResume() {
        super.onResume();
        resumedAfterPip = true;
        pipActive = false;
        if (castManager != null) castManager.onResume();
        if (playerController != null) playerController.attachToActivity();
        scheduleControllerAutoHide();
        hideSystemUI();
    }

    @Override
    public void onUserLeaveHint() {
        super.onUserLeaveHint();
        SharedPreferences sp = getSharedPreferences("AnimeAppPrefs", MODE_PRIVATE);
        boolean pipAuto = sp.getBoolean("pip_auto", true);
        if (pipAuto && playerController != null && playerController.getPlayer() != null
                && playerController.getPlayer().isPlaying()) {
            enterPip();
        }
    }

    
    @Override
    public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
        if (playerController == null || playerController.getPlayer() == null)
            return super.onKeyDown(keyCode, event);

        if (isPlayerControlFocused() && keyCodeToFocusDirection(keyCode) != 0
                && binding.playerView.isControllerFullyVisible()) {
            return super.onKeyDown(keyCode, event);
        }

        ExoPlayer player = playerController.getPlayer();
        long seekMs = playerController.getSeekDurationMs();

        switch (keyCode) {
          
            case android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case android.view.KeyEvent.KEYCODE_DPAD_CENTER:
            case android.view.KeyEvent.KEYCODE_ENTER:
            case android.view.KeyEvent.KEYCODE_SPACE:
                if (player.isPlaying()) player.pause(); else player.play();
                return true;

            case android.view.KeyEvent.KEYCODE_MEDIA_PLAY:
                player.play(); return true;

            case android.view.KeyEvent.KEYCODE_MEDIA_PAUSE:
                player.pause(); return true;

            case android.view.KeyEvent.KEYCODE_MEDIA_STOP:
                player.pause(); finish(); return true;

           
            case android.view.KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
            case android.view.KeyEvent.KEYCODE_MEDIA_SKIP_FORWARD:
                playerController.seekForward(seekMs); return true;

            case android.view.KeyEvent.KEYCODE_MEDIA_REWIND:
            case android.view.KeyEvent.KEYCODE_MEDIA_SKIP_BACKWARD:
                playerController.seekBackward(seekMs); return true;

           
            case android.view.KeyEvent.KEYCODE_DPAD_LEFT:
                playerController.seekBackward(seekMs); return true;

            case android.view.KeyEvent.KEYCODE_DPAD_RIGHT:
                playerController.seekForward(seekMs); return true;

           
            case android.view.KeyEvent.KEYCODE_DPAD_UP:
            case android.view.KeyEvent.KEYCODE_VOLUME_UP:
                if (brightnessVolumeManager != null) brightnessVolumeManager.stepVolume(1);
                return true;

            case android.view.KeyEvent.KEYCODE_DPAD_DOWN:
            case android.view.KeyEvent.KEYCODE_VOLUME_DOWN:
                if (brightnessVolumeManager != null) brightnessVolumeManager.stepVolume(-1);
                return true;

           
            case android.view.KeyEvent.KEYCODE_MEDIA_NEXT:
            case android.view.KeyEvent.KEYCODE_PAGE_DOWN:
                playerController.playNextEpisode(); return true;

            case android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS:
            case android.view.KeyEvent.KEYCODE_PAGE_UP:
                playerController.playPreviousEpisode(); return true;

           
            case android.view.KeyEvent.KEYCODE_BACK:
                finish(); return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (pipActive) {
          
            if (playerController != null) playerController.releasePlayer();
        } else if (!isInPictureInPictureMode()) {
           
            if (playerController != null) playerController.pausePlayer();
        }
      
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try { unregisterReceiver(pipReceiver); } catch (Exception ignored) {}
        if (castManager != null) castManager.onPause();
        if (playerController != null) playerController.releasePlayer();
    }

    @Override
    protected void onPause() {
        super.onPause();
        resumedAfterPip = false;
        saveCurrentPlaybackPosition();
        if (!isInPictureInPictureMode()) {
            if (playerController != null) playerController.pausePlayer();
        }
    }

    public static void start(AppCompatActivity activity, List<Episode> episodes, int currentIndex, String animeTitle, String animeUrl) {
        Intent intent = new Intent(activity, VideoPlayerActivity.class);
        intent.putParcelableArrayListExtra("EPISODES", new ArrayList<>(episodes));
        intent.putExtra("CURRENT_INDEX", currentIndex);
        intent.putExtra("ANIME_TITLE", animeTitle);
        intent.putExtra("ANIME_URL", animeUrl);
        activity.startActivity(intent);
    }

    public static void start(AppCompatActivity activity, Episode episode, String animeTitle, String animeUrl) {
        Intent intent = new Intent(activity, VideoPlayerActivity.class);
        intent.putExtra("EPISODE", episode);
        intent.putExtra("ANIME_TITLE", animeTitle);
        intent.putExtra("ANIME_URL", animeUrl);
        activity.startActivity(intent);
    }
}
