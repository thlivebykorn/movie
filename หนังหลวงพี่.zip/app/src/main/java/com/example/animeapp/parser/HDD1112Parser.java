package com.example.animeapp.parser;

import android.util.Base64;
import android.util.Log;

import com.example.animeapp.models.Anime;
import com.example.animeapp.models.Episode;
import com.example.animeapp.models.HostListModel;
import com.example.animeapp.network.OkHttpClientFactory;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.example.animeapp.domain.DomainConfig;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class HDD1112Parser implements AnimeParser {
    private static final String TAG = "HDD1112Parser";

    private final OkHttpClient client;
    private final Gson gson = new Gson();
    private String referer;
    private String animeImageUrl;

    public HDD1112Parser() {
        this.client = OkHttpClientFactory.getClientWithDoH();
    }

    private boolean isAllowedReferer(String referer) {
        String configured = DomainConfig.BaseUrl.HDD1112();
        Matcher matcher = Pattern.compile("https?://([^/]+)").matcher(referer);
        String host = matcher.find() ? matcher.group(1) : referer;

        if (configured != null && !configured.isEmpty() && host.endsWith(configured)) {
            return true;
        }
        return host.equals("1112hdss.com") || host.equals("1112hdc.com");
    }

    @Override
    public Anime parseAnimeDetail(Document doc) throws IOException {
        this.referer = doc.baseUri();

        if (!isAllowedReferer(this.referer)) {
            throw new IOException("ไม่สามารถดึงข้อมูลซีรี่ย์ได้");
        }

        Anime parsed = com.example.animeapp.parser.NativeParseBridge.parseAnimeDetail("hdd1112", doc);
        String title = parsed.getTitle();
        this.animeImageUrl = parsed.getImageUrl();

        if (this.animeImageUrl == null || this.animeImageUrl.isEmpty()) {
            this.animeImageUrl = "https://" + DomainConfig.BaseUrl.HDD1112() + "/wp-content/themes/cj/assets/images/default-poster.jpg";
        }

        List<Episode> episodes = parsed.getEpisodes();
        if (episodes == null || episodes.isEmpty()) {
            episodes = parseEpisodes(doc, this.animeImageUrl);
        }
        return new Anime(title, doc.baseUri(), this.animeImageUrl, episodes);
    }

    @Override
    public List<Episode> parseEpisodes(Document doc, String imageUrl) {
        List<Episode> episodes = com.example.animeapp.parser.NativeParseBridge.parseEpisodes("hdd1112", doc, imageUrl);
        if (!episodes.isEmpty()) {
            return episodes;
        }

        Log.d(TAG, "cjPlayerMeta not found, trying AJAX fallback");
        String postId = extractPostId(doc);

        if (postId == null) {
            Log.e(TAG, "parseEpisodes: missing postId for AJAX fallback");
            return new ArrayList<>();
        }

        return fetchEpisodesFromApi(postId, imageUrl);
    }

    private List<Episode> parseEpisodesFromCjPlayerMeta(Document doc, String imageUrl) {
        List<Episode> episodes = new ArrayList<>();

        for (Element script : doc.select("script")) {
            String html = script.html();
            int idx = html.indexOf("window.cjPlayerMeta");
            if (idx < 0) continue;

            String after = html.substring(idx + "window.cjPlayerMeta".length()).trim();
            int eq = after.indexOf('=');
            if (eq < 0) continue;

            String value = after.substring(eq + 1).trim();
            JsonObject meta = null;

            if (value.startsWith("{")) {
                int start = 0;
                int depth = 0;
                int end = -1;
                for (int i = 0; i < value.length(); i++) {
                    char c = value.charAt(i);
                    if (c == '{') depth++;
                    else if (c == '}') {
                        depth--;
                        if (depth == 0) { end = i + 1; break; }
                    }
                }
                if (end < 0) continue;
                try {
                    meta = JsonParser.parseString(value.substring(start, end)).getAsJsonObject();
                    Log.d(TAG, "Parsed inline cjPlayerMeta JSON");
                } catch (Exception e) {
                    Log.e(TAG, "Failed to parse cjPlayerMeta JSON: " + e.getMessage());
                }
            } else {
                int q1 = value.indexOf('"');
                int q2 = value.indexOf('"', q1 + 1);
                if (q1 < 0 || q2 < 0) continue;

                String encoded = value.substring(q1 + 1, q2).replace("\\/", "/");
                String postId = extractPostId(doc);
                meta = decryptMeta(encoded, postId);
                if (meta == null) {
                    Log.e(TAG, "Failed to decrypt cjPlayerMeta");
                } else {
                    Log.d(TAG, "Decrypted inline cjPlayerMeta");
                }
            }

            if (meta == null) continue;

            episodes = parseEpisodesFromMeta(meta, imageUrl);
            if (!episodes.isEmpty()) break;
        }

        return episodes;
    }

    private List<Episode> parseEpisodesFromMeta(JsonObject meta, String imageUrl) {
        List<Episode> episodes = new ArrayList<>();

        try {
            if (!meta.has("series")) return episodes;
            JsonObject series = meta.getAsJsonObject("series");
            if (!series.has("videos")) return episodes;
            JsonObject videos = series.getAsJsonObject("videos");

            String[] versions = {"th", "sub"};
            for (String ver : versions) {
                if (!videos.has(ver)) continue;
                JsonObject versionObj = videos.getAsJsonObject(ver);
                if (!versionObj.has("list") || !versionObj.get("list").isJsonObject()) continue;

                JsonObject list = versionObj.getAsJsonObject("list");
                int totalEp = versionObj.has("total_ep") ? versionObj.get("total_ep").getAsInt() : 0;
                if (totalEp <= 0) {
                    for (String key : list.keySet()) {
                        if (key.startsWith("ep_")) totalEp++;
                    }
                }

                for (int i = 1; i <= totalEp; i++) {
                    String epKey = "ep_" + i;
                    if (!list.has(epKey)) continue;

                    JsonObject epData = list.getAsJsonObject(epKey);
                    String videoUrl = null;

                    if (epData.has("server_1") && epData.getAsJsonObject("server_1").has("url")) {
                        videoUrl = epData.getAsJsonObject("server_1").get("url").getAsString();
                    } else if (epData.has("server_2") && epData.getAsJsonObject("server_2").has("url")) {
                        videoUrl = epData.getAsJsonObject("server_2").get("url").getAsString();
                    }

                    if (videoUrl != null) {
                        String torboEmbed = extractTorboEmbedUrl(videoUrl);
                        String resolved = resolveVideoUrl(videoUrl);
                        String epReferer = torboEmbed != null ? torboEmbed : referer;
                        Log.d(TAG, "cjPlayerMeta EP." + i + " -> " + resolved);
                        episodes.add(new Episode(
                            "EP." + i,
                            resolved,
                            imageUrl,
                            "",
                            epReferer,
                            i
                        ));
                    }
                }

                if (!episodes.isEmpty()) break;
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to parse meta: " + e.getMessage());
        }

        return episodes;
    }

    private JsonObject decryptMeta(String encoded, String postId) {
        if (encoded == null || encoded.isEmpty() || postId == null || postId.isEmpty()) {
            return null;
        }
        try {
            String salt = "cj_s3cur3_pl@y3r_2026";
            String key = md5Hex(postId + "_" + salt);
            if (key == null) return null;

            byte[] raw = Base64.decode(encoded, Base64.DEFAULT);
            byte[] decrypted = rc4(key.getBytes(StandardCharsets.US_ASCII), raw);
            String jsonStr = new String(decrypted, StandardCharsets.UTF_8);

            return JsonParser.parseString(jsonStr).getAsJsonObject();
        } catch (Exception e) {
            Log.e(TAG, "decryptMeta error: " + e.getMessage(), e);
            return null;
        }
    }

    private byte[] rc4(byte[] key, byte[] data) {
        int[] s = new int[256];
        for (int i = 0; i < 256; i++) s[i] = i;

        int j = 0;
        for (int i = 0; i < 256; i++) {
            j = (j + s[i] + (key[i % key.length] & 0xff)) % 256;
            int tmp = s[i];
            s[i] = s[j];
            s[j] = tmp;
        }

        byte[] out = new byte[data.length];
        int i = 0;
        int k = 0;
        for (int x = 0; x < data.length; x++) {
            i = (i + 1) % 256;
            k = (k + s[i]) % 256;
            int tmp = s[i];
            s[i] = s[k];
            s[k] = tmp;
            out[x] = (byte) (data[x] ^ s[(s[i] + s[k]) % 256]);
        }
        return out;
    }

    private String md5Hex(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] digest = md.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) {
                sb.append(Character.forDigit((b >> 4) & 0xf, 16));
                sb.append(Character.forDigit(b & 0xf, 16));
            }
            return sb.toString();
        } catch (Exception e) {
            Log.e(TAG, "md5Hex error: " + e.getMessage());
            return null;
        }
    }

    private String resolveVideoUrl(String url) {
        String torbo = extractTorboStreamUrl(url);
        if (torbo != null) return torbo;
        return url;
    }

    private String extractTorboEmbedUrl(String url) {
        String unescaped = url.replace("\\/", "/");
        Matcher matcher = Pattern.compile(
            "(https?://[^/]+/(?:embed|play)/[A-Za-z0-9]{32})",
            Pattern.CASE_INSENSITIVE
        ).matcher(unescaped);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return null;
    }

    private String extractTorboStreamUrl(String text) {
        String unescaped = text.replace("\\/", "/");
        Matcher matcher = Pattern.compile(
            "(https?://[^/]+)/(?:embed|play)/([A-Za-z0-9]{32})",
            Pattern.CASE_INSENSITIVE
        ).matcher(unescaped);
        if (matcher.find()) {
            return matcher.group(1) + "/api/stream/" + matcher.group(2) + "/index.m3u8";
        }
        return null;
    }

    private List<Episode> fetchEpisodesFromApi(String postId, String animeImageUrl) {
        List<Episode> episodes = new ArrayList<>();

        try {
            String url = "https://" + DomainConfig.BaseUrl.HDD1112() + "/wp-admin/admin-ajax.php";
            MediaType formMediaType = MediaType.parse("application/x-www-form-urlencoded");
            RequestBody body = RequestBody.create(
                "action=single_get_videos&post_id=" + postId,
                formMediaType
            );

            Request request = new Request.Builder()
                    .url(url)
                    .post(body)
                    .build();

            try (Response response = client.newCall(request).execute()) {
                if (!response.isSuccessful()) {
                    throw new IOException("API failed: " + response.code());
                }

                String json = response.body().string();
                Log.d(TAG, "API response: " + json);

                JsonObject root = JsonParser.parseString(json).getAsJsonObject();

                if (!root.has("success") || !root.get("success").getAsBoolean()) {
                    throw new IOException("API success=false");
                }

                JsonElement data = root.get("data");
                JsonObject meta = null;

                if (data != null && data.isJsonObject()) {
                    meta = data.getAsJsonObject();
                } else if (data != null && data.isJsonPrimitive()) {
                    String encoded = data.getAsString().replace("\\/", "/");
                    meta = decryptMeta(encoded, postId);
                }

                if (meta == null) {
                    Log.e(TAG, "No usable meta from API for postId=" + postId);
                    return episodes;
                }

                episodes = parseEpisodesFromMeta(meta, animeImageUrl);
            }

        } catch (Exception e) {
            Log.e(TAG, "fetchEpisodesFromApi error: " + e.getMessage(), e);
        }

        return episodes;
    }

    private String extractPostId(Document doc) {
        Element script = doc.selectFirst("script#wp-postviews-cache-js-extra");
        if (script != null) {
            String js = script.data();
            Pattern pattern = Pattern.compile("\"post_id\":\"(\\d+)\"");
            Matcher matcher = pattern.matcher(js);
            if (matcher.find()) {
                return matcher.group(1);
            }
        }

        for (Element s : doc.select("script")) {
            String js = s.html();
            Matcher matcher = Pattern.compile("const\\s+postId\\s*=\\s*(\\d+)").matcher(js);
            if (matcher.find()) {
                return matcher.group(1);
            }
        }
        return null;
    }

    @Override
    public String parseVideoUrl(Document epDoc, String referer, int episodeNumber) throws IOException {
        this.referer = referer;
        String videoUrl = epDoc.baseUri();

        String torboUrl = extractTorboStreamUrl(videoUrl);
        if (torboUrl != null) return torboUrl;

        if (videoUrl.contains("online225.com") || videoUrl.contains("oklive-1.xyz") || videoUrl.contains("mycdn-hd.xyz") || videoUrl.contains("ok-nah.com") || videoUrl.contains("play-heyhd.com")) {
            try {
                Request request = new Request.Builder()
                        .url(videoUrl)
                        .header("User-Agent", "Mozilla/5.0")
                        .header("Referer", referer)
                        .build();

                try (Response response = client.newCall(request).execute()) {
                    if (!response.isSuccessful()) {
                        return videoUrl;
                    }

                    String html = response.body().string();
                    Document playerDoc = Jsoup.parse(html);

                    Element iframe = playerDoc.selectFirst("iframe[src]");
                    if (iframe != null) {
                        return iframe.absUrl("src");
                    }

                    return extractFromPageScript(html);
                }

            } catch (IOException e) {
                return videoUrl;
            }
        }

        return videoUrl;
    }

    private String extractFromPageScript(String html) throws IOException {
        Pattern scriptPattern = Pattern.compile("<script[^>]*>(.*?)</script>", Pattern.DOTALL);
        Matcher scriptMatcher = scriptPattern.matcher(html);

        while (scriptMatcher.find()) {
            String scriptContent = scriptMatcher.group(1);

            
            if (scriptContent.contains("sources") && scriptContent.contains("file")) {
                Pattern jwSourcePattern = Pattern.compile(
                    "sources\\s*:\\s*\\[\\s*\\{\\s*file\\s*:\\s*\"([^\"]+\\.m3u8[^\"]*)\"",
                    Pattern.DOTALL
                );
                Matcher jwMatcher = jwSourcePattern.matcher(scriptContent);
                if (jwMatcher.find()) {
                    String fileUrl = jwMatcher.group(1);
                    Log.d(TAG, "Extracted JWPlayer source URL: " + fileUrl);
                    return fileUrl;
                }
            }

            if (scriptContent.contains("videoSources")) {
                Pattern videoServerPattern = Pattern.compile("\"videoServer\":\"(\\d+)\"");
                Pattern videoSourcesPattern = Pattern.compile("\"videoSources\":\\[\\{\"file\":\"([^\"]+)\"");
                Pattern hostListPattern = Pattern.compile("\"hostList\":(\\{.*?\\})");

                Matcher videoServerMatcher = videoServerPattern.matcher(scriptContent);
                Matcher videoSourcesMatcher = videoSourcesPattern.matcher(scriptContent);
                Matcher hostListMatcher = hostListPattern.matcher(scriptContent);

                if (videoServerMatcher.find() && videoSourcesMatcher.find() && hostListMatcher.find()) {
                    String videoServer = videoServerMatcher.group(1);
                    String videoFile = videoSourcesMatcher.group(1);
                    String hostListJson = hostListMatcher.group(1);

                    HostListModel hostList = gson.fromJson("{\"hostList\":" + hostListJson + "}", HostListModel.class);

                    List<String> selectedDomainList = hostList.getHostList().get(videoServer);
                    if (selectedDomainList != null && !selectedDomainList.isEmpty()) {
                        String domain = selectedDomainList.get(0)
                                .replace("[", "")
                                .replace("]", "")
                                .replace("'", "")
                                .trim();

                        String videoUrlResult = videoFile.replaceAll(
                                "https:\\\\/\\\\/\\d+\\\\/cdn\\\\/hls\\\\/",
                                "https://" + domain + "/api/files/"
                        );

                        videoUrlResult = videoUrlResult.replace("\\/", "/");

                        return videoUrlResult;
                    }
                }
            }
        }

        throw new IOException("ไม่พบ video URL ในสคริปต์");
    }
}
