package com.example.animeapp.adapters;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.animeapp.R;
import com.example.animeapp.models.HistoryItem;
import com.google.android.material.card.MaterialCardView;

import java.util.List;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {

    private List<HistoryItem>          historyList;
    private OnHistoryItemClickListener listener;

   
    private static final int COLOR_STROKE_NORMAL  = Color.parseColor("#1F1635"); 
    private static final int COLOR_STROKE_FOCUSED = Color.parseColor("#9B6FD4"); 
    private static final int COLOR_BG_NORMAL      = Color.parseColor("#13131F"); 
    private static final int COLOR_BG_FOCUSED     = Color.parseColor("#1E1830");
    private static final int COLOR_BAR_NORMAL     = Color.parseColor("#7B5EA7"); 
    private static final int COLOR_BAR_FOCUSED    = Color.parseColor("#C084FC"); 

    public interface OnHistoryItemClickListener {
        void onHistoryItemClick(HistoryItem item);
    }

    public HistoryAdapter(List<HistoryItem> historyList, OnHistoryItemClickListener listener) {
        this.historyList = historyList;
        this.listener    = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_history, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        HistoryItem item = historyList.get(position);

        holder.titleText.setText(item.getTitle());
        holder.episodeText.setText("ตอนที่ " + item.getEpisode());
        holder.timeText.setText(item.getFormattedTimestamp());

        if (item.getImageUrl() != null && !item.getImageUrl().isEmpty()) {
            Glide.with(holder.itemView.getContext())
                .load(item.getImageUrl())
                .placeholder(R.drawable.placeholder_image)
                .error(R.drawable.warning)
                .into(holder.historyImage);
        } else {
            holder.historyImage.setImageResource(R.drawable.placeholder_image);
        }

        holder.itemView.setOnClickListener(v -> listener.onHistoryItemClick(item));

       
        holder.itemView.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                holder.card.setStrokeColor(COLOR_STROKE_FOCUSED);
                holder.card.setStrokeWidth(dpToPx(holder.itemView, 2));
               
                if (holder.accentBar != null)
                    holder.accentBar.setBackgroundColor(COLOR_BAR_FOCUSED);
              
                holder.itemView.animate().scaleX(1.02f).scaleY(1.02f).setDuration(120).start();
            } else {
                holder.card.setStrokeColor(COLOR_STROKE_NORMAL);
                holder.card.setStrokeWidth(dpToPx(holder.itemView, 1));

                if (holder.accentBar != null)
                    holder.accentBar.setBackgroundColor(COLOR_BAR_NORMAL);
                holder.itemView.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
            }
        });
    }

    private int dpToPx(View view, int dp) {
        float density = view.getContext().getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }

    @Override
    public int getItemCount() { return historyList.size(); }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView       titleText, episodeText, timeText;
        ImageView      historyImage;
        MaterialCardView card;
        View           accentBar;

        public ViewHolder(View itemView) {
            super(itemView);
            historyImage = itemView.findViewById(R.id.history_image);
            titleText    = itemView.findViewById(R.id.title_text);
            episodeText  = itemView.findViewById(R.id.episode_text);
            timeText     = itemView.findViewById(R.id.time_text);
            card         = itemView.findViewById(R.id.history_card);
            accentBar    = itemView.findViewById(R.id.accent_bar);
        }
    }
}
