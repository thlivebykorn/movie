package com.example.animeapp.sources;

import android.util.Log;
import com.example.animeapp.models.AnimeItem;
import com.example.animeapp.models.PageItem;
import com.example.animeapp.network.OkHttpClientFactory;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import com.example.animeapp.domain.DomainConfig;

public class WatchLakornSource implements AnimeSource {

    private static final String TAG = "WatchLakornSource";
    private static final String FALLBACK_DOMAIN = "www.watchlakorn.org";
    private static final String UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

    private final OkHttpClient client;

    public WatchLakornSource() {
        this.client = OkHttpClientFactory.getClientWithDoH();
    }

    private String getDomain() {
        String domain = DomainConfig.BaseUrl.WATCHLAKORN();
        if (domain == null || domain.isEmpty()) return FALLBACK_DOMAIN;
        return domain;
    }

    private String baseUrl() {
        return "https://" + getDomain();
    }

    @Override
    public String getSourceName() {
        return DomainConfig.SourceName.WATCHLAKORN();
    }

    @Override
    public String getBaseUrl() {
        return baseUrl();
    }

    @Override
    public String getSearchUrl(String keyword) {
        try {
            return baseUrl() + "/api.php?action=search&q=" + java.net.URLEncoder.encode(keyword, "UTF-8");
        } catch (Exception e) {
            return baseUrl() + "/api.php?action=search&q=" + keyword;
        }
    }

    @Override
    public void fetchAnimeList(String pageUrl, AnimeLoadCallback callback) {
        new Thread(() -> {
            try {
                if (pageUrl != null && pageUrl.contains("api.php?")) {
                    try {
                        fetchJsonList(pageUrl, callback);
                        return;
                    } catch (Exception jsonErr) {
                        Log.e(TAG, "JSON list failed, fallback to HTML parse", jsonErr);
                    }
                }

                fetchHtmlList(pageUrl, callback);
            } catch (Exception e) {
                Log.e(TAG, "Error fetching list: " + e.getMessage(), e);
                callback.onFailure("เกิดข้อผิดพลาด: " + e.getMessage());
            }
        }).start();
    }

    

    private void fetchJsonList(String pageUrl, AnimeLoadCallback callback) throws Exception {
        Log.d(TAG, "Fetching JSON list from: " + pageUrl);

        Request request = new Request.Builder()
            .url(pageUrl)
            .header("User-Agent", UA)
            .header("Accept", "application/json, text/plain, */*")
            .header("Referer", baseUrl() + "/")
            .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new Exception("HTTP error: " + response.code());
            }
            String body = response.body().string();
            JSONObject root = new JSONObject(body);

            String action = queryParam(pageUrl, "action");
            if (action == null || action.isEmpty()) action = "get_all";

            JSONArray items = root.optJSONArray("items");
            List<AnimeItem> animeItems = new ArrayList<>();
            if (items != null) {
                for (int i = 0; i < items.length(); i++) {
                    JSONObject obj = items.optJSONObject(i);
                    if (obj == null) continue;

                    String title = obj.optString("title", "");
                    if (title.isEmpty()) title = obj.optString("series_name", "");
                    if (title.isEmpty()) continue;

                    long categoryId = obj.optLong("category_id", 0L);
                    String image = normalizeImage(obj.optString("image", ""));
                    String url;
                    if (categoryId > 0) {
                        url = seriesDetailUrl(categoryId);
                    } else {
                        long vid = obj.optLong("id", 0L);
                        url = vid > 0 ? playerUrl(vid) : pageUrl;
                    }

                    String latestEpisode = "";
                    if (obj.has("total_episodes")) {
                        latestEpisode = "ตอน " + obj.optInt("total_episodes");
                    } else if (obj.has("episode_display")) {
                        latestEpisode = obj.optString("episode_display");
                    }
                    animeItems.add(new AnimeItem(title, url, image, "", latestEpisode));
                }
            }

            List<PageItem> pages = buildPages(root, pageUrl, action);
            callback.onSuccess(animeItems, pages);
        }
    }

    private List<PageItem> buildPages(JSONObject root, String pageUrl, String action) throws Exception {
        List<PageItem> pages = new ArrayList<>();
        int totalPages = root.optInt("total_pages", 1);
        if (totalPages <= 1) return pages;

        int currentPage = 1;
        try {
            currentPage = Integer.parseInt(queryParam(pageUrl, "page"));
        } catch (Exception ignored) {}

        String group = queryParam(pageUrl, "group");
        for (int p = 1; p <= totalPages; p++) {
            String q = "/api.php?action=" + action + "&page=" + p;
            if (group != null && !group.isEmpty()) q += "&group=" + group;
            boolean isCurrent = (p == currentPage);
            pages.add(new PageItem(String.valueOf(p), baseUrl() + q, isCurrent));
        }
        return pages;
    }

    private String seriesDetailUrl(long categoryId) {
        return baseUrl() + "/api.php?action=get_series_detail&id=" + categoryId
                + "&category_id=" + categoryId + "&page=1";
    }

    private String playerUrl(long videoId) {
        return baseUrl() + "/api.php?action=get_player&id=" + videoId;
    }

    private static String queryParam(String url, String key) {
        try {
            java.net.URI uri = new java.net.URI(url);
            java.util.Map<String, String> params = new java.util.HashMap<>();
            String query = uri.getRawQuery();
            if (query != null) {
                for (String part : query.split("&")) {
                    int idx = part.indexOf('=');
                    if (idx < 0) continue;
                    String k = java.net.URLDecoder.decode(part.substring(0, idx), "UTF-8");
                    String v = java.net.URLDecoder.decode(part.substring(idx + 1), "UTF-8");
                    params.put(k, v);
                }
            }
            return params.get(key);
        } catch (Exception e) {
            return null;
        }
    }

    private static String normalizeImage(String image) {
        if (image == null || image.isEmpty()) return "";
        if (image.startsWith("//")) return "https:" + image;
        return image;
    }

   

    private void fetchHtmlList(String pageUrl, AnimeLoadCallback callback) throws Exception {
        Log.d(TAG, "Fetching HTML list from: " + pageUrl);

        Request request = new Request.Builder()
            .url(pageUrl)
            .header("User-Agent", UA)
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .header("Referer", baseUrl() + "/")
            .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                callback.onFailure("HTTP error: " + response.code());
                return;
            }

            String html = response.body().string();
            if (html.length() < 100) {
                callback.onFailure("ได้รับข้อมูลน้อยเกินไป");
                return;
            }

            Document doc = Jsoup.parse(html, pageUrl);
            com.example.animeapp.parser.NativeParseBridge.SourceListResult nativeResult = com.example.animeapp.parser.NativeParseBridge.parseSourceList("watchlakorn", doc);
            List<AnimeItem> items = nativeResult.animeItems;
            List<PageItem> pages = nativeResult.pageItems;

            callback.onSuccess(items, pages);
        }
    }

    private List<AnimeItem> parseAnimeItems(Document doc) {
        return com.example.animeapp.parser.NativeParseBridge.parseSourceList("watchlakorn", doc).animeItems;
    }

    private List<PageItem> parsePageItems(Document doc, String pageUrl) {
        return com.example.animeapp.parser.NativeParseBridge.parseSourceList("watchlakorn", doc).pageItems;
    }
}