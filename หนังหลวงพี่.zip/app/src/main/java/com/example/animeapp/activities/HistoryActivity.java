package com.example.animeapp.activities;

import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.animeapp.R;
import com.example.animeapp.adapters.HistoryAdapter;
import com.example.animeapp.database.DatabaseHelper;
import com.example.animeapp.models.Episode;
import com.example.animeapp.models.HistoryItem;

import java.util.ArrayList;
import java.util.List;

import it.xabaras.android.recyclerview.swipedecorator.RecyclerViewSwipeDecorator;
import androidx.core.view.WindowCompat;
import com.example.animeapp.dialogs.CustomLoadingDialog;
import androidx.core.content.IntentCompat;
import android.os.Looper;
import android.os.Handler;

public class HistoryActivity extends AppCompatActivity {

   
    public static final String EXTRA_TAB = "tab";
    public static final String TAB_HISTORY   = "history";
    public static final String TAB_FAVORITES = "favorites";

    private String currentTab = TAB_HISTORY;

    private List<HistoryItem>                     historyList;
    private List<DatabaseHelper.FavoriteItem>     favoriteList;

    private HistoryAdapter   historyAdapter;
    private FavoritesAdapter favoritesAdapter;

    private DatabaseHelper dbHelper;
    private TextView       emptyText;
    private RecyclerView   recyclerView;

   
    private TextView tabHistory;
    private TextView tabFavorites;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.VANILLA_ICE_CREAM) {
            WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        }

        setContentView(R.layout.activity_history);

        dbHelper = new DatabaseHelper(this);

       
        String tab = getIntent().getStringExtra(EXTRA_TAB);
        if (TAB_FAVORITES.equals(tab)) currentTab = TAB_FAVORITES;

        initializeViews();
        setupWindowInsets();
        setupToolbar();
        setupTabs();
        loadTab(currentTab);
        setupSwipeToDelete();
    }

   
    private void initializeViews() {
        recyclerView = findViewById(R.id.history_recycler_view);
        emptyText    = findViewById(R.id.empty_history_text);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    private void setupWindowInsets() {
        View rootView = findViewById(android.R.id.content);
        ViewCompat.setOnApplyWindowInsetsListener(rootView, (v, windowInsets) -> {
            Insets insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());
            Toolbar toolbar = findViewById(R.id.toolbar);
            if (toolbar != null) {
                toolbar.setPadding(
                    toolbar.getPaddingLeft(), insets.top,
                    toolbar.getPaddingRight(), toolbar.getPaddingBottom());
            }
            return WindowInsetsCompat.CONSUMED;
        });
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        toolbar.post(() -> {
            for (int i = 0; i < toolbar.getChildCount(); i++) {
                View child = toolbar.getChildAt(i);
                if (child instanceof android.widget.ImageButton) {
                    makeToolbarButtonTvFocusable(child);
                }
            }
        });
    }

    private void makeToolbarButtonTvFocusable(View view) {
        view.setFocusable(true);
        view.setFocusableInTouchMode(false);
        view.setClickable(true);
        view.setBackgroundResource(R.drawable.focus_background);
        int pad = dp(8);
        view.setPadding(pad, pad, pad, pad);
    }

  
    private void setupTabs() {
        LinearLayout tabBar = new LinearLayout(this);
        tabBar.setOrientation(LinearLayout.HORIZONTAL);
        tabBar.setBackgroundColor(0xFF1A1A1A);

        tabHistory   = makeTabButton("📋 ประวัติการดู");
        tabFavorites = makeTabButton("⭐ รายการโปรด");

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tabBar.addView(tabHistory, lp);
        tabBar.addView(tabFavorites, lp);

        ViewGroup parent = (ViewGroup) recyclerView.getParent();
        int idx = parent.indexOfChild(recyclerView);
        parent.addView(tabBar, idx);

        tabHistory.setOnClickListener(v -> loadTab(TAB_HISTORY));
        tabFavorites.setOnClickListener(v -> loadTab(TAB_FAVORITES));
        tabHistory.setOnFocusChangeListener((v, hasFocus) -> highlightTab(currentTab));
        tabFavorites.setOnFocusChangeListener((v, hasFocus) -> highlightTab(currentTab));
        tabHistory.setOnKeyListener((v, keyCode, event) -> handleTabKey(keyCode, event));
        tabFavorites.setOnKeyListener((v, keyCode, event) -> handleTabKey(keyCode, event));
        highlightTab(currentTab);
    }

    private TextView makeTabButton(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(14f);
        tv.setPadding(dp(16), dp(14), dp(16), dp(14));
        tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        tv.setClickable(true);
        tv.setFocusable(true);
        tv.setFocusableInTouchMode(false);
        return tv;
    }

    private boolean handleTabKey(int keyCode, android.view.KeyEvent event) {
        if (event.getAction() != android.view.KeyEvent.ACTION_DOWN) return false;
        if (keyCode == android.view.KeyEvent.KEYCODE_DPAD_LEFT) {
            tabHistory.requestFocus();
            loadTab(TAB_HISTORY);
            return true;
        }
        if (keyCode == android.view.KeyEvent.KEYCODE_DPAD_RIGHT) {
            tabFavorites.requestFocus();
            loadTab(TAB_FAVORITES);
            return true;
        }
        return false;
    }

    private void highlightTab(String tab) {
        if (tabHistory == null || tabFavorites == null) return;
        boolean isHistory = TAB_HISTORY.equals(tab);
        styleTab(tabHistory, isHistory);
        styleTab(tabFavorites, !isHistory);
    }

    private void styleTab(TextView tabView, boolean selected) {
        boolean focused = tabView.hasFocus();
        tabView.setTextColor(selected || focused ? 0xFFB084FC : 0xFF888888);

        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
        bg.setColor(focused ? 0xFF2A1F4A : (selected ? 0xFF2A1A4A : 0xFF1A1A1A));
        if (focused) {
            bg.setStroke(dp(2), 0xFFC084FC);
        }
        tabView.setBackground(bg);
    }

  
    private void loadTab(String tab) {
        currentTab = tab;
        highlightTab(tab);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(
                TAB_FAVORITES.equals(tab) ? "⭐ รายการโปรด" : "📋 ประวัติการดู");
        }

        if (TAB_FAVORITES.equals(tab)) {
            loadFavorites();
        } else {
            loadHistoryData();
        }
    }

   
    private void loadHistoryData() {
        historyList = dbHelper.getAllHistory();
        if (historyList == null || historyList.isEmpty()) {
            showEmpty("ยังไม่มีประวัติการดู");
        } else {
            emptyText.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
            historyAdapter = new HistoryAdapter(historyList, this::onHistoryItemClick);
            recyclerView.setAdapter(historyAdapter);
        }
    }

    
    private void loadFavorites() {
        favoriteList = dbHelper.getAllFavorites();
        if (favoriteList == null || favoriteList.isEmpty()) {
            showEmpty("ยังไม่มีรายการโปรด\nกดไอคอน ⭐ บนหน้าอนิเมะเพื่อเพิ่ม");
        } else {
            emptyText.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
            favoritesAdapter = new FavoritesAdapter(favoriteList);
            recyclerView.setAdapter(favoritesAdapter);
            focusFirstRecyclerItem();
        }
    }

    private void focusFirstRecyclerItem() {
        recyclerView.post(() -> {
            if (recyclerView.getAdapter() == null || recyclerView.getAdapter().getItemCount() == 0) {
                return;
            }

            RecyclerView.ViewHolder holder = recyclerView.findViewHolderForAdapterPosition(0);
            if (holder != null) {
                holder.itemView.requestFocus();
            } else {
                recyclerView.scrollToPosition(0);
                recyclerView.post(() -> {
                    RecyclerView.ViewHolder firstHolder = recyclerView.findViewHolderForAdapterPosition(0);
                    if (firstHolder != null) firstHolder.itemView.requestFocus();
                });
            }
        });
    }

    private void showEmpty(String msg) {
        emptyText.setText(msg);
        emptyText.setVisibility(View.VISIBLE);
        recyclerView.setVisibility(View.GONE);
    }

  
    private void setupSwipeToDelete() {
        ItemTouchHelper.SimpleCallback callback = new ItemTouchHelper.SimpleCallback(
                0, ItemTouchHelper.LEFT) {
            @Override
            public boolean onMove(@NonNull RecyclerView rv,
                                  @NonNull RecyclerView.ViewHolder vh,
                                  @NonNull RecyclerView.ViewHolder target) {
                return false;
            }
            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder vh, int direction) {
                deleteItem(vh.getBindingAdapterPosition());
            }
            @Override
            public void onChildDraw(@NonNull Canvas c,
                                    @NonNull RecyclerView rv,
                                    @NonNull RecyclerView.ViewHolder vh,
                                    float dX, float dY, int actionState,
                                    boolean isCurrentlyActive) {
                new RecyclerViewSwipeDecorator.Builder(
                        c, rv, vh, dX, dY, actionState, isCurrentlyActive)
                    .addSwipeLeftBackgroundColor(
                        ContextCompat.getColor(HistoryActivity.this, R.color.red))
                    .addSwipeLeftActionIcon(R.drawable.ic_delete)
                    .create().decorate();
                super.onChildDraw(c, rv, vh, dX, dY, actionState, isCurrentlyActive);
            }
        };
        new ItemTouchHelper(callback).attachToRecyclerView(recyclerView);
    }

    private void deleteItem(int position) {
        if (TAB_FAVORITES.equals(currentTab)) {
          
            if (favoriteList == null || position >= favoriteList.size()) return;
            DatabaseHelper.FavoriteItem item = favoriteList.get(position);
            dbHelper.removeFavorite(item.animeUrl);
            favoriteList.remove(position);
            if (favoritesAdapter != null) favoritesAdapter.notifyItemRemoved(position);
            if (favoriteList.isEmpty()) showEmpty("ยังไม่มีรายการโปรด");
            Toast.makeText(this, "ลบออกจากรายการโปรดแล้ว", Toast.LENGTH_SHORT).show();
        } else {
           
            if (historyList == null || position >= historyList.size()) return;
            HistoryItem item = historyList.get(position);
            dbHelper.deleteHistory(item.getId());
            historyList.remove(position);
            if (historyAdapter != null) historyAdapter.notifyItemRemoved(position);
            if (historyList.isEmpty()) showEmpty("ยังไม่มีประวัติการดู");
            Toast.makeText(this, "ลบรายการแล้ว", Toast.LENGTH_SHORT).show();
        }
    }

   
    private void onHistoryItemClick(HistoryItem item) {
        CustomLoadingDialog progressDialog = new CustomLoadingDialog(this);
        progressDialog.setMessage("กำลังโหลดข้อมูล...");
        progressDialog.show();

        new Thread(() -> {
            try {
                com.example.animeapp.models.Anime anime =
                    com.example.animeapp.network.AnimeApiClient.fetchAnimeData(item.getAnimeUrl(), null);
                List<Episode> episodes = anime.getEpisodes();

                int currentIndex = -1;
                String targetEpisodeUrl = item.getEpisodeUrl();
                for (int i = 0; i < episodes.size(); i++) {
                    if (episodes.get(i).getInfoUrl().equals(targetEpisodeUrl)) {
                        currentIndex = i; break;
                    }
                }
                if (currentIndex == -1) {
                    try {
                        int targetEpNum = Integer.parseInt(item.getEpisode());
                        for (int i = 0; i < episodes.size(); i++) {
                            if (episodes.get(i).getEpisodeNumber() == targetEpNum) {
                                currentIndex = i; break;
                            }
                        }
                    } catch (NumberFormatException ignored) {}
                }

                final int finalIndex = currentIndex;
                runOnUiThread(() -> {
                    if (finalIndex == -1) {
                        progressDialog.dismiss();
                        Toast.makeText(this, "ไม่พบข้อมูลตอนในรายการปัจจุบัน",
                            Toast.LENGTH_SHORT).show();
                        return;
                    }
                    progressDialog.setMessage("กำลังเตรียมวิดีโอ...");
                    new Thread(() -> {
                        try {
                            Episode ep = episodes.get(finalIndex);
                            String videoUrl = com.example.animeapp.network.AnimeApiClient
                                .fetchVideoUrl(ep.getInfoUrl(), ep.getReferer(),
                                    ep.getEpisodeNumber());
                            runOnUiThread(() -> {
                                progressDialog.dismiss();
                                if (videoUrl != null && !videoUrl.isEmpty()) {
                                    ep.setVideoUrl(videoUrl);
                                    VideoPlayerActivity.start(this, episodes, finalIndex,
                                        item.getTitle(), item.getAnimeUrl());
                                } else {
                                    Toast.makeText(this, "ไม่พบลิงก์วิดีโอ",
                                        Toast.LENGTH_SHORT).show();
                                }
                            });
                        } catch (Exception e) {
                            runOnUiThread(() -> {
                                progressDialog.dismiss();
                                Toast.makeText(this, "เกิดข้อผิดพลาดในการโหลดวิดีโอ",
                                    Toast.LENGTH_SHORT).show();
                            });
                        }
                    }).start();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, "เกิดข้อผิดพลาด: " + e.getMessage(),
                        Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

   
    private class FavoritesAdapter
            extends RecyclerView.Adapter<FavoritesAdapter.VH> {

        private final List<DatabaseHelper.FavoriteItem> items;

        FavoritesAdapter(List<DatabaseHelper.FavoriteItem> items) {
            this.items = items;
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
           
            LinearLayout card = new LinearLayout(parent.getContext());
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setBackgroundResource(R.drawable.history_item_focus_bg);
            card.setPadding(dp(12), dp(12), dp(12), dp(12));
            card.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
            RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(dp(12), dp(6), dp(12), dp(6));
            card.setLayoutParams(lp);
            card.setClickable(true);
            card.setFocusable(true);
            card.setFocusableInTouchMode(false);

            ImageView img = new ImageView(parent.getContext());
            LinearLayout.LayoutParams imgLp = new LinearLayout.LayoutParams(dp(80), dp(110));
            imgLp.setMarginEnd(dp(12));
            img.setLayoutParams(imgLp);
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            img.setTag("img");

            LinearLayout textBlock = new LinearLayout(parent.getContext());
            textBlock.setOrientation(LinearLayout.VERTICAL);
            textBlock.setLayoutParams(new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            TextView tvTitle = new TextView(parent.getContext());
            tvTitle.setTextColor(Color.WHITE);
            tvTitle.setTextSize(15f);
            tvTitle.setTag("title");

            TextView tvSource = new TextView(parent.getContext());
            tvSource.setTextColor(0xFF888888);
            tvSource.setTextSize(12f);
            tvSource.setPadding(0, dp(4), 0, 0);
            tvSource.setTag("source");

            TextView tvLastEp = new TextView(parent.getContext());
            tvLastEp.setTextColor(0xFFB084FC);
            tvLastEp.setTextSize(12f);
            tvLastEp.setPadding(0, dp(4), 0, 0);
            tvLastEp.setTag("lastep");

            textBlock.addView(tvTitle);
            textBlock.addView(tvSource);
            textBlock.addView(tvLastEp);

            card.addView(img);
            card.addView(textBlock);

            return new VH(card, img, tvTitle, tvSource, tvLastEp);
        }

        @Override
        public void onBindViewHolder(@NonNull VH holder, int position) {
            DatabaseHelper.FavoriteItem item = items.get(position);
            holder.tvTitle.setText(item.title);
            holder.tvSource.setText("🌐 " + item.sourceName);
            holder.tvLastEp.setText(
                item.lastEpisode != null && !item.lastEpisode.isEmpty()
                    ? "ล่าสุด: " + item.lastEpisode
                    : "ยังไม่ได้ดู");

           
            loadFavoriteImage(holder.img, item);

            holder.itemView.setOnClickListener(v -> onFavoriteItemClick(item));
            holder.itemView.setOnFocusChangeListener((v, hasFocus) -> {
                v.setSelected(hasFocus);
                v.animate()
                    .scaleX(hasFocus ? 1.02f : 1f)
                    .scaleY(hasFocus ? 1.02f : 1f)
                    .setDuration(120)
                    .start();
            });
        }

        @Override
        public int getItemCount() { return items.size(); }

        class VH extends RecyclerView.ViewHolder {
            ImageView img;
            TextView tvTitle, tvSource, tvLastEp;
            VH(View v, ImageView img, TextView t, TextView s, TextView le) {
                super(v);
                this.img = img; tvTitle = t; tvSource = s; tvLastEp = le;
            }
        }
    }

  
    private void onFavoriteItemClick(DatabaseHelper.FavoriteItem item) {
      
        AnimeDetailActivity.start(this, item.animeUrl, item.title);
    }

  
    private void loadFavoriteImage(ImageView imageView, DatabaseHelper.FavoriteItem item) {
        if (item.imageUrl != null && !item.imageUrl.isEmpty()) {
            Glide.with(imageView.getContext())
                .load(item.imageUrl)
                .placeholder(android.R.color.darker_gray)
                .error(android.R.drawable.ic_menu_gallery)
                .into(imageView);
            return;
        }

       
        imageView.setBackgroundColor(0xFF2A2A2A);
        new Thread(() -> {
            try {
                com.example.animeapp.models.Anime anime =
                    com.example.animeapp.network.AnimeApiClient.fetchAnimeData(item.animeUrl, null);
                String fetchedUrl = anime != null ? anime.getImageUrl() : null;
                if (fetchedUrl != null && !fetchedUrl.isEmpty()) {
                   
                    item.imageUrl = fetchedUrl;
                    dbHelper.addFavorite(item.title, item.animeUrl,
                        fetchedUrl, item.sourceName, item.lastEpisode);

                    runOnUiThread(() ->
                        Glide.with(imageView.getContext())
                            .load(fetchedUrl)
                            .placeholder(android.R.color.darker_gray)
                            .error(android.R.drawable.ic_menu_gallery)
                            .into(imageView)
                    );
                }
            } catch (Exception ignored) {}
        }).start();
    }

   
    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        if (dbHelper != null) dbHelper.close();
        super.onDestroy();
    }

    @Override
    public boolean onSupportNavigateUp() {
        getOnBackPressedDispatcher().onBackPressed();
        return true;
    }
}
