package com.example.animeapp.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import com.example.animeapp.workers.FavoriteCheckWorker;

import java.util.concurrent.TimeUnit;


public class BootReceiver extends BroadcastReceiver {

    private static final String TAG = "BootReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (action == null) return;

        if (Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)
                || "android.intent.action.QUICKBOOT_POWERON".equals(action)) {

            Log.d(TAG, "Boot/Update detected → rescheduling FavoriteCheckWorker");
            scheduleFavoriteCheck(context);
        }
    }

    private void scheduleFavoriteCheck(Context ctx) {
        try {
           
            PeriodicWorkRequest work = new PeriodicWorkRequest.Builder(
                    FavoriteCheckWorker.class, 3, TimeUnit.HOURS, 30, TimeUnit.MINUTES)
                    .build();

            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
                    "favorite_check",
                    ExistingPeriodicWorkPolicy.UPDATE,
                    work
            );

           
            androidx.work.OneTimeWorkRequest oneTime =
                    new androidx.work.OneTimeWorkRequest.Builder(FavoriteCheckWorker.class)
                            .setInitialDelay(2, TimeUnit.MINUTES) 
                            .build();
            WorkManager.getInstance(ctx).enqueueUniqueWork(
                    "favorite_check_boot",
                    androidx.work.ExistingWorkPolicy.REPLACE,
                    oneTime
            );

            Log.d(TAG, "FavoriteCheckWorker scheduled successfully after boot");
        } catch (Exception e) {
            Log.e(TAG, "Failed to schedule worker: " + e.getMessage());
        }
    }
}
