package com.example.animeapp.activities;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;

import com.example.animeapp.R;
import com.example.animeapp.auth.SessionManager;
import com.example.animeapp.domain.DomainConfig;
import com.example.animeapp.model.Category;
import com.example.animeapp.model.Source;
import com.example.animeapp.models.AnimeItem;
import com.example.animeapp.models.PageItem;
import com.example.animeapp.network.ServerApiClient;
import com.example.animeapp.security.AppSecurityManager;
import com.example.animeapp.sources.AnimeSource;
import com.example.animeapp.sources.AnimemojiSource;
import com.example.animeapp.sources.FixmonoSource;
import com.example.animeapp.sources.GoSeriesSource;
import com.example.animeapp.sources.Hdd1112Source;
import com.example.animeapp.sources.Hdd123Source;
import com.example.animeapp.sources.Hd24Source;
import com.example.animeapp.sources.SeriesDaySource;
import com.example.animeapp.sources.WatchLakornSource;
import com.example.animeapp.sources.HdMediaSource;
import com.example.animeapp.sources.WowDramaSource;
import com.example.animeapp.startup.StartupDataCache;

import org.json.JSONObject;

import java.util.List;

public class SplashActivity extends AppCompatActivity {

    private static final long LOGO_APPEAR_MS = 600L;
    private static final long TAGLINE_DELAY_MS = 400L;
    private static final long HOLD_MS = 800L;
    private static final long PRELOAD_TIMEOUT_MS = 10000L;
    private static final String PREF_NAME = "AnimeAppPrefs";
    private static final String KEY_DEFAULT_SOURCE = "default_source_id";

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private boolean animationFinished = false;
    private boolean preloadFinished = false;
    private boolean firstPageRequestStarted = false;
    private boolean mainStarted = false;
    private boolean gateRunning = false;

    private View gateUi;
    private TextView gateTitle;
    private TextView gateMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);

        setContentView(R.layout.activity_splash);
        com.example.animeapp.network.AnimeApiClient.init(this);

        gateUi = findViewById(R.id.splash_gate_ui);
        gateTitle = findViewById(R.id.gate_title);
        gateMessage = findViewById(R.id.gate_message);
        findViewById(R.id.gate_retry).setOnClickListener(v -> runGate());
        findViewById(R.id.gate_logout).setOnClickListener(v -> forceLogout("ออกจากระบบแล้ว"));

        startSplashAnimation();

        getOnBackPressedDispatcher().addCallback(this, new androidx.activity.OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
               
            }
        });

        long totalAnimMs = LOGO_APPEAR_MS + TAGLINE_DELAY_MS + 350;
        mainHandler.postDelayed(() -> {
            animationFinished = true;
            runGate();
            startMainWhenReady();
        }, totalAnimMs + HOLD_MS);
    }

    private void startSplashAnimation() {
        TextView loadingText = findViewById(R.id.splash_loading_text);
        View showcase = findViewById(R.id.splash_showcase);
        View brandGroup = findViewById(R.id.splash_brand_group);
        View progressGroup = findViewById(R.id.splash_progress_group);
        View progressFill = findViewById(R.id.splash_progress_fill);
        View glowTop = findViewById(R.id.splash_glow_top);
        View glowBottom = findViewById(R.id.splash_glow_bottom);

        showcase.setAlpha(0f);
        showcase.setTranslationY(26f);
        brandGroup.setAlpha(0f);
        brandGroup.setTranslationY(18f);
        progressGroup.setAlpha(0f);
        progressGroup.setTranslationY(18f);
        progressFill.setAlpha(0f);

        ObjectAnimator showcaseAlpha = ObjectAnimator.ofFloat(showcase, "alpha", 0f, 1f);
        ObjectAnimator showcaseSlide = ObjectAnimator.ofFloat(showcase, "translationY", 26f, 0f);
        ObjectAnimator brandAlpha = ObjectAnimator.ofFloat(brandGroup, "alpha", 0f, 1f);
        ObjectAnimator brandSlide = ObjectAnimator.ofFloat(brandGroup, "translationY", 18f, 0f);
        ObjectAnimator progressGroupAlpha = ObjectAnimator.ofFloat(progressGroup, "alpha", 0f, 1f);
        ObjectAnimator progressGroupSlide = ObjectAnimator.ofFloat(progressGroup, "translationY", 18f, 0f);
        ObjectAnimator progressAlpha = ObjectAnimator.ofFloat(progressFill, "alpha", 0f, 1f);

        showcaseAlpha.setDuration(520);
        showcaseSlide.setDuration(620);
        brandAlpha.setDuration(420);
        brandSlide.setDuration(520);
        progressGroupAlpha.setDuration(360);
        progressGroupSlide.setDuration(460);
        progressAlpha.setDuration(260);

        brandAlpha.setStartDelay(260);
        brandSlide.setStartDelay(260);
        progressGroupAlpha.setStartDelay(520);
        progressGroupSlide.setStartDelay(520);
        progressAlpha.setStartDelay(620);

        AnimatorSet introSet = new AnimatorSet();
        introSet.playTogether(
            showcaseAlpha,
            showcaseSlide,
            brandAlpha,
            brandSlide,
            progressGroupAlpha,
            progressGroupSlide,
            progressAlpha
        );
        introSet.start();

        ObjectAnimator progressMove = ObjectAnimator.ofFloat(progressFill, "translationX", -150f, 280f);
        progressMove.setDuration(1050);
        progressMove.setRepeatCount(ObjectAnimator.INFINITE);
        progressMove.setInterpolator(new AccelerateDecelerateInterpolator());
        progressMove.start();

        startAmbientSplashMotion(showcase, brandGroup, loadingText, glowTop, glowBottom);
    }

    private void startAmbientSplashMotion(
            View showcase,
            View brandGroup,
            View loadingText,
            View glowTop,
            View glowBottom) {
        mainHandler.postDelayed(() -> {
            ObjectAnimator showcaseFloat = ObjectAnimator.ofFloat(showcase, "translationY", 0f, -8f, 0f);
            showcaseFloat.setDuration(1800);
            showcaseFloat.setRepeatCount(ValueAnimator.INFINITE);
            showcaseFloat.setInterpolator(new AccelerateDecelerateInterpolator());

            ObjectAnimator brandFloat = ObjectAnimator.ofFloat(brandGroup, "translationY", 0f, -5f, 0f);
            brandFloat.setDuration(2100);
            brandFloat.setRepeatCount(ValueAnimator.INFINITE);
            brandFloat.setInterpolator(new AccelerateDecelerateInterpolator());

            ObjectAnimator loadingPulse = ObjectAnimator.ofFloat(loadingText, "alpha", 0.58f, 1f, 0.58f);
            loadingPulse.setDuration(1350);
            loadingPulse.setRepeatCount(ValueAnimator.INFINITE);
            loadingPulse.setInterpolator(new AccelerateDecelerateInterpolator());

            ObjectAnimator topGlow = ObjectAnimator.ofFloat(glowTop, "alpha", 0.36f, 0.52f, 0.36f);
            topGlow.setDuration(2100);
            topGlow.setRepeatCount(ValueAnimator.INFINITE);

            ObjectAnimator bottomGlow = ObjectAnimator.ofFloat(glowBottom, "alpha", 0.2f, 0.32f, 0.2f);
            bottomGlow.setDuration(2400);
            bottomGlow.setRepeatCount(ValueAnimator.INFINITE);

            showcaseFloat.start();
            brandFloat.start();
            loadingPulse.start();
            topGlow.start();
            bottomGlow.start();
        }, 820);
    }

    private void runGate() {
        if (gateRunning) return;
        gateRunning = true;

        if (!AppSecurityManager.isSignatureValid(this)) {
            gateRunning = false;
            showTamperDialog();
            return;
        }

        if (!SessionManager.hasSession(this)) {
            gateRunning = false;
            openLogin();
            return;
        }

        new Thread(() -> {
            try {
                JSONObject res = ServerApiClient.checkSession(SplashActivity.this);
                String status = res.optString("status", "pending");
                runOnUiThread(() -> {
                    gateRunning = false;
                    handleGateStatus(status);
                });
            } catch (ServerApiClient.ApiException e) {
                runOnUiThread(() -> {
                    gateRunning = false;
                    handleGateError(e.code, e.getMessage());
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    gateRunning = false;
                    handleGateError(null, e.getMessage());
                });
            }
        }).start();
    }

    private void handleGateStatus(String status) {
        if ("approved".equals(status)) {
            preloadFirstAnimePage();
        } else if ("pending".equals(status)) {
            showGateUi("รอการอนุมัติ", "บัญชีของคุณยังไม่ได้รับการอนุมัติจากแอดมิน\nกรุณารอสักครู่แล้วลองใหม่");
        } else if ("banned".equals(status)) {
            forceLogout("บัญชีของคุณถูกระงับการใช้งาน");
        } else {
            preloadFirstAnimePage();
        }
    }

    private void handleGateError(String code, String message) {
        if (code == null) {
            showGateUi("การเชื่อมต่อล้มเหลว", "ไม่สามารถติดต่อเซิร์ฟเวอร์ได้\nกรุณาตรวจสอบอินเทอร์เน็ตแล้วลองใหม่");
            return;
        }
        switch (code) {
            case "KICKED":
                forceLogout("บัญชีนี้ถูกใช้บนเครื่องอื่น");
                break;
            case "BANNED":
                forceLogout("บัญชีของคุณถูกระงับการใช้งาน");
                break;
            case "AUTH_REQUIRED":
                forceLogout("เซสชันหมดอายุ กรุณาเข้าสู่ระบบใหม่");
                break;
            case "PENDING":
                showGateUi("รอการอนุมัติ", "บัญชีของคุณยังไม่ได้รับการอนุมัติจากแอดมิน\nกรุณารอสักครู่แล้วลองใหม่");
                break;
            case "TAMPERED":
                showTamperDialog();
                break;
            case "OUTDATED":
            case "MAINTENANCE":
                showGateUi("แจ้งเตือน", message != null ? message : "กรุณาอัปเดตแอปเป็นเวอร์ชันล่าสุด");
                break;
            default:
                showGateUi("การเชื่อมต่อล้มเหลว", message != null ? message : "ไม่สามารถติดต่อเซิร์ฟเวอร์ได้");
                break;
        }
    }

    private void showGateUi(String title, String message) {
        if (gateUi == null) return;
        gateUi.setVisibility(View.VISIBLE);
        gateTitle.setText(title);
        gateMessage.setText(message);
    }

    private void forceLogout(String message) {
        SessionManager.clear(this);
        ServerApiClient.logout(this);
        if (message != null) {
            new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("แจ้งเตือน")
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton("ตกลง", (d, w) -> openLogin())
                .show();
        } else {
            openLogin();
        }
    }

    private void showTamperDialog() {
        new androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("แอปมีการดัดแปลง")
            .setMessage("ไม่สามารถใช้งานแอปได้ กรุณาดาวน์โหลดจากต้นฉบับ")
            .setCancelable(false)
            .setPositiveButton("ปิด", (d, w) -> finishAffinity())
            .show();
    }

    private void openLogin() {
        Intent intent = new Intent(this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        overridePendingTransition(0, 0);
        finish();
    }

    private void preloadFirstAnimePage() {
        if (gateUi != null) gateUi.setVisibility(View.GONE);
        StartupDataCache.clear();
        DomainConfig.setErrorListener(new DomainConfig.OnLoadErrorListener() {
            @Override
            public void onLoadFailed(String error) {
                String code = DomainConfig.getLastErrorCode();
                if ("KICKED".equals(code) || "BANNED".equals(code) || "AUTH_REQUIRED".equals(code)) {
                    runOnUiThread(() -> forceLogout(error != null ? error : "เซสชันหมดอายุ กรุณาเข้าสู่ระบบใหม่"));
                    return;
                }
                if ("MAINTENANCE".equals(code) || "OUTDATED".equals(code)) {
                    runOnUiThread(() -> showGateUi("แจ้งเตือน", error != null ? error : "ระบบกำลังปรับปรุง กรุณาลองใหม่ภายหลัง"));
                    return;
                }
                markPreloadFinished();
            }
        });

        DomainConfig.reset();
        DomainConfig.initialize(this);

        long startedAt = System.currentTimeMillis();
        mainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (DomainConfig.isReady()) {
                    loadDefaultSourceFirstPage();
                    return;
                }

                if (System.currentTimeMillis() - startedAt >= PRELOAD_TIMEOUT_MS) {
                    markPreloadFinished();
                    return;
                }

                mainHandler.postDelayed(this, 120);
            }
        }, 120);
    }

    private void loadDefaultSourceFirstPage() {
        List<Source> sources = DomainConfig.getSources();
        if (sources == null || sources.isEmpty()) {
            markPreloadFinished();
            return;
        }

        SharedPreferences prefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        String defaultSourceId = prefs.getString(KEY_DEFAULT_SOURCE, sources.get(0).getId());
        Source defaultSource = sources.get(0);
        for (Source source : sources) {
            if (source.getId().equals(defaultSourceId)) {
                defaultSource = source;
                break;
            }
        }

        List<Category> categories = defaultSource.getCategories();
        if (categories == null || categories.isEmpty()) {
            markPreloadFinished();
            return;
        }

        Category firstCategory = categories.get(0);
        String pageUrl = defaultSource.getFullUrl(firstCategory.getId());
        AnimeSource animeSource = createAnimeSource(defaultSource);
        if (animeSource == null || pageUrl == null || pageUrl.isEmpty()) {
            markPreloadFinished();
            return;
        }

        Source sourceForCache = defaultSource;
        firstPageRequestStarted = true;
        mainHandler.postDelayed(() -> {
            if (firstPageRequestStarted && !preloadFinished) {
                markPreloadFinished();
            }
        }, PRELOAD_TIMEOUT_MS);

        animeSource.fetchAnimeList(pageUrl, new AnimeSource.AnimeLoadCallback() {
            @Override
            public void onSuccess(List<AnimeItem> animeItems, List<PageItem> pageItems) {
                firstPageRequestStarted = false;
                StartupDataCache.save(
                    sourceForCache.getId(),
                    firstCategory.getId(),
                    pageUrl,
                    1,
                    animeItems,
                    pageItems
                );
                markPreloadFinished();
            }

            @Override
            public void onFailure(String errorMessage) {
                firstPageRequestStarted = false;
                markPreloadFinished();
            }
        });
    }

    private AnimeSource createAnimeSource(Source source) {
        if (source == null || source.getId() == null) return null;
        String id = source.getId().trim().toLowerCase();

        switch (id) {
            case "animemoji": return new AnimemojiSource(this);
            case "fixmono": return new FixmonoSource();
            case "goseries4k": return new GoSeriesSource();
            case "wowdrama": return new WowDramaSource();
            case "seriesday": return new SeriesDaySource();
            case "movie123": return new Hdd123Source();
            case "hdd1112": return new Hdd1112Source();
            case "movie24hd": return new Hd24Source();
            case "watchlakorn": return new WatchLakornSource();
            case "hdmedia": return new HdMediaSource();
            default: return null;
        }
    }

    private void markPreloadFinished() {
        mainHandler.post(() -> {
            preloadFinished = true;
            startMainWhenReady();
        });
    }

    private void startMainWhenReady() {
        if (mainStarted || !animationFinished || !preloadFinished) return;
        if (gateUi != null && gateUi.getVisibility() == View.VISIBLE) return;
        mainStarted = true;
        startMain();
    }

    private void startMain() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        overridePendingTransition(0, 0);
        finish();
    }
}
