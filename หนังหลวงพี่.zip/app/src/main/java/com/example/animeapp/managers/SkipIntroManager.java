package com.example.animeapp.managers;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.Button;


public class SkipIntroManager {

   
    private static final long INTRO_START_MS = 3_000L;  
    private static final long INTRO_END_MS   = 90_000L;  
    private static final long FADE_DURATION  = 350L;

    private final Button  skipBtn;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable      seekCallback;
    private boolean       dismissed = false; 

  
    public SkipIntroManager(Button skipBtn, Runnable seekToMs) {
        this.skipBtn      = skipBtn;
        this.seekCallback = seekToMs;

        skipBtn.setText("⏭  ข้ามบทนำ");
        skipBtn.setOnClickListener(v -> onSkipClicked());
    }

   
    public void onPlayerPositionChanged(long posMs, long durationMs) {
        if (dismissed) return;

        long introEnd = (durationMs > 0 && durationMs < INTRO_END_MS)
            ? durationMs / 3   
            : INTRO_END_MS;

        boolean shouldShow = posMs >= INTRO_START_MS && posMs < introEnd;

        if (shouldShow && skipBtn.getVisibility() != View.VISIBLE) {
            showButton();
        } else if (!shouldShow && skipBtn.getVisibility() == View.VISIBLE) {
            hideButton(false);
        }
    }

  
    public void reset() {
        dismissed = false;
        skipBtn.setVisibility(View.GONE);
        skipBtn.clearAnimation();
    }

   
    public void release() {
        handler.removeCallbacksAndMessages(null);
        skipBtn.setVisibility(View.GONE);
    }

    

    private void showButton() {
        skipBtn.setVisibility(View.VISIBLE);
        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
        fadeIn.setDuration(FADE_DURATION);
        fadeIn.setFillAfter(true);
        skipBtn.startAnimation(fadeIn);
    }

    private void hideButton(boolean userDismissed) {
        if (userDismissed) dismissed = true;
        AlphaAnimation fadeOut = new AlphaAnimation(1f, 0f);
        fadeOut.setDuration(FADE_DURATION);
        fadeOut.setFillAfter(true);
        fadeOut.setAnimationListener(new Animation.AnimationListener() {
            @Override public void onAnimationStart(Animation a) {}
            @Override public void onAnimationRepeat(Animation a) {}
            @Override public void onAnimationEnd(Animation a) {
                skipBtn.setVisibility(View.GONE);
            }
        });
        skipBtn.startAnimation(fadeOut);
    }

    private void onSkipClicked() {
        hideButton(true);
        if (seekCallback != null) seekCallback.run();
    }
}
