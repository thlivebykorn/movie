package com.example.animeapp.models;

public class AnimeItem {
    private String title;
    private String url;
    private String imageUrl;
    private String dubText;
    private String latestEpisode; 

    public AnimeItem(String title, String url, String imageUrl, String dubText) {
        this.title         = title;
        this.url           = url;
        this.imageUrl      = imageUrl;
        this.dubText       = dubText;
        this.latestEpisode = "";
    }

    public AnimeItem(String title, String url, String imageUrl, String dubText, String latestEpisode) {
        this.title         = title;
        this.url           = url;
        this.imageUrl      = imageUrl;
        this.dubText       = dubText;
        this.latestEpisode = latestEpisode != null ? latestEpisode : "";
    }

    public String getTitle()         { return title; }
    public String getUrl()           { return url; }
    public String getImageUrl()      { return imageUrl; }
    public String getDubText()       { return dubText; }
    public String getLatestEpisode() { return latestEpisode; }

    public void setLatestEpisode(String ep) {
        this.latestEpisode = ep != null ? ep : "";
    }
}
