package com.example.animeapp.network;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public final class GetplayStreamResolver {

    private static final String CHROME_UA =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

    private GetplayStreamResolver() {}

   
    public static String resolve(String streamBase, String md5, String parent, OkHttpClient client) {
        try {
            String embedUrl = streamBase + "/embed/" + md5;

            String jsonBody = "{\"md5\":\"" + md5 + "\",\"parent\":\"" + parent + "\"}";
            RequestBody body = RequestBody.create(jsonBody, MediaType.parse("application/json"));

            Request request = new Request.Builder()
                    .url(streamBase + "/api/tokenplay")
                    .post(body)
                    .header("User-Agent", CHROME_UA)
                    .header("Referer", embedUrl)
                    .header("Content-Type", "application/json")
                    .build();

            OkHttpClient httpClient = client != null ? client : OkHttpClientFactory.getClientWithDoH();
            try (Response response = httpClient.newCall(request).execute()) {
                if (!response.isSuccessful() || response.body() == null) {
                    return null;
                }
                JsonObject json = JsonParser.parseString(response.body().string()).getAsJsonObject();
                if (!json.has("token") || !json.has("expires")) {
                    return null;
                }

                String streamId = json.has("stream_id")
                        ? json.get("stream_id").getAsString() : md5;

                StringBuilder qs = new StringBuilder("?token=")
                        .append(json.get("token").getAsString())
                        .append("&expires=").append(json.get("expires").getAsLong())
                        .append("&parent=").append(parent);
                if (json.has("session_id")) {
                    qs.append("&sid=").append(json.get("session_id").getAsString());
                }

                String masterUrl = streamBase + "/api/stream/" + streamId + "/index.m3u8" + qs;
                return resolveFlatPlaylist(masterUrl, embedUrl, httpClient, qs.toString());
            }
        } catch (Exception e) {
            return null;
        }
    }

    private static String resolveFlatPlaylist(String masterUrl, String embedUrl,
                                              OkHttpClient client, String qs) {
        try {
            Request request = new Request.Builder()
                    .url(masterUrl)
                    .header("User-Agent", CHROME_UA)
                    .header("Referer", embedUrl)
                    .build();

            try (Response response = client.newCall(request).execute()) {
                if (!response.isSuccessful() || response.body() == null) {
                    return masterUrl;
                }
                String body = response.body().string();
                if (!body.contains("#EXT-X-STREAM-INF")) {
                    return masterUrl;
                }

                String[] lines = body.split("\n");
                for (int i = 0; i + 1 < lines.length; i++) {
                    if (lines[i].trim().startsWith("#EXT-X-STREAM-INF")) {
                        String variant = lines[i + 1].trim();
                        if (variant.isEmpty()) continue;
                        if (variant.startsWith("http")) return variant;
                        String base = masterUrl.substring(0, masterUrl.lastIndexOf('/') + 1);
                        String absolute = base + variant;
                        return absolute.contains("token=") ? absolute : absolute + qs;
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return masterUrl;
    }
}
