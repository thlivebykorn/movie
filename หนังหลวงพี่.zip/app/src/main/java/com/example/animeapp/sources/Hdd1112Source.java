package com.example.animeapp.sources;

import com.example.animeapp.models.AnimeItem;
import com.example.animeapp.models.PageItem;
import com.example.animeapp.network.OkHttpClientFactory;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import com.example.animeapp.domain.DomainConfig;

public class Hdd1112Source implements AnimeSource {

    @Override
    public String getSourceName() {
        return DomainConfig.SourceName.HDD1112();
    }

    @Override
    public String getBaseUrl() {
        return "https://" + DomainConfig.BaseUrl.HDD1112() + DomainConfig.HomePage.HDD1112();
    }

    @Override
    public String getSearchUrl(String keyword) {
        return "https://" + DomainConfig.BaseUrl.HDD1112() + "/?s=" + keyword;
    }

    public List<AnimeItem> parseAnimeItems(Document doc) {
        return com.example.animeapp.parser.NativeParseBridge.parseSourceList("hdd1112", doc).animeItems;
    }

    public List<PageItem> parsePageItems(Document doc) {
        return com.example.animeapp.parser.NativeParseBridge.parseSourceList("hdd1112", doc).pageItems;
    }

    @Override
    public void fetchAnimeList(String pageUrl, AnimeLoadCallback callback) {
        new Thread(() -> {
            try {
                OkHttpClient client = OkHttpClientFactory.getClientWithDoH();

                Request request = new Request.Builder()
                        .url(pageUrl)
                        .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36")
                        .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
                        .header("Accept-Language", "en-US,en;q=0.5")
                        .header("Referer", "https://" + DomainConfig.BaseUrl.HDD1112())
                        .build();

                Response response = client.newCall(request).execute();

                if (response.isSuccessful()) {
                    String html = response.body().string();
                    Document doc = Jsoup.parse(html);

                    com.example.animeapp.parser.NativeParseBridge.SourceListResult nativeResult = com.example.animeapp.parser.NativeParseBridge.parseSourceList("hdd1112", doc);

                    List<AnimeItem> animeItems = nativeResult.animeItems;

                    List<PageItem> pageItems = nativeResult.pageItems;

                    callback.onSuccess(animeItems, pageItems);
                } else {
                    callback.onFailure("รหัสผิดพลาด: " + response.code());
                }

            } catch (IOException e) {
                callback.onFailure("เกิดข้อผิดพลาด: " + e.getMessage());
            }
        }).start();
    }
}