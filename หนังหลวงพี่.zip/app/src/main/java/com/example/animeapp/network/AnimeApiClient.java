package com.example.animeapp.network;

import android.content.Context;
import android.util.Log;

import com.example.animeapp.domain.DomainConfig;
import com.example.animeapp.models.Anime;
import com.example.animeapp.models.Episode;
import com.example.animeapp.parser.AnimeParser;
import com.example.animeapp.parser.AnimemojiParser;
import com.example.animeapp.parser.FixmonoParser;
import com.example.animeapp.parser.GoSeries4kParser;
import com.example.animeapp.parser.WowDramaParser;

import com.example.animeapp.parser.HDD1112Parser;
import com.example.animeapp.parser.Hdd123Parser;
import com.example.animeapp.parser.Hd24Parser;
import com.example.animeapp.parser.SeriesDayParser;
import com.example.animeapp.parser.WatchLakornParser;
import com.example.animeapp.parser.HdMediaParser;


import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;


import java.io.IOException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class AnimeApiClient {
    private static final String TAG = "AnimeApiClient";
    private static OkHttpClient client;

    public static void init(Context context) {
        client = OkHttpClientFactory.getClientWithDoH();
    }

    public static Anime fetchAnimeData(String url, AnimeLoadListener listener) throws IOException {
        try {
            Document doc = fetchDocument(url);
            String sourceId = getSourceIdFromUrl(url);
            if (sourceId == null) {
                throw new IOException("ไม่สามารถระบุ source จาก URL: " + url);
            }

            AnimeParser parser = createParser(sourceId, url);
            if (parser == null) {
                throw new IOException("ไม่รองรับการดึงข้อมูลสำหรับ source: " + sourceId);
            }

            Anime anime = parser.parseAnimeDetail(doc);
            anime.setSource(sourceId);

            if (listener != null) {
                List<Episode> episodes = anime.getEpisodes();
                listener.onTotalEpisodes(episodes.size());
                listener.onProgress(episodes.size(), episodes.size());
            }

            return anime;
        } catch (Exception e) {
            Log.e(TAG, "fetchAnimeData error", e);
            throw new IOException("ดึงข้อมูลไม่สำเร็จ: " + e.getMessage(), e);
        }
    }

    public static String fetchVideoUrl(String epUrl, String referer, int episodeNumber) throws IOException {
        try {
            if (epUrl != null && epUrl.contains("/index.m3u8")) {
                return attachGetplayToken(epUrl, referer);
            }

            Document doc = fetchDocument(epUrl);
            String sourceId = getSourceIdFromUrl(epUrl);
            if (sourceId == null) {
                throw new IOException("ไม่สามารถระบุ source จาก episode URL: " + epUrl);
            }

            AnimeParser parser = createParser(sourceId, epUrl);
            if (parser == null) {
                throw new IOException("ไม่รองรับการดึงวิดีโอสำหรับ source: " + sourceId);
            }

            return parser.parseVideoUrl(doc, referer, episodeNumber);
        } catch (Exception e) {
            Log.e(TAG, "fetchVideoUrl error", e);
            throw new IOException("ดึงลิงก์วิดีโอไม่สำเร็จ: " + e.getMessage(), e);
        }
    }

    private static Document fetchDocument(String url) throws IOException {
        Request request = new Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
            .header("Accept-Language", "th-TH,th;q=0.9,en-US;q=0.8,en;q=0.7")
            .build();

        Response response = client.newCall(request).execute();
        String html = response.body().string();
        return Jsoup.parse(html, url);
    }

    private static AnimeParser createParser(String sourceId, String url) {
        switch (sourceId) {
            case "animemoji": return new AnimemojiParser();
            case "fixmono": return new FixmonoParser();
            case "seriesday": return new SeriesDayParser();
            case "movie123": return new Hdd123Parser();
            case "hdd1112": return new HDD1112Parser();
            case "movie24hd": return new Hd24Parser();
            case "watchlakorn": return new WatchLakornParser();
            case "hdmedia": return new HdMediaParser();
            case "goseries4k": return new GoSeries4kParser();
            case "wowdrama": return new WowDramaParser();
            default: return null;
        }
    }

    private static String getSourceIdFromUrl(String url) {
        if (url == null) return null;
        String host = extractHost(url);

        if (host.contains("oklive-1.xyz") || host.contains("online225.com")
            || host.contains("mycdn-hd.xyz") || host.contains("ok-nah.com")
            || host.contains("ok-hd.com")
            || host.contains("play-heyhd.com")) return "hdd1112";
        

        List<com.example.animeapp.model.Source> sources = DomainConfig.getSources();
        for (com.example.animeapp.model.Source source : sources) {
            if (source.getDomain() == null || source.getDomain().isEmpty()) continue;
            String domain = stripWww(source.getDomain().toLowerCase());
            if (!domain.isEmpty() && host.contains(domain)) {
                return source.getId();
            }
        }

        return null;
    }

    private static String extractHost(String url) {
        try {
            java.net.URI uri = new java.net.URI(url);
            String host = uri.getHost() != null ? uri.getHost().toLowerCase() : "";
            return stripWww(host);
        } catch (Exception e) {
            String stripped = url.replaceFirst("https?://", "");
            return stripWww(stripped.split("/")[0].toLowerCase());
        }
    }

    private static String stripWww(String domain) {
        if (domain == null) return "";
        return domain.startsWith("www.") ? domain.substring(4) : domain;
    }

    public static void resetParsers() {
        Log.d(TAG, "Parser references reset");
    }

    private static final Pattern GETPLAY_STREAM_PATTERN = Pattern.compile(
            "(https?://[^/]+)/api/stream/([A-Za-z0-9_-]{20,})/index\\.m3u8",
            Pattern.CASE_INSENSITIVE
    );

    public static boolean isGetplayStreamWithoutToken(String url) {
        return url != null
                && !url.contains("token=")
                && GETPLAY_STREAM_PATTERN.matcher(url).find();
    }

    private static String attachGetplayToken(String m3u8Url, String referer) {
        if (m3u8Url == null || m3u8Url.contains("token=")) return m3u8Url;
        Matcher matcher = GETPLAY_STREAM_PATTERN.matcher(m3u8Url);
        if (!matcher.find()) return m3u8Url;

        String streamBase = matcher.group(1);
        String md5 = matcher.group(2);
        String parent = extractHost(referer != null ? referer : m3u8Url);
        if (parent == null || parent.isEmpty()) parent = extractHost(m3u8Url);

        OkHttpClient httpClient = client != null ? client : OkHttpClientFactory.getClientWithDoH();
        String resolved = GetplayStreamResolver.resolve(streamBase, md5, parent, httpClient);
        if (resolved != null) return resolved;

        Log.w(TAG, "attachGetplayToken failed for " + m3u8Url);
        return m3u8Url;
    }
}
