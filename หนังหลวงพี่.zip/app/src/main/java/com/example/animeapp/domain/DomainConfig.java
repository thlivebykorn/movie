package com.example.animeapp.domain;

import android.content.Context;
import android.util.Log;
import com.example.animeapp.model.Source;
import com.example.animeapp.model.Strings;
import java.util.ArrayList;
import java.util.List;

public class DomainConfig {
    private static final String TAG = "DomainConfig";
    
    private static List<Source> sources = new ArrayList<>();
    private static Strings strings = new Strings();
    private static boolean isReady = false;
    private static volatile boolean initialized = false;
    private static String lastError = null;
    private static String lastErrorCode = null;

    private static DomainFetcher activeFetcher = null;

    public interface OnLoadErrorListener {
        void onLoadFailed(String error);
    }
    private static OnLoadErrorListener errorListener;

    public static void setErrorListener(OnLoadErrorListener listener) {
        errorListener = listener;
    }

   
    public static boolean isLoaded() {
        return initialized && !sources.isEmpty();
    }

    public static String getLastError() { return lastError; }

    public static String getLastErrorCode() { return lastErrorCode; }

    public static synchronized void initialize(Context ctx) {
        if (initialized) return;
        initialized = true;
        isReady = false;
        lastError = null;

        activeFetcher = new DomainFetcher();
        activeFetcher.setContext(ctx);
        activeFetcher.setListener(new DomainFetcher.DomainLoadListener() {
            @Override
            public void onSourcesLoaded(List<Source> loadedSources, Strings loadedStrings) {
                if (loadedSources != null && !loadedSources.isEmpty()) {
                    sources.clear();
                    sources.addAll(loadedSources);
                    strings = loadedStrings;
                    isReady = true;
                    Log.d(TAG, "Loaded " + sources.size() + " sources with metadata");
                }
            }

            @Override
            public void onSourcesLoadFailed(String error, String code) {
                isReady = false;
                initialized = false;
                lastError = error;
                lastErrorCode = code;
                Log.e(TAG, "Failed to load sources: " + error + (code != null ? " [" + code + "]" : ""));
                if (errorListener != null) errorListener.onLoadFailed(error);
            }
        });

        activeFetcher.fetchSources();
    }

  
    public static synchronized void reset() {
        initialized = false;
        isReady = false;
        lastError = null;
        lastErrorCode = null;
        sources.clear();
        activeFetcher = null;
    }
    
    public static boolean isReady() {
        return isReady;
    }
    
    public static List<Source> getSources() {
        return new ArrayList<>(sources);
    }
    
    public static Source getSourceById(String sourceId) {
        for (Source source : sources) {
            if (source.getId().equals(sourceId)) {
                return source;
            }
        }
        return null;
    }
    
    public static String getUrl(String sourceId, String categoryId) {
        Source source = getSourceById(sourceId);
        if (source != null) {
            return source.getFullUrl(categoryId);
        }
        return "";
    }
    
    public static String getTitle(String sourceId, String categoryId) {
        Source source = getSourceById(sourceId);
        if (source != null) {
            return source.getCategoryTitle(categoryId);
        }
        return "";
    }
    
    public static Strings getStrings() {
        return strings;
    }
   
    public static class BaseUrl {
        public static String ANIMEMOJI() { return getDomain("animemoji"); }
        public static String FIXMONO()   { return getDomain("fixmono"); }
        public static String GOSERIES4K(){ return getDomain("goseries4k"); }
        public static String WOWDRAMA()  { return getDomain("wowdrama"); }
        public static String HDD1112()   { return getDomain("hdd1112"); }
        public static String SERIESDAY() { return getDomain("seriesday"); }
        public static String MOVIE123()  { return getDomain("movie123"); }
        public static String MOVIE24HD() { return getDomain("movie24hd"); }
        public static String DOONANG()   { return getDomain("doonang"); }
        public static String WATCHLAKORN() { return getDomain("watchlakorn"); }
        public static String HDMEDIA()     { return getDomain("hdmedia"); }
        
        private static String getDomain(String sourceId) {
            Source source = getSourceById(sourceId);
            return source != null ? source.getDomain() : "";
        }
    }
    
    public static class ApiUrl {
        
        public static String GET_API() {
            return strings != null && strings.getApi() != null ? strings.getApi() : "";
        }
        public static String PLAY_API() {
            return strings != null && strings.getPlayApi() != null ? strings.getPlayApi() : "";
        }
        public static String PLAY_ANIMEMOJI() {
            return strings != null && strings.getPlayAnimemoji() != null ? strings.getPlayAnimemoji() : "";
        }
        public static String GETPLAY_STREAM_API() {
            return strings != null && strings.getGetplayStreamApi() != null ? strings.getGetplayStreamApi() : "";
        }
        private static String ensureTrailingSlash(String url) {
            return url.endsWith("/") ? url : url + "/";
        }
        
    }
    
    public static class SourceName {
        public static String Home()      { return strings != null && strings.getHome()          != null ? strings.getHome()          : ""; }
        public static String ANIMEMOJI() { return strings != null && strings.getNameAnimemoji() != null ? strings.getNameAnimemoji() : ""; }
        public static String FIXMONO()   { return strings != null && strings.getNameFixmono()   != null ? strings.getNameFixmono()   : ""; }
        public static String GOSERIES4K(){ return strings != null && strings.getNameGoseries4k()!= null ? strings.getNameGoseries4k(): ""; }
        public static String WOWDRAMA()  { return strings != null && strings.getNameWowdrama()  != null ? strings.getNameWowdrama()  : ""; }
        public static String HDD1112()   { return strings != null && strings.getNameHdd1112()   != null ? strings.getNameHdd1112()   : ""; }
        public static String SERIESDAY() { return strings != null && strings.getNameSeriesday() != null ? strings.getNameSeriesday() : ""; }
        public static String MOVIE123()  { return strings != null && strings.getNameMovie123()  != null ? strings.getNameMovie123()  : ""; }
        public static String MOVIE24HD() { return strings != null && strings.getNameMovie24hd() != null ? strings.getNameMovie24hd() : ""; }
        public static String DOONANG()   { return strings != null && strings.getNameDoonang()   != null ? strings.getNameDoonang()   : ""; }
        public static String WATCHLAKORN() { return strings != null && strings.getNameWatchlakorn() != null ? strings.getNameWatchlakorn() : "Watch Lakorn"; }
        public static String HDMEDIA()     { return strings != null && strings.getNameHdmedia()   != null ? strings.getNameHdmedia()   : "24HD Media"; }
    }
    
    public static class HomePage {
        public static String ANIMEMOJI() { return strings != null && strings.getHomeAnimemoji() != null ? strings.getHomeAnimemoji() : ""; }
        public static String FIXMONO()   { return strings != null && strings.getHomeFixmono()   != null ? strings.getHomeFixmono()   : ""; }
        public static String GOSERIES4K(){ return strings != null && strings.getHomeGoseries4k()!= null ? strings.getHomeGoseries4k(): ""; }
        public static String WOWDRAMA()  { return strings != null && strings.getHomeWowdrama()  != null ? strings.getHomeWowdrama()  : ""; }
        public static String HDD1112()   { return strings != null && strings.getHomeHdd1112()   != null ? strings.getHomeHdd1112()   : ""; }
        public static String SERIESDAY() { return strings != null && strings.getHomeSeriesday() != null ? strings.getHomeSeriesday() : ""; }
        public static String MOVIE123()  { return strings != null && strings.getHomeMovie123()  != null ? strings.getHomeMovie123()  : ""; }
        public static String MOVIE24HD() { return strings != null && strings.getHomeMovie24hd() != null ? strings.getHomeMovie24hd() : ""; }
        public static String DOONANG()   { return strings != null && strings.getHomeDoonang()   != null ? strings.getHomeDoonang()   : ""; }
        public static String WATCHLAKORN() { return strings != null && strings.getHomeWatchlakorn() != null ? strings.getHomeWatchlakorn() : ""; }
        public static String HDMEDIA()     { return strings != null && strings.getHomeHdmedia()     != null ? strings.getHomeHdmedia()     : ""; }
    }
}
