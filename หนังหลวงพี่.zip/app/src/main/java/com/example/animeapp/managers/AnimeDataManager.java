package com.example.animeapp.managers;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.example.animeapp.R;
import com.example.animeapp.models.Anime;
import com.example.animeapp.models.Episode;
import com.example.animeapp.network.AnimeApiClient;
import com.example.animeapp.network.AnimeLoadListener;

import java.io.IOException;
import java.util.List;

public class AnimeDataManager {
    private Activity activity;
    private TextView progressTextView;
    private ProgressBar progressBar;
    private View progressContainer;
    private Anime cachedAnime;
    private boolean isRefreshing = false;

    public AnimeDataManager(Activity activity, 
                          TextView progressTextView, 
                          ProgressBar progressBar, 
                          View progressContainer) {
        this.activity = activity;
        this.progressTextView = progressTextView;
        this.progressBar = progressBar;
        this.progressContainer = progressContainer;
    }

    public void loadAnimeData(String animeUrl, DataLoadListener listener) {
        if (!isNetworkAvailable()) {
            showNoInternetToast();
            return;
        }

        isRefreshing = false;
        showProgress("กำลังโหลดข้อมูล...");
        fetchAnime(animeUrl, listener);
    }

    public void refreshAnimeData(String animeUrl, DataLoadListener listener) {
        if (!isNetworkAvailable()) {
            showNoInternetToast();
            return;
        }

        isRefreshing = true;
        showProgress("กำลังอัปเดตข้อมูล...");
        fetchAnime(animeUrl, listener);
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager) activity.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        Network network = cm.getActiveNetwork();
        if (network == null) return false;
        NetworkCapabilities capabilities = cm.getNetworkCapabilities(network);
        return capabilities != null && capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
    }

    private void showNoInternetToast() {
        activity.runOnUiThread(() -> 
            Toast.makeText(activity, "ไม่มีอินเทอร์เน็ต", Toast.LENGTH_SHORT).show()
        );
    }

    private void showProgress(String message) {
        activity.runOnUiThread(() -> {
            progressContainer.setVisibility(View.VISIBLE);
            progressTextView.setText(message);
            progressBar.setProgress(0);
            progressBar.setMax(100);
        });
    }

    private void hideProgress() {
        activity.runOnUiThread(() -> progressContainer.setVisibility(View.GONE));
    }
    
    /*

    private void updateProgress(int current, int total) {
        activity.runOnUiThread(() -> {
            int percent = (int) (((float)current / total) * 100);
            progressTextView.setText(
                String.format("กำลังดึงข้อมูล: ตอนที่ %d จาก %d (%d%%)", current, total, percent)
            );
            progressBar.setProgress(percent);
            
            if (current == total) {
                progressTextView.setText("ดึงข้อมูลเสร็จสิ้น");
                new Handler(Looper.getMainLooper()).postDelayed(this::hideProgress, 1500);
            }
        });
    }
    */
    
    private void updateProgress(int current, int total) {
        int percent = (int) (((float) current / total) * 100);

        // ใช้ string resource แทนการเขียนตรงๆ
        String progressText = activity.getString(
                R.string.loading_progress,
                String.valueOf(current),
                String.valueOf(total)
        );

        progressTextView.setText(
                String.format("%s (%d%%)", progressText, percent)
        );

        progressBar.setProgress(percent);

        if (current == total) {
            progressTextView.setText("ดึงข้อมูลเสร็จสิ้น");
            new Handler(Looper.getMainLooper()).postDelayed(this::hideProgress, 1500);
        }
    }

    public Anime getCachedAnime() {
        return cachedAnime;
    }

    public interface DataLoadListener {
        void onTitleLoaded(String title);
        void onEpisodesLoaded(List<Episode> episodes);
        void onDataLoadFailed(String errorMessage);
    }

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(android.os.Looper.getMainLooper());

    private void fetchAnime(String animeUrl, DataLoadListener listener) {
        final String[] errorMessage = {""};
        executor.execute(() -> {
            Anime anime = null;
            try {
                anime = AnimeApiClient.fetchAnimeData(animeUrl, new AnimeLoadListener() {
                    @Override
                    public void onProgress(int current, int total) {
                        mainHandler.post(() -> updateProgress(current, total));
                    }
                    @Override
                    public void onTotalEpisodes(int total) {
                        mainHandler.post(() -> progressBar.setMax(total));
                    }
                });
            } catch (IOException e) {
                errorMessage[0] = "การเชื่อมต่อล้มเหลว: " + e.getMessage();
                Log.e("AnimeFetch", "IOException", e);
            } catch (Exception e) {
                errorMessage[0] = "เกิดข้อผิดพลาดในการโหลดข้อมูล";
                Log.e("AnimeFetch", "Exception", e);
            }

            final Anime finalAnime = anime;
            mainHandler.post(() -> {
                if (activity == null || activity.isFinishing() || activity.isDestroyed()) return;
                if (finalAnime != null) {
                    cachedAnime = finalAnime;
                    listener.onTitleLoaded(finalAnime.getTitle());
                    listener.onEpisodesLoaded(finalAnime.getEpisodes());
                    if (isRefreshing) {
                        Toast.makeText(activity, "อัปเดตข้อมูลเรียบร้อย", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    String msg = errorMessage[0].isEmpty() ? "ไม่สามารถดึงข้อมูลได้" : errorMessage[0];
                    listener.onDataLoadFailed(msg);
                    Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show();
                    hideProgress();
                }
            });
        });
    }

    public void shutdown() {
        executor.shutdownNow();
    }
}