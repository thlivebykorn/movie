package com.example.animeapp.fragments;

import android.content.res.Configuration;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.animeapp.R;
import com.example.animeapp.adapters.AnimeGridAdapter;
import com.example.animeapp.models.AnimeItem;
import com.example.animeapp.models.PageItem;
import com.example.animeapp.database.DatabaseHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AnimeListFragment extends Fragment {

    public interface LoadPageCallback {
        void onLoadPage(String url, int pageNum);
    }

    public interface AnimeClickCallback {
        void onAnimeClick(AnimeItem item);
    }

    private int currentPage = 1;
    private int maxPage     = 1;
    private List<PageItem> allPageItems = new ArrayList<>();

    private RecyclerView       recyclerView;
    private AnimeGridAdapter   adapter;
    private GridLayoutManager  gridLayoutManager;
    private View               loadingIndicator;
    private View               firstLoadingState;
    private View               paginationBar;
    private TextView           btnPrev, btnPage1, btnPage2, btnPage3, btnPage4;
    private TextView           btnDotsLeft, btnDotsRight, btnLast, btnNext;
    private List<AnimeItem>    pendingAnimeItems;
    private List<PageItem>     pendingPageItems;
    private int                pendingLoadedPageNum = 1;

    private LoadPageCallback   loadPageCallback;
    private AnimeClickCallback animeClickCallback;

    public static AnimeListFragment newInstance() {
        return new AnimeListFragment();
    }

   
    private int getSpanCount() {
        if (getContext() == null) return 2;
        android.content.SharedPreferences prefs = requireContext()
            .getSharedPreferences("AnimeAppPrefs", android.content.Context.MODE_PRIVATE);
        boolean isTV = (getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_TYPE_MASK) == Configuration.UI_MODE_TYPE_TELEVISION;
        if (isTV) {
            return prefs.getInt("tv_grid_columns", 4);
        } else {
            return prefs.getInt("grid_columns", 2);
        }
    }

    public void setLoadPageCallback(LoadPageCallback cb)    { this.loadPageCallback   = cb; }
    public void setAnimeClickCallback(AnimeClickCallback cb){ this.animeClickCallback = cb; }

    public void refreshGridColumns() {
        if (gridLayoutManager == null || getContext() == null) return;
        int cols = getSpanCount();
        gridLayoutManager.setSpanCount(cols);
        if (adapter != null) adapter.notifyItemRangeChanged(0, adapter.getItemCount());
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_anime_list, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView  = view.findViewById(R.id.anime_recycler_view);
        loadingIndicator = view.findViewById(R.id.list_loading_indicator);
        firstLoadingState = view.findViewById(R.id.first_loading_state);
        paginationBar = view.findViewById(R.id.pagination_bar);
        btnPrev       = view.findViewById(R.id.btn_page_prev);
        btnPage1      = view.findViewById(R.id.btn_page_1);
        btnPage2      = view.findViewById(R.id.btn_page_2);
        btnPage3      = view.findViewById(R.id.btn_page_3);
        btnPage4      = view.findViewById(R.id.btn_page_4);
        btnDotsLeft   = view.findViewById(R.id.btn_page_dots_left);
        btnDotsRight  = view.findViewById(R.id.btn_page_dots_right);
        btnLast       = view.findViewById(R.id.btn_page_last);
        btnNext       = view.findViewById(R.id.btn_page_next);

        ViewCompat.setOnApplyWindowInsetsListener(paginationBar, (v, windowInsets) -> {
            Insets navInsets = windowInsets.getInsets(WindowInsetsCompat.Type.navigationBars());
            v.setPadding(
                v.getPaddingLeft(), v.getPaddingTop(), v.getPaddingRight(),
                navInsets.bottom + (int)(10 * getResources().getDisplayMetrics().density)
            );
            return windowInsets;
        });

        int spanCount = getSpanCount();

        adapter = new AnimeGridAdapter(new ArrayList<>(), item -> {
            if (animeClickCallback != null) animeClickCallback.onAnimeClick(item);
        });
        gridLayoutManager = new GridLayoutManager(getContext(), spanCount);
        recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.setAdapter(adapter);
        recyclerView.setFocusable(true);
        recyclerView.setFocusableInTouchMode(true);
        recyclerView.post(() -> recyclerView.requestFocus());

        ((androidx.recyclerview.widget.SimpleItemAnimator) recyclerView.getItemAnimator())
            .setSupportsChangeAnimations(false);
        recyclerView.setItemViewCacheSize(20);

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView rv, int dx, int dy) {
                if (maxPage <= 1) return;
                GridLayoutManager lm = (GridLayoutManager) rv.getLayoutManager();
                if (lm == null) return;
                int total   = lm.getItemCount();
                int visible = lm.getChildCount();
                int first   = lm.findFirstVisibleItemPosition();
                int span    = lm.getSpanCount();
                boolean nearBottom = (visible + first) >= total - span;
                if (nearBottom && total > 0) {
                    paginationBar.setVisibility(View.VISIBLE);
                } else if (dy < 0) {
                    paginationBar.setVisibility(View.GONE);
                }
            }
        });

        btnPrev.setOnClickListener(v  -> goToPage(currentPage - 1));
        btnNext.setOnClickListener(v  -> goToPage(currentPage + 1));
        btnPage1.setOnClickListener(v -> goToPage(Integer.parseInt(btnPage1.getText().toString())));
        btnPage2.setOnClickListener(v -> goToPage(Integer.parseInt(btnPage2.getText().toString())));
        btnPage3.setOnClickListener(v -> goToPage(Integer.parseInt(btnPage3.getText().toString())));
        btnPage4.setOnClickListener(v -> goToPage(Integer.parseInt(btnPage4.getText().toString())));
        btnLast.setOnClickListener(v  -> goToPage(Integer.parseInt(btnLast.getText().toString())));

        refreshFavorites();
        applyPendingDataIfReady();
    }

    @Override
    public void onResume() {
        super.onResume();
        refreshFavorites();
    }

    private void refreshFavorites() {
        if (adapter != null && getContext() != null) {
            DatabaseHelper db = new DatabaseHelper(getContext());
            List<DatabaseHelper.FavoriteItem> favs = db.getAllFavorites();
            Map<String, String> favMap = new HashMap<>();
            for (DatabaseHelper.FavoriteItem fav : favs) {
                favMap.put(fav.animeUrl, fav.lastEpisode);
            }
            adapter.setFavoritesMap(favMap);

            android.content.SharedPreferences prefs = requireContext()
                .getSharedPreferences("AnimeAppPrefs", android.content.Context.MODE_PRIVATE);
            adapter.setShowEpisodeNumber(prefs.getBoolean("show_episode_number", true));
        }
    }

   
    public void showLoadingIndicator() {
        boolean hasItems = adapter != null && adapter.getItemCount() > 0;
        if (firstLoadingState != null) {
            firstLoadingState.setVisibility(View.GONE);
        }
        if (loadingIndicator != null) {
            loadingIndicator.setVisibility(hasItems ? View.VISIBLE : View.GONE);
        }
        if (paginationBar != null) paginationBar.setVisibility(View.GONE);
    }

   
    private void hideLoadingIndicator() {
        if (loadingIndicator != null) loadingIndicator.setVisibility(View.GONE);
        if (firstLoadingState != null) firstLoadingState.setVisibility(View.GONE);
    }


    public void updateAnimeList(List<AnimeItem> items) {
        if (recyclerView == null || adapter == null) {
            pendingAnimeItems = items != null ? new ArrayList<>(items) : new ArrayList<>();
            return;
        }
        hideLoadingIndicator();
        
        if (recyclerView.getAdapter() != adapter) {
            recyclerView.setAdapter(adapter);
        }
        adapter.updateItems(items);
        recyclerView.scrollToPosition(0);
    }

    public boolean hasAnimeItems() {
        if (adapter != null && adapter.getItemCount() > 0) return true;
        return pendingAnimeItems != null && !pendingAnimeItems.isEmpty();
    }

    public void updatePageList(List<PageItem> pages, int loadedPageNum) {
        if (!isAdded() || getContext() == null || paginationBar == null) {
            pendingPageItems = pages != null ? new ArrayList<>(pages) : new ArrayList<>();
            pendingLoadedPageNum = loadedPageNum;
            return;
        }
        allPageItems = pages;
        int max = 1;
        for (PageItem item : pages) {
            try {
                int num = Integer.parseInt(item.getPageNumber().trim());
                if (num > max) max = num;
                if (item.isCurrent()) currentPage = num;
            } catch (NumberFormatException ignored) {}
        }
        if (loadedPageNum > 0) currentPage = loadedPageNum;
        maxPage = Math.max(max, currentPage);
        if (paginationBar != null) paginationBar.setVisibility(View.GONE);
        if (btnPrev == null || btnNext == null) return;
        updatePaginationButtons();
    }

    private void applyPendingDataIfReady() {
        if (pendingAnimeItems != null) {
            List<AnimeItem> items = pendingAnimeItems;
            pendingAnimeItems = null;
            updateAnimeList(items);
        }
        if (pendingPageItems != null) {
            List<PageItem> pages = pendingPageItems;
            int loadedPageNum = pendingLoadedPageNum;
            pendingPageItems = null;
            updatePageList(pages, loadedPageNum);
        }
    }

    public void reset() {
        currentPage = 1;
        maxPage     = 1;
        allPageItems.clear();
        if (paginationBar != null) paginationBar.setVisibility(View.GONE);
        hideLoadingIndicator();
        if (adapter != null) adapter.updateItems(new ArrayList<>());
    }

    public void focusGrid() {
        if (recyclerView != null) {
            recyclerView.requestFocus();
        }
    }

    

    private void goToPage(int page) {
        if (page < 1 || page > maxPage) return;
        if (paginationBar != null) paginationBar.setVisibility(View.GONE);
        for (PageItem item : allPageItems) {
            try {
                if (Integer.parseInt(item.getPageNumber().trim()) == page
                        && !item.getUrl().isEmpty()) {
                    if (loadPageCallback != null) loadPageCallback.onLoadPage(item.getUrl(), page);
                    return;
                }
            } catch (NumberFormatException ignored) {}
        }
        String constructed = buildPageUrl(page);
        if (constructed != null && loadPageCallback != null) {
            loadPageCallback.onLoadPage(constructed, page);
        }
    }

    private String buildPageUrl(int targetPage) {
        String sampleUrl  = null;
        int    samplePage = -1;
        for (PageItem item : allPageItems) {
            if (item.getUrl().isEmpty()) continue;
            try {
                int num = Integer.parseInt(item.getPageNumber().trim());
                if (num >= 2) { sampleUrl = item.getUrl(); samplePage = num; break; }
            } catch (NumberFormatException ignored) {}
        }
        if (sampleUrl == null) return null;
        java.util.regex.Matcher m =
            java.util.regex.Pattern.compile("(.*?/page/)" + samplePage + "(/?.*)").matcher(sampleUrl);
        if (m.matches()) return m.group(1) + targetPage + m.group(2);
        m = java.util.regex.Pattern.compile("(.*[?&]page=)" + samplePage + "(.*)").matcher(sampleUrl);
        if (m.matches()) return m.group(1) + targetPage + m.group(2);
        return sampleUrl.replace("/" + samplePage + "/", "/" + targetPage + "/")
                        .replace("=" + samplePage, "=" + targetPage);
    }

    private void updatePaginationButtons() {
        if (maxPage <= 1 || allPageItems.isEmpty()) {
            paginationBar.setVisibility(View.GONE);
            return;
        }
        btnPrev.setAlpha(currentPage > 1 ? 1f : 0.3f);
        btnPrev.setEnabled(currentPage > 1);
        btnNext.setAlpha(currentPage < maxPage ? 1f : 0.3f);
        btnNext.setEnabled(currentPage < maxPage);

        if (maxPage <= 5) {
            setPageBtn(btnPage1, 1,       true);
            setPageBtn(btnPage2, 2,       maxPage >= 2);
            setPageBtn(btnPage3, 3,       maxPage >= 3);
            setPageBtn(btnPage4, 4,       maxPage >= 4);
            btnDotsLeft.setVisibility(View.GONE);
            btnDotsRight.setVisibility(View.GONE);
            setPageBtn(btnLast,  maxPage, maxPage >= 5);
        } else if (currentPage <= 2) {
            setPageBtn(btnPage1, 1, true);
            setPageBtn(btnPage2, 2, true);
            setPageBtn(btnPage3, 3, true);
            setPageBtn(btnPage4, 4, true);
            btnDotsLeft.setVisibility(View.GONE);
            btnDotsRight.setVisibility(View.VISIBLE);
            setPageBtn(btnLast,  maxPage, true);
        } else if (currentPage >= maxPage - 1) {
            setPageBtn(btnPage1, 1, true);
            btnDotsLeft.setVisibility(View.VISIBLE);
            btnDotsRight.setVisibility(View.GONE);
            setPageBtn(btnPage2, maxPage - 3, maxPage > 4);
            setPageBtn(btnPage3, maxPage - 2, maxPage > 3);
            setPageBtn(btnPage4, maxPage - 1, true);
            setPageBtn(btnLast,  maxPage,     true);
        } else {
            setPageBtn(btnPage1, 1, true);
            btnDotsLeft.setVisibility(View.VISIBLE);
            setPageBtn(btnPage2, currentPage - 1, true);
            setPageBtn(btnPage3, currentPage,     true);
            setPageBtn(btnPage4, currentPage + 1, true);
            btnDotsRight.setVisibility(View.VISIBLE);
            setPageBtn(btnLast,  maxPage, true);
        }
    }

    private void setPageBtn(TextView btn, int pageNum, boolean show) {
        if (!isAdded() || getContext() == null) return;
        if (!show) { btn.setVisibility(View.GONE); return; }
        btn.setVisibility(View.VISIBLE);
        btn.setText(String.valueOf(pageNum));
        boolean active = (pageNum == currentPage);
        btn.setBackgroundResource(active ? R.drawable.page_btn_active_bg : R.drawable.page_btn_bg);
        btn.setTextColor(requireContext().getColor(
                active ? android.R.color.white : R.color.text_primary));
        btn.setTypeface(null, active ? Typeface.BOLD : Typeface.NORMAL);
    }
}
