package com.example.animeapp.sources;

import android.util.Log;
import com.example.animeapp.models.AnimeItem;
import com.example.animeapp.models.PageItem;
import com.example.animeapp.network.OkHttpClientFactory;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import com.example.animeapp.domain.DomainConfig;

public class FixmonoSource implements AnimeSource {
    
    private static final String TAG = "FixmonoSource";
    private final ExecutorService executorService;
    private final OkHttpClient client;
    
    public FixmonoSource() {
        this.executorService = Executors.newSingleThreadExecutor();
        this.client = OkHttpClientFactory.getClientWithDoH();
    }
    
    @Override
    public String getSourceName() {
        return DomainConfig.SourceName.FIXMONO();
    }

    @Override
    public String getBaseUrl() {
        return "https://" + DomainConfig.BaseUrl.FIXMONO() + DomainConfig.HomePage.FIXMONO();
    }

    @Override
    public String getSearchUrl(String keyword) {
        return "https://" + DomainConfig.BaseUrl.FIXMONO() + "/?s=" + keyword;
    }

    @Override
    public void fetchAnimeList(String pageUrl, AnimeLoadCallback callback) {
        executorService.execute(() -> {
            try {
                Log.d(TAG, "Fetching from: " + pageUrl);
                
                Request request = new Request.Builder()
                    .url(pageUrl)
                    .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                    .build();

                Response response = client.newCall(request).execute();
                
                if (response.isSuccessful()) {
                    String html = response.body().string();
                    Document doc = Jsoup.parse(html, pageUrl);
                    
                    com.example.animeapp.parser.NativeParseBridge.SourceListResult nativeResult = com.example.animeapp.parser.NativeParseBridge.parseSourceList("fixmono", doc);
                    
                    List<AnimeItem> animeItems = nativeResult.animeItems;
                    
                    List<PageItem> pageItems = nativeResult.pageItems;
                    
                    Log.d(TAG, "Success: " + animeItems.size() + " items");
                    callback.onSuccess(animeItems, pageItems);
                } else {
                    Log.e(TAG, "HTTP error: " + response.code());
                    callback.onFailure("โหลดหน้าไม่สำเร็จ (HTTP " + response.code() + ")");
                }
                
                response.close();
                
            } catch (IOException e) {
                Log.e(TAG, "Network error: " + e.getMessage(), e);
                callback.onFailure("เกิดข้อผิดพลาดในการเชื่อมต่อ: " + e.getMessage());
            } catch (Exception e) {
                Log.e(TAG, "Unexpected error: " + e.getMessage(), e);
                callback.onFailure("เกิดข้อผิดพลาด: " + e.getMessage());
            }
        });
    }

    public List<AnimeItem> parseAnimeItems(Document doc) {
        return com.example.animeapp.parser.NativeParseBridge.parseSourceList("fixmono", doc).animeItems;
    }

    public List<PageItem> parsePageItems(Document doc) {
        return com.example.animeapp.parser.NativeParseBridge.parseSourceList("fixmono", doc).pageItems;
    }

    private boolean isNumeric(String s) {
        try { Integer.parseInt(s); return true; } catch (NumberFormatException e) { return false; }
    }

    public void cleanup() {
        if (executorService != null && !executorService.isShutdown()) {
            executorService.shutdown();
        }
    }
}