package com.example.animeapp.sources;

import com.example.animeapp.models.AnimeItem;
import com.example.animeapp.models.PageItem;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import com.example.animeapp.network.OkHttpClientFactory;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import com.example.animeapp.domain.DomainConfig;

public class Hd24Source implements AnimeSource {

    @Override
    public String getSourceName() {
        return DomainConfig.SourceName.MOVIE24HD();
    }

    @Override
    public String getBaseUrl() {
        return "https://" + DomainConfig.BaseUrl.MOVIE24HD() + DomainConfig.HomePage.MOVIE24HD();
    }

    @Override
    public String getSearchUrl(String keyword) {
        return "https://" + DomainConfig.BaseUrl.MOVIE24HD() + "/search_movie?keyword=" + keyword;
    }

    public List<AnimeItem> parseAnimeItems(Document doc) {
        return com.example.animeapp.parser.NativeParseBridge.parseSourceList("movie24hd", doc).animeItems;
    }

    public List<PageItem> parsePageItems(Document doc) {
        return com.example.animeapp.parser.NativeParseBridge.parseSourceList("movie24hd", doc).pageItems;
    }

    private boolean isNumeric(String s) {
        try { Integer.parseInt(s); return true; } catch (NumberFormatException e) { return false; }
    }

    @Override
    public void fetchAnimeList(String pageUrl, AnimeLoadCallback callback) {
        new Thread(() -> {
            try {
                
                OkHttpClient client = OkHttpClientFactory.getClientWithDoH();
                
                Request request = new Request.Builder()
                    .url(pageUrl)
                    .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.134 Safari/537.36")
                    .addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
                    .addHeader("Referer", getBaseUrl())
                    .build();

                try (Response response = client.newCall(request).execute()) {
                    String html = response.body().string();
                    
                    if (html.length() < 1000) {
                        callback.onFailure("ได้รับข้อมูล HTML น้อยเกินไป");
                        return;
                    }
                    
                    Document doc = Jsoup.parse(html);
                    com.example.animeapp.parser.NativeParseBridge.SourceListResult nativeResult = com.example.animeapp.parser.NativeParseBridge.parseSourceList("movie24hd", doc);
                    List<AnimeItem> animeItems = nativeResult.animeItems;
                    List<PageItem> pageItems = nativeResult.pageItems;
                    
                    callback.onSuccess(animeItems, pageItems);
                }
            } catch (Exception e) {
                callback.onFailure("เกิดข้อผิดพลาด: " + e.getMessage());
            }
        }).start();
    }
}