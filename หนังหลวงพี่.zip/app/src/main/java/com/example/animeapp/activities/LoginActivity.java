package com.example.animeapp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.animeapp.R;
import com.example.animeapp.auth.SessionManager;
import com.example.animeapp.network.ServerApiClient;

import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity {

    private TextView tabLogin;
    private TextView tabRegister;
    private EditText inputUsername;
    private EditText inputPassword;
    private EditText inputConfirm;
    private TextView labelConfirm;
    private TextView loginError;
    private TextView loginStatus;
    private Button btnSubmit;
    private TextView loginFooter;

    private boolean isRegisterMode = false;
    private boolean submitting = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        tabLogin = findViewById(R.id.tab_login);
        tabRegister = findViewById(R.id.tab_register);
        inputUsername = findViewById(R.id.input_username);
        inputPassword = findViewById(R.id.input_password);
        inputConfirm = findViewById(R.id.input_confirm);
        labelConfirm = findViewById(R.id.label_confirm);
        loginError = findViewById(R.id.login_error);
        loginStatus = findViewById(R.id.login_status);
        btnSubmit = findViewById(R.id.btn_submit);
        loginFooter = findViewById(R.id.login_footer);

        tabLogin.setOnClickListener(v -> setMode(false));
        tabRegister.setOnClickListener(v -> setMode(true));
        btnSubmit.setOnClickListener(v -> onSubmit());

        setMode(false);
    }

    private void setMode(boolean register) {
        isRegisterMode = register;
        int active = register ? R.color.accent_glow : R.color.accent_glow;
        tabLogin.setTextColor(getColorRes(register ? R.color.text_hint : active));
        tabRegister.setTextColor(getColorRes(register ? active : R.color.text_hint));
        inputConfirm.setVisibility(register ? View.VISIBLE : View.GONE);
        labelConfirm.setVisibility(register ? View.VISIBLE : View.GONE);
        btnSubmit.setText(register ? "สมัครสมาชิก" : "เข้าสู่ระบบ");
        loginFooter.setVisibility(register ? View.GONE : View.VISIBLE);
        loginError.setVisibility(View.GONE);
    }

    private int getColorRes(int res) {
        return getColor(res);
    }

    private void onSubmit() {
        if (submitting) return;
        loginError.setVisibility(View.GONE);
        loginStatus.setVisibility(View.GONE);

        String username = inputUsername.getText().toString().trim();
        String password = inputPassword.getText().toString();
        String confirm = inputConfirm.getText().toString();

        if (username.isEmpty()) {
            showError("กรุณากรอกชื่อผู้ใช้");
            return;
        }
        if (password.length() < 6) {
            showError("รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร");
            return;
        }
        if (isRegisterMode && !password.equals(confirm)) {
            showError("รหัสผ่านไม่ตรงกัน");
            return;
        }

        submitting = true;
        btnSubmit.setEnabled(false);
        btnSubmit.setText("กำลังดำเนินการ...");

        new Thread(() -> {
            try {
                if (isRegisterMode) {
                    JSONObject res = ServerApiClient.register(LoginActivity.this, username, password);
                    String status = res.optString("status", "pending");
                    String msg = res.optString("message", "สมัครสมาชิกสำเร็จ");
                    runOnUiThread(() -> {
                        submitting = false;
                        btnSubmit.setEnabled(true);
                        btnSubmit.setText("สมัครสมาชิก");
                        showStatus(msg);
                        inputPassword.setText("");
                        inputConfirm.setText("");
                        setMode(false);
                        showError("");
                    });
                } else {
                    JSONObject res = ServerApiClient.login(LoginActivity.this, username, password);
                    String token = res.getString("token");
                    String status = res.optString("status", "approved");
                    SessionManager.saveSession(LoginActivity.this, token, username, status, res.optString("role", "user"));
                    runOnUiThread(() -> {
                        submitting = false;
                        openSplash();
                    });
                }
            } catch (ServerApiClient.ApiException e) {
                runOnUiThread(() -> {
                    submitting = false;
                    btnSubmit.setEnabled(true);
                    btnSubmit.setText(isRegisterMode ? "สมัครสมาชิก" : "เข้าสู่ระบบ");
                    showError(translateCode(e.code, e.getMessage()));
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    submitting = false;
                    btnSubmit.setEnabled(true);
                    btnSubmit.setText(isRegisterMode ? "สมัครสมาชิก" : "เข้าสู่ระบบ");
                    showError("ไม่สามารถเชื่อมต่อกับเซิร์ฟเวอร์ได้ กรุณาลองใหม่");
                });
            }
        }).start();
    }

    private String translateCode(String code, String message) {
        switch (code) {
            case "BAD_CREDENTIALS": return "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง";
            case "USERNAME_TAKEN": return "ชื่อผู้ใช้นี้ถูกใช้งานแล้ว";
            case "INVALID_USERNAME": return message;
            case "INVALID_PASSWORD": return message;
            case "SERVER": return "เซิร์ฟเวอร์ผิดพลาด กรุณาลองใหม่";
            default: return message != null && !message.isEmpty() ? message : "เกิดข้อผิดพลาด";
        }
    }

    private void showError(String msg) {
        if (msg == null || msg.isEmpty()) {
            loginError.setVisibility(View.GONE);
            return;
        }
        loginError.setText(msg);
        loginError.setVisibility(View.VISIBLE);
    }

    private void showStatus(String msg) {
        loginStatus.setText(msg);
        loginStatus.setVisibility(View.VISIBLE);
    }

    private void openSplash() {
        Intent intent = new Intent(this, SplashActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        overridePendingTransition(0, 0);
        finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
