package com.example.animeapp.utils;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;


public class BatteryOptimizationHelper {

    private static final String PREF_NAME = "battery_opt_pref";
    private static final String KEY_ASKED = "battery_opt_asked";

   
    public static void requestIfNeeded(Activity activity) {
        if (isIgnoringBatteryOptimizations(activity)) return; 
        if (hasAskedBefore(activity)) return;                 
        showDialog(activity);
    }

    

    private static boolean isIgnoringBatteryOptimizations(Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
        return pm != null && pm.isIgnoringBatteryOptimizations(ctx.getPackageName());
    }

    private static boolean hasAskedBefore(Context ctx) {
        return ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                  .getBoolean(KEY_ASKED, false);
    }

    private static void markAsked(Context ctx) {
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
           .edit().putBoolean(KEY_ASKED, true).apply();
    }

   

    private static void showDialog(Activity activity) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity, 0);

       
        ScrollView scrollView = new ScrollView(activity);
        scrollView.setVerticalScrollBarEnabled(false);
        scrollView.setFillViewport(true);
        int screenH = activity.getResources().getDisplayMetrics().heightPixels;
        scrollView.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (int)(screenH * 0.85f)));

       
        LinearLayout card = new LinearLayout(activity);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        int cardPadH = dp(activity, 22);
        int cardPadV = dp(activity, 22);
        card.setPadding(cardPadH, cardPadV, cardPadH, cardPadV);

        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setShape(GradientDrawable.RECTANGLE);
        cardBg.setCornerRadius(dp(activity, 24));
        cardBg.setColor(Color.parseColor("#0E0E1A"));
        cardBg.setStroke(dp(activity, 1), Color.parseColor("#3D2B6B"));
        card.setBackground(cardBg);
        scrollView.addView(card, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        
        FrameLayout iconWrap = new FrameLayout(activity);
        int iconSize = dp(activity, 64);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(iconSize, iconSize);
        iconLp.gravity = Gravity.CENTER_HORIZONTAL;
        iconLp.bottomMargin = dp(activity, 14);

       
        View glowRing = new View(activity);
        GradientDrawable glowDr = new GradientDrawable();
        glowDr.setShape(GradientDrawable.OVAL);
        glowDr.setColor(Color.parseColor("#1A7B5EA7"));
        glowDr.setStroke(dp(activity, 2), Color.parseColor("#7B5EA7"));
        glowRing.setBackground(glowDr);
        FrameLayout.LayoutParams glowLp = new FrameLayout.LayoutParams(iconSize, iconSize);
        iconWrap.addView(glowRing, glowLp);

       
        View innerCircle = new View(activity);
        GradientDrawable innerDr = new GradientDrawable();
        innerDr.setShape(GradientDrawable.OVAL);
        innerDr.setColors(new int[]{
            Color.parseColor("#2A1F4A"),
            Color.parseColor("#1A1A2E")
        });
        innerDr.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        innerCircle.setBackground(innerDr);
        int innerSize = dp(activity, 46);
        FrameLayout.LayoutParams innerLp = new FrameLayout.LayoutParams(innerSize, innerSize);
        innerLp.gravity = Gravity.CENTER;
        iconWrap.addView(innerCircle, innerLp);

       
        TextView iconLabel = new TextView(activity);
        iconLabel.setText("⚡");
        iconLabel.setTextSize(22);
        iconLabel.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams emojiLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        iconLabel.setLayoutParams(emojiLp);
        iconWrap.addView(iconLabel);

        card.addView(iconWrap, iconLp);

       
        TextView title = new TextView(activity);
        title.setText("เปิดการแจ้งเตือนตลอดเวลา");
        title.setTextSize(16);
        title.setTextColor(Color.parseColor("#F5F0FF"));
        title.setGravity(Gravity.CENTER);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        titleLp.bottomMargin = dp(activity, 8);
        card.addView(title, titleLp);

       
        TextView subtitle = new TextView(activity);
        subtitle.setText("บางรุ่น (Xiaomi, Samsung, Oppo ฯลฯ)\nอาจบล็อกการแจ้งเตือนตอนใหม่\nกดอนุญาตเพื่อให้แอปทำงานได้เต็มที่");
        subtitle.setTextSize(12.5f);
        subtitle.setTextColor(Color.parseColor("#A89BC8"));
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setLineSpacing(dp(activity, 2), 1f);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        subLp.bottomMargin = dp(activity, 16);
        card.addView(subtitle, subLp);

        
        View divider = new View(activity);
        divider.setBackgroundColor(Color.parseColor("#1F1635"));
        LinearLayout.LayoutParams divLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 1));
        divLp.bottomMargin = dp(activity, 14);
        card.addView(divider, divLp);

        
        addBullet(activity, card, "🔔", "แจ้งเตือนตอนใหม่ได้ทันที");
        addBullet(activity, card, "🔄", "เช็คอัตโนมัติทุก 3 ชั่วโมง");
        addBullet(activity, card, "🔋", "ใช้แบตน้อยมาก ไม่กระทบการใช้งาน");

       
        View spacer = new View(activity);
        card.addView(spacer, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 16)));

      
        TextView btnAllow = new TextView(activity);
        btnAllow.setText("✓  อนุญาตเลย");
        btnAllow.setTextSize(15);
        btnAllow.setTextColor(Color.WHITE);
        btnAllow.setGravity(Gravity.CENTER);
        btnAllow.setPadding(0, dp(activity, 14), 0, dp(activity, 14));
        btnAllow.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);

        GradientDrawable btnBg = new GradientDrawable();
        btnBg.setShape(GradientDrawable.RECTANGLE);
        btnBg.setCornerRadius(dp(activity, 14));
        btnBg.setColors(new int[]{
            Color.parseColor("#9B6FD4"),
            Color.parseColor("#7B5EA7")
        });
        btnBg.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);
        btnAllow.setBackground(btnBg);

        LinearLayout.LayoutParams allowLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        allowLp.bottomMargin = dp(activity, 10);
        card.addView(btnAllow, allowLp);

        
        TextView btnSkip = new TextView(activity);
        btnSkip.setText("ไม่ต้องการ");
        btnSkip.setTextSize(13f);
        btnSkip.setTextColor(Color.parseColor("#5E5480"));
        btnSkip.setGravity(Gravity.CENTER);
        btnSkip.setPadding(0, dp(activity, 8), 0, dp(activity, 4));
        card.addView(btnSkip, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

       
        builder.setView(scrollView);
        builder.setCancelable(false);
        AlertDialog dialog = builder.create();

        Window win = dialog.getWindow();
        if (win != null) {
            win.setBackgroundDrawableResource(android.R.color.transparent);
            win.setDimAmount(0.75f);
            WindowManager.LayoutParams lp = win.getAttributes();
            lp.width = (int) (activity.getResources().getDisplayMetrics().widthPixels * 0.88f);
            win.setAttributes(lp);
        }

       
        btnAllow.setOnClickListener(v -> {
            animateButtonPress(btnAllow, () -> {
                markAsked(activity);
                dialog.dismiss();
                openBatterySettings(activity);
            });
        });

        btnSkip.setOnClickListener(v -> {
            markAsked(activity);
            dialog.dismiss();
        });

        dialog.show();

        
        animateDialogEntry(scrollView, iconWrap);
    }


    private static void addBullet(Activity ctx, LinearLayout parent,
                                  String emoji, String text) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rowLp.bottomMargin = dp(ctx, 10);

       
        TextView emojiBubble = new TextView(ctx);
        emojiBubble.setText(emoji);
        emojiBubble.setTextSize(16);
        emojiBubble.setGravity(Gravity.CENTER);
        int bubbleSize = dp(ctx, 36);
        GradientDrawable bubbleBg = new GradientDrawable();
        bubbleBg.setShape(GradientDrawable.OVAL);
        bubbleBg.setColor(Color.parseColor("#1F1635"));
        emojiBubble.setBackground(bubbleBg);
        LinearLayout.LayoutParams bubbleLp = new LinearLayout.LayoutParams(bubbleSize, bubbleSize);
        bubbleLp.rightMargin = dp(ctx, 12);
        row.addView(emojiBubble, bubbleLp);

       
        TextView label = new TextView(ctx);
        label.setText(text);
        label.setTextSize(13.5f);
        label.setTextColor(Color.parseColor("#C8BEE8"));
        row.addView(label, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        parent.addView(row, rowLp);
    }

    private static void animateDialogEntry(View card, View iconWrap) {
        card.setAlpha(0f);
        card.setScaleX(0.85f);
        card.setScaleY(0.85f);
        card.setTranslationY(dp(card.getContext(), 40));

        card.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .translationY(0f)
            .setDuration(420)
            .setInterpolator(new OvershootInterpolator(1.1f))
            .start();

       
        iconWrap.postDelayed(() -> {
            ObjectAnimator pulse = ObjectAnimator.ofFloat(iconWrap, "scaleX", 1f, 1.12f, 1f);
            ObjectAnimator pulseY = ObjectAnimator.ofFloat(iconWrap, "scaleY", 1f, 1.12f, 1f);
            AnimatorSet set = new AnimatorSet();
            set.playTogether(pulse, pulseY);
            set.setDuration(900);
            set.setInterpolator(new DecelerateInterpolator());
            pulse.setRepeatCount(ValueAnimator.INFINITE);
            pulseY.setRepeatCount(ValueAnimator.INFINITE);
            pulse.setRepeatMode(ValueAnimator.REVERSE);
            pulseY.setRepeatMode(ValueAnimator.REVERSE);
            set.start();
        }, 500);
    }

    private static void animateButtonPress(View btn, Runnable onEnd) {
        btn.animate()
            .scaleX(0.94f)
            .scaleY(0.94f)
            .setDuration(90)
            .withEndAction(() ->
                btn.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(90)
                    .withEndAction(onEnd)
                    .start()
            ).start();
    }

    private static void openBatterySettings(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                Intent intent = new Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + activity.getPackageName())
                );
                activity.startActivity(intent);
            } catch (Exception e) {
              
                Intent fallback = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", activity.getPackageName(), null));
                activity.startActivity(fallback);
            }
        }
    }

    private static int dp(Context ctx, int value) {
        return (int) (value * ctx.getResources().getDisplayMetrics().density);
    }
}
