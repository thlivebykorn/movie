package com.example.animeapp.audio;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.audiofx.BassBoost;
import android.media.audiofx.Equalizer;

public class AudioEffectManager {

    private static final String PREF_NAME       = "AudioEffectPrefs";
    private static final String KEY_ENABLED     = "eq_enabled";
    private static final String KEY_PRESET      = "eq_preset";
    private static final String KEY_BASS        = "eq_bass";
    private static final String KEY_BAND_PREFIX = "eq_band_";

    public static final String[] PRESET_NAMES = {
        "ปกติ", "คลาสสิก", "เต้นรำ", "ราบเรียบ", "โฟล์ก",
        "เฮฟวีเมทัล", "ฮิปฮอป", "แจ๊ส", "ป๊อป", "ร็อก"
    };
    public static final int PRESET_CUSTOM = -1;

    private Equalizer equalizer;
    private BassBoost bassBoost;
    private boolean   isEnabled    = true;
    private int       currentPreset = 0;
    private short     bassStrength  = 0;

    private final Context           context;
    private final SharedPreferences prefs;

    public AudioEffectManager(Context context) {
        this.context = context;
        this.prefs   = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public void init(int audioSessionId) {
        release();
        try {
            equalizer = new Equalizer(0, audioSessionId);
            bassBoost = new BassBoost(0, audioSessionId);

            isEnabled     = prefs.getBoolean(KEY_ENABLED, true);
            currentPreset = prefs.getInt(KEY_PRESET, 0);
            bassStrength  = (short) prefs.getInt(KEY_BASS, 0);

            equalizer.setEnabled(isEnabled);
            bassBoost.setEnabled(isEnabled);

            if (currentPreset == PRESET_CUSTOM) {
                loadCustomBands();
            } else {
                applyPreset(currentPreset);
            }
            bassBoost.setStrength(bassStrength);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void release() {
        try { if (equalizer != null) { equalizer.release(); equalizer = null; } } catch (Exception ignored) {}
        try { if (bassBoost != null) { bassBoost.release(); bassBoost = null;  } } catch (Exception ignored) {}
    }

    public boolean isEnabled()         { return isEnabled; }
    public int     getPreset()         { return currentPreset; }
    public short   getBassStrength()   { return bassStrength; }
    public int     getNumBands()       { return equalizer != null ? equalizer.getNumberOfBands() : 5; }

    public short[] getBandLevelRange() {
        if (equalizer == null) return new short[]{-1500, 1500};
        try { return equalizer.getBandLevelRange(); } catch (Exception e) { return new short[]{-1500, 1500}; }
    }

    private short[] bandLevelCache = null;

    public short getBandLevel(short band) {
        if (equalizer == null) return 0;
        try {
            short level = equalizer.getBandLevel(band);
           
            if (bandLevelCache == null || bandLevelCache.length <= band) {
                bandLevelCache = new short[equalizer.getNumberOfBands()];
            }
            bandLevelCache[band] = level;
            return level;
        } catch (Exception e) {
           
            if (bandLevelCache != null && band < bandLevelCache.length)
                return bandLevelCache[band];
            return 0;
        }
    }

    public int getBandFreqHz(short band) {
        if (equalizer == null) return 0;
        try { return equalizer.getCenterFreq(band) / 1000; } catch (Exception e) { return 0; }
    }

    public String getFreqLabel(short band) {
        int hz = getBandFreqHz(band);
        if (hz >= 1000) return (hz / 1000) + " kHz";
        return hz + " Hz";
    }

    public void setEnabled(boolean enabled) {
        isEnabled = enabled;
        try { if (equalizer != null) equalizer.setEnabled(enabled); } catch (Exception ignored) {}
        try { if (bassBoost != null) bassBoost.setEnabled(enabled); } catch (Exception ignored) {}
        prefs.edit().putBoolean(KEY_ENABLED, enabled).apply();
    }

    public void applyPreset(int presetIndex) {
        currentPreset = presetIndex;
        if (equalizer == null) return;
        try {
            if (presetIndex >= 0 && presetIndex < equalizer.getNumberOfPresets()) {
                equalizer.usePreset((short) presetIndex);
            } else if (presetIndex == 0) {
                for (short i = 0; i < equalizer.getNumberOfBands(); i++) {
                    equalizer.setBandLevel(i, (short) 0);
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
        prefs.edit().putInt(KEY_PRESET, presetIndex).apply();
    }

    public void setBandLevel(short band, short level) {
        currentPreset = PRESET_CUSTOM;
        try { if (equalizer != null) equalizer.setBandLevel(band, level); } catch (Exception ignored) {}
        prefs.edit()
            .putInt(KEY_PRESET, PRESET_CUSTOM)
            .putInt(KEY_BAND_PREFIX + band, level)
            .apply();
    }

    public void setBassStrength(short strength) {
        bassStrength = strength;
        try { if (bassBoost != null) bassBoost.setStrength(strength); } catch (Exception ignored) {}
        prefs.edit().putInt(KEY_BASS, strength).apply();
    }

    private void loadCustomBands() {
        if (equalizer == null) return;
        try {
            int bands = equalizer.getNumberOfBands();
            for (short i = 0; i < bands; i++) {
                short level = (short) prefs.getInt(KEY_BAND_PREFIX + i, 0);
                equalizer.setBandLevel(i, level);
            }
        } catch (Exception ignored) {}
    }
}
