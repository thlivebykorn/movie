package com.example.animeapp.parser;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import com.example.animeapp.models.Anime;
import com.example.animeapp.models.Episode;
import com.example.animeapp.network.OkHttpClientFactory;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import com.example.animeapp.domain.DomainConfig;

public class Hdd123Parser implements AnimeParser {
    
    private final OkHttpClient client;
    
    public Hdd123Parser() {
        this.client = OkHttpClientFactory.getClientWithDoH();
    }
    
    @Override
    public Anime parseAnimeDetail(Document doc) {
        return com.example.animeapp.parser.NativeParseBridge.parseAnimeDetail("movie123", doc);
    }

    @Override
    public List<Episode> parseEpisodes(Document doc, String imageUrl) {
        return com.example.animeapp.parser.NativeParseBridge.parseEpisodes("movie123", doc, imageUrl);
    }
    
    private List<Episode> parseTableFormat(Element table, Document doc, String imageUrl) {
        List<Episode> episodes = new ArrayList<>();
        Elements rows = table.select("tbody tr");
        
        for (int i = 0; i < rows.size(); i++) {
            Element row = rows.get(i);
            Element link = row.selectFirst("td a");
            
            if (link != null) {
                String episodeTitle = link.text().trim();
                String episodeUrl = link.attr("abs:href");
                
                Elements tds = row.select("td");
                int episodeNumber = i + 1;
                if (tds.size() >= 2) {
                    try {
                        episodeNumber = Integer.parseInt(tds.get(1).text().trim());
                    } catch (NumberFormatException e) {
                        episodeNumber = i + 1;
                    }
                }
                
                episodes.add(new Episode(
                    episodeTitle,
                    episodeUrl,
                    imageUrl,
                    "",
                    episodeUrl,
                    episodeNumber
                ));
            }
        }
        
        return episodes;
    }
    
    private List<Episode> parseDropdownFormat(Element select, Document doc, String imageUrl) {
        List<Episode> episodes = new ArrayList<>();
        Elements options = select.select("option");
        
        for (int i = 0; i < options.size(); i++) {
            Element option = options.get(i);
            String episodeTitle = option.text().trim();
            String episodeUrl = option.attr("value");
            
            if (!episodeUrl.startsWith("http")) {
                episodeUrl = doc.baseUri() + episodeUrl;
            }
            
            int episodeNumber = extractEpisodeNumber(episodeTitle, i + 1);
            
            episodes.add(new Episode(
                episodeTitle,
                episodeUrl,
                imageUrl,
                "",
                episodeUrl,
                episodeNumber
            ));
        }
        
        return episodes;
    }
    
    private List<Episode> parseStandardFormat(Document doc, String imageUrl) {
        List<Episode> episodes = new ArrayList<>();
        Elements serverLists = doc.select("div.list-eps-ajax");
        
        for (Element serverList : serverLists) {
            Elements episodeElements = serverList.select("li.halim-episode");
            
            for (Element episodeElement : episodeElements) {
                Element span = episodeElement.selectFirst("span.halim-btn");
                if (span != null) {
                    String episodeTitle = span.attr("data-title");
                    String dataEpisode = span.attr("data-episode");
                    
                    int episodeNumber = 1;
                    if (!dataEpisode.isEmpty()) {
                        try {
                            episodeNumber = Integer.parseInt(dataEpisode);
                        } catch (NumberFormatException e) {
                            episodeNumber = 1;
                        }
                    }
                    
                    episodes.add(new Episode(
                        episodeTitle,
                        doc.baseUri(),
                        imageUrl,
                        "",
                        doc.baseUri(),
                        episodeNumber
                    ));
                }
            }
        }
        
        if (episodes.isEmpty()) {
            String title = doc.selectFirst("meta[property=og:title]") != null 
                ? doc.selectFirst("meta[property=og:title]").attr("content")
                : "Movie";
            
            episodes.add(new Episode(
                title,
                doc.baseUri(),
                imageUrl,
                "",
                doc.baseUri(),
                1
            ));
        }
        
        return episodes;
    }
    
    private int extractEpisodeNumber(String episodeTitle, int defaultNumber) {
        Pattern pattern = Pattern.compile("EP[\\s-]*(\\d+)", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(episodeTitle);
        
        if (matcher.find()) {
            try {
                return Integer.parseInt(matcher.group(1));
            } catch (NumberFormatException e) {
                return defaultNumber;
            }
        }
        
        return defaultNumber;
    }

    @Override
    public String parseVideoUrl(Document epDoc, String referer, int episodeNumber) throws IOException {
        String nonce = extractNonce(epDoc.html());
        Element activeSpan = epDoc.selectFirst("span.halim-btn.active");

        if (activeSpan == null) {
            activeSpan = epDoc.selectFirst("span.halim-btn");
            if (activeSpan == null) {
                return "";
            }
        }

        String dataPostId = activeSpan.attr("data-post-id");
        String dataServer = activeSpan.attr("data-server");
        String dataEpisode = activeSpan.attr("data-episode");

        String postData = String.format(
            "action=halim_ajax_player&nonce=%s&episode=%s&postid=%s&server=%s",
            nonce, dataEpisode, dataPostId, dataServer
        );

        RequestBody body = RequestBody.create(
            postData,
            MediaType.parse("application/x-www-form-urlencoded")
        );

        Request request = new Request.Builder()
            .url("https://" + DomainConfig.BaseUrl.MOVIE123() + "/api/get.php")
            .header("Content-Type", "application/x-www-form-urlencoded")
            .header("Referer", referer)
            .header("User-Agent", "Mozilla/5.0")
            .post(body)
            .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                return "";
            }

            String html = response.body().string();
            Document iframeDoc = Jsoup.parse(html);
            Element iframe = iframeDoc.selectFirst("iframe");

            if (iframe != null) {
                String videoUrl = iframe.attr("src");
                return convertToM3u8Url(videoUrl);
            }

            return "";
        }
    }

    private String extractNonce(String html) {
        Pattern pattern = Pattern.compile("ajax_player.+?\"nonce\":\"(.+?)\"");
        Matcher matcher = pattern.matcher(html);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return "";
    }

    private String convertToM3u8Url(String inputUrl) {
        Pattern pattern = Pattern.compile("id=([^&]+)");
        Matcher matcher = pattern.matcher(inputUrl);
        
        if (matcher.find()) {
            String id = matcher.group(1);
            return String.format(DomainConfig.ApiUrl.PLAY_API() + "%s/%s.m3u8", id, id);
        }
        return inputUrl;
    }
}