package com.example.animeapp.managers;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;
import android.util.Log;

import java.util.UUID;


public class DeviceManager {

    private static final String TAG = "DeviceManager";

    private static final String PREFS_NAME    = "DevicePrefs";
    private static final String KEY_DEVICE_ID = "device_id";

    private final Context context;
    private final SharedPreferences prefs;

    private final String deviceId;

    private static DeviceManager instance;
    public static DeviceManager getInstance(Context ctx) {
        if (instance == null) instance = new DeviceManager(ctx.getApplicationContext());
        return instance;
    }

    private DeviceManager(Context context) {
        this.context  = context;
        this.prefs    = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        this.deviceId = getOrCreateDeviceId();
    }

    public String getDeviceId() { return deviceId; }

    public String getShortDeviceId() {
        if (deviceId.length() < 12) return deviceId;
        return deviceId.substring(0, 8) + "…" + deviceId.substring(deviceId.length() - 4);
    }

    private String getOrCreateDeviceId() {
        String existing = prefs.getString(KEY_DEVICE_ID, null);
        if (existing != null && !existing.isEmpty()) return existing;

        String androidId = Settings.Secure.getString(
            context.getContentResolver(),
            Settings.Secure.ANDROID_ID
        );

        String newId;
        if (androidId != null && !androidId.isEmpty()
                && !androidId.equals("9774d56d682e549c")
                && androidId.length() >= 8) {
            newId = toUuidFormat(androidId);
            Log.d(TAG, "Using ANDROID_ID as device ID");
        } else {
            newId = UUID.randomUUID().toString();
            Log.d(TAG, "Created random Device ID (ANDROID_ID unavailable)");
        }

        prefs.edit().putString(KEY_DEVICE_ID, newId).apply();
        return newId;
    }

    private String toUuidFormat(String hex) {
        String h = hex.replaceAll("[^a-fA-F0-9]", "");
        while (h.length() < 32) h = h + "0";
        if (h.length() > 32) h = h.substring(0, 32);
        return h.substring(0, 8) + "-" + h.substring(8, 12) + "-"
             + h.substring(12, 16) + "-" + h.substring(16, 20) + "-"
             + h.substring(20, 32);
    }
}
