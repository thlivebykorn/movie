package com.example.animeapp.startup;

import com.example.animeapp.models.AnimeItem;
import com.example.animeapp.models.PageItem;

import java.util.ArrayList;
import java.util.List;

public final class StartupDataCache {
    private static CachedData cachedData;

    private StartupDataCache() {}

    public static synchronized void save(
            String sourceId,
            String categoryId,
            String pageUrl,
            int pageNum,
            List<AnimeItem> animeItems,
            List<PageItem> pageItems) {
        cachedData = new CachedData(
            sourceId,
            categoryId,
            pageUrl,
            pageNum,
            animeItems != null ? new ArrayList<>(animeItems) : new ArrayList<>(),
            pageItems != null ? new ArrayList<>(pageItems) : new ArrayList<>()
        );
    }

    public static synchronized CachedData peek() {
        return cachedData;
    }

    public static synchronized void clear() {
        cachedData = null;
    }

    public static final class CachedData {
        public final String sourceId;
        public final String categoryId;
        public final String pageUrl;
        public final int pageNum;
        public final List<AnimeItem> animeItems;
        public final List<PageItem> pageItems;

        private CachedData(
                String sourceId,
                String categoryId,
                String pageUrl,
                int pageNum,
                List<AnimeItem> animeItems,
                List<PageItem> pageItems) {
            this.sourceId = sourceId;
            this.categoryId = categoryId;
            this.pageUrl = pageUrl;
            this.pageNum = pageNum;
            this.animeItems = animeItems;
            this.pageItems = pageItems;
        }
    }

}
