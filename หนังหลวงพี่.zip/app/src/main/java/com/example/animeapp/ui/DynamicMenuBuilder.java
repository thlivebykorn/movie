package com.example.animeapp.ui;

import android.content.Context;
import android.view.Menu;
import android.view.MenuItem;
import com.example.animeapp.R;
import com.example.animeapp.domain.DomainConfig;
import com.example.animeapp.model.Source;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

public class DynamicMenuBuilder {
    
    private final Map<Integer, Source> sourceMap = new HashMap<>();
    private final Context context;
    
    public DynamicMenuBuilder(Context context) {
        this.context = context;
    }
    
    public void buildDynamicMenu(Menu menu) {
        List<Source> sources = DomainConfig.getSources();
        if (sources == null || sources.isEmpty()) return;
        
        sourceMap.clear();

       
        int groupId = menu.findItem(R.id.group_sources) != null
            ? R.id.group_sources : Menu.NONE;

        int itemOrder = 100; 
        for (Source source : sources) {
            int menuId  = android.view.View.generateViewId();
            int iconRes = getIconForSource(source.getId());

            MenuItem item = menu.add(R.id.group_sources, menuId, itemOrder++, source.getName());
            item.setIcon(iconRes);
            item.setCheckable(true);

            sourceMap.put(menuId, source);
        }
    }
    
    private int getIconForSource(String sourceId) {
        if (sourceId == null) return R.drawable.ic_source_goseries;
        switch (sourceId.toLowerCase()) {
            case "animemoji":   return R.drawable.ic_source_animemoji;
            case "fixmono":     return R.drawable.ic_source_fixmono;
            case "goseries4k":  return R.drawable.ic_source_goseries;
            case "wowdrama":    return R.drawable.ic_source_wowdrama;
            case "hdd1112":     return R.drawable.ic_source_hdd1112;
            case "seriesday":   return R.drawable.ic_source_seriesday;
            case "movie123":
            case "hdd123":      return R.drawable.ic_source_movie123;
            case "movie24hd":
            case "24hd":        return R.drawable.ic_source_movie24hd;
            case "hdmedia":     return R.drawable.ic_source_movie24hd;
            default:            return R.drawable.ic_source_goseries;
        }
    }
    
    public Source getSource(int itemId) {
        return sourceMap.get(itemId);
    }
}
