package com.example.animeapp.network;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.concurrent.TimeUnit;
import okhttp3.OkHttpClient;

public class OkHttpClientFactory {

    private static OkHttpClient client;
    private static OkHttpClient clientWithDoH;
    private static OkHttpClient clientNoDoH;

    
    public static synchronized void resetClients() {
        client = null;
        clientWithDoH = null;
        clientNoDoH = null;
    }

    public static synchronized OkHttpClient getClient() {
        if (client == null) {
            client = new OkHttpClient.Builder()
                    .dns(CustomDnsSelector.getInstance())
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.SECONDS)
                    .writeTimeout(30, TimeUnit.SECONDS)
                    .followRedirects(true)
                    .followSslRedirects(true)
                    .build();
        }
        return client;
    }

   
    public static OkHttpClient getClientWithDoH(Context context) {
        boolean useDoH = true;
        if (context != null) {
            SharedPreferences prefs = context.getSharedPreferences("AnimeAppPrefs",
                Context.MODE_PRIVATE);
            useDoH = prefs.getBoolean("use_doh", true);
        }
        return useDoH ? getDoHClient() : getNoDoHClient();
    }

  
    public static synchronized OkHttpClient getClientWithDoH() {
        return getDoHClient();
    }

    private static synchronized OkHttpClient getDoHClient() {
        if (clientWithDoH == null) {
            clientWithDoH = new OkHttpClient.Builder()
                    .dns(CloudflareDnsProvider.getInstance().getDns())
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.SECONDS)
                    .writeTimeout(30, TimeUnit.SECONDS)
                    .followRedirects(true)
                    .followSslRedirects(true)
                    .build();
        }
        return clientWithDoH;
    }

    private static synchronized OkHttpClient getNoDoHClient() {
        if (clientNoDoH == null) {
            clientNoDoH = new OkHttpClient.Builder()
                    .dns(CustomDnsSelector.getInstance())
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.SECONDS)
                    .writeTimeout(30, TimeUnit.SECONDS)
                    .followRedirects(true)
                    .followSslRedirects(true)
                    .build();
        }
        return clientNoDoH;
    }
}
