package com.example.animeapp.parser;

import android.util.Log;
import com.example.animeapp.models.Anime;
import com.example.animeapp.models.Episode;
import com.example.animeapp.network.OkHttpClientFactory;
import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import com.example.animeapp.domain.DomainConfig;


public class WatchLakornParser implements AnimeParser {

    private static final String TAG = "WatchLakornParser";
    private static final String FALLBACK_DOMAIN = "www.watchlakorn.org";
    private static final String UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

    private final OkHttpClient client;
    private String base;
    private String referer;

    public WatchLakornParser() {
        this.client = OkHttpClientFactory.getClientWithDoH();
    }

    private String getDomain() {
        String domain = DomainConfig.BaseUrl.WATCHLAKORN();
        return (domain == null || domain.isEmpty()) ? FALLBACK_DOMAIN : domain;
    }

    private String baseUrl() {
        if (base == null || base.isEmpty()) base = "https://" + getDomain();
        return base;
    }

    private String homeReferer() {
        if (referer == null || referer.isEmpty()) referer = baseUrl() + "/";
        return referer;
    }

    @Override
    public Anime parseAnimeDetail(Document doc) throws IOException {
        String url = doc != null ? doc.baseUri() : "";
        this.referer = url;

        if (url.contains("api.php?action=get_series_detail")) {
            JSONObject root = fetchJson(url);
            return parseSeriesDetailFromJson(root, url);
        }

        if (url.contains("api.php?action=get_player")) {
            JSONObject root = fetchJson(url);
            return buildSingleVideoAnime(root, url);
        }

       
        Matcher videoMatcher = Pattern.compile("-video-(\\d+)").matcher(url);
        if (videoMatcher.find()) {
            String playerUrl = baseUrl() + "/api.php?action=get_player&id=" + videoMatcher.group(1);
            JSONObject root = fetchJson(playerUrl);
            return buildSingleVideoAnime(root, url);
        }

       
        this.domain = getDomain();
        return parseOldHtmlDetail(doc);
    }

    @Override
    public List<Episode> parseEpisodes(Document doc, String imageUrl) {
        try {
            return parseAnimeDetail(doc).getEpisodes();
        } catch (Exception e) {
            Log.e(TAG, "parseEpisodes failed", e);
            return new ArrayList<>();
        }
    }

    private String ensureMediaPlayable(String stream) throws IOException {
        if (stream == null || !stream.toLowerCase().endsWith(".m3u8")) return stream;

        String master;
        try {
            master = fetchRaw(stream);
        } catch (Exception e) {
           
            return stream;
        }

        if (!master.contains("#EXT-X-STREAM-INF")) {
            if (!master.contains("#EXTINF")) {
                throw new IOException("ตอนนี้ถูกลบออกจากระบบแล้ว กรุณาเลือกตอนอื่น");
            }
            int code = probeFirstSegment(master, stream);
            if (isDeadSegment(code)) {
                throw new IOException("ตอนนี้ถูกลบออกจากระบบแล้ว กรุณาเลือกตอนอื่น");
            }
            return stream;
        }

       
        List<String> uris = new ArrayList<>();
        String[] lines = master.split("\\r?\\n");
        for (int i = 0; i < lines.length; i++) {
            if (!lines[i].trim().startsWith("#EXT-X-STREAM-INF") || i + 1 >= lines.length) continue;
            String uri = lines[i + 1].trim();
            if (!uri.isEmpty() && !uri.startsWith("#") && !uris.contains(uri)) {
                uris.add(resolveUrl(stream, uri));
            }
        }
        if (uris.isEmpty()) return stream;

        boolean anyOk = false;
        boolean sawDead = false;
        for (String u : uris) {
            String media;
            try {
                media = fetchRaw(u);
            } catch (Exception e) {
                continue;
            }
            if (!media.contains("#EXTINF")) continue;
            int code = probeFirstSegment(media, u);
            if (code >= 200 && code < 300) {
                anyOk = true;
                break;
            }
            if (isDeadSegment(code)) sawDead = true;
        }
        if (!anyOk && sawDead) {
            throw new IOException("ตอนนี้ถูกลบออกจากระบบแล้ว กรุณาเลือกตอนอื่น");
        }
        return stream;
    }

    private boolean isDeadSegment(int code) {
        return code >= 400 && code < 500;
    }

    private int probeFirstSegment(String media, String baseUrl) {
        String[] lines = media.split("\\r?\\n");
        String seg = null;
        for (int i = 0; i < lines.length - 1; i++) {
            if (lines[i].trim().startsWith("#EXTINF")) {
                String next = lines[i + 1].trim();
                if (!next.isEmpty() && !next.startsWith("#")) {
                    seg = next;
                    break;
                }
            }
        }
        if (seg == null) return -1;

        String url = resolveUrl(baseUrl, seg);
        Request req = new Request.Builder()
                .url(url)
                .header("User-Agent", UA)
                .header("Referer", homeReferer())
                .header("Range", "bytes=0-0")
                .build();
        try (Response resp = client.newCall(req).execute()) {
            return resp.code();
        } catch (Exception e) {
            return -1;
        }
    }

    private String resolveUrl(String base, String ref) {
        if (ref == null || ref.isEmpty()) return base;
        if (ref.startsWith("http")) return ref;
        if (ref.startsWith("//")) return "https:" + ref;
        if (ref.startsWith("/")) {
            try {
                return java.net.URI.create(base).resolve(ref).toString();
            } catch (Exception ignored) {}
            return baseUrl() + ref;
        }
        try {
            return java.net.URI.create(base).resolve(ref).toString();
        } catch (Exception ignored) {
            return base;
        }
    }

    @Override
    public String parseVideoUrl(Document epDoc, String referer, int episodeNumber) throws IOException {
        this.referer = referer;
        String url = epDoc != null ? epDoc.baseUri() : "";

        if (url.contains("api.php?action=get_player")) {
            JSONObject root = fetchJson(url);
            JSONObject video = root.optJSONObject("video");
            if (video != null) {
                String stream = resolveStream(video);
                if (!stream.isEmpty()) return ensureMediaPlayable(stream);
            }
            throw new IOException("ไม่พบสตรีมวิดีโอใน api.php?action=get_player");
        }

        if (url.contains("content_jw6.php")) {
            String file = parseJwFile(fetchRaw(url));
            if (!file.isEmpty()) return ensureMediaPlayable(file);
        }

        return parseOldHtmlVideoPage(epDoc);
    }

   

    private JSONObject fetchJson(String url) throws IOException {
        try {
            return new JSONObject(fetchRaw(url));
        } catch (org.json.JSONException e) {
            throw new IOException("JSON parse error: " + e.getMessage(), e);
        }
    }

    private String fetchRaw(String url) throws IOException {
        Request req = new Request.Builder()
                .url(url)
                .header("User-Agent", UA)
                .header("Accept", "application/json, text/plain, */*")
                .header("Referer", homeReferer())
                .build();
        try (Response resp = client.newCall(req).execute()) {
            if (!resp.isSuccessful()) throw new IOException("HTTP " + resp.code());
            return resp.body().string();
        }
    }

    private Anime parseSeriesDetailFromJson(JSONObject root, String pageUrl) throws IOException {
        try {
            JSONObject series = root.optJSONObject("series");
            String title = series != null ? series.optString("title", "") : "";
            if (title.isEmpty()) title = "รายการ";
            String image = series != null ? normalize(series.optString("image", "")) : "";

            JSONArray eps = root.optJSONArray("episodes");
            List<Episode> episodes = new ArrayList<>();
            if (eps != null) {
                for (int i = 0; i < eps.length(); i++) {
                    JSONObject e = eps.optJSONObject(i);
                    if (e == null) continue;
                    long vid = e.optLong("id", 0L);
                    int epNum = e.optInt("episode", i + 1);
                    String epTitle = e.optString("episode_display", "");
                    if (epTitle.isEmpty()) epTitle = "ตอนที่ " + epNum;
                    String epImage = normalize(e.optString("image", ""));
                    if (epImage.isEmpty()) epImage = image;
                    String infoUrl = vid > 0
                            ? baseUrl() + "/api.php?action=get_player&id=" + vid
                            : pageUrl;
                    episodes.add(new Episode(epTitle, infoUrl, epImage, "", homeReferer(), epNum));
                }
            }
            return new Anime(title, pageUrl, image, episodes);
        } catch (Exception e) {
            throw new IOException("parse series detail failed: " + e.getMessage(), e);
        }
    }

    private Anime buildSingleVideoAnime(JSONObject root, String pageUrl) throws IOException {
        JSONObject video = root.optJSONObject("video");
        if (video == null) throw new IOException("ไม่พบข้อมูลวิดีโอ");
        String title = video.optString("title", "วิดีโอ");
        String image = normalize(video.optString("image", ""));
        String stream = resolveStream(video);
        List<Episode> episodes = new ArrayList<>();
        episodes.add(new Episode(title, pageUrl, image, stream, homeReferer(), 1));
        return new Anime(title, pageUrl, image, episodes);
    }

  
    private String resolveStream(JSONObject video) throws IOException {
        String stream = video.optString("stream_url", "");
        if (stream.isEmpty()) stream = video.optString("playlist_url", "");
        if (stream.isEmpty()) stream = video.optString("playlist", "");
        if (stream == null || stream.isEmpty()) return "";

        if (stream.contains("content_jw6.php") || stream.contains("content_jw")) {
            String jwUrl = stream.startsWith("http") ? stream : baseUrl() + "/" + stream;
            return parseJwFile(fetchRaw(jwUrl));
        }
        if (stream.startsWith("//")) return "https:" + stream;
        if (stream.startsWith("/")) return baseUrl() + stream;
        return stream;
    }

    private String parseJwFile(String jwJson) throws IOException {
        try {
            JSONArray arr = new JSONArray(jwJson);
            if (arr.length() > 0) {
                String file = arr.getJSONObject(0).optString("file", "");
                if (!file.isEmpty()) {
                    if (file.startsWith("//")) return "https:" + file;
                    if (file.startsWith("http")) return file;
                    return baseUrl() + "/" + file;
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "parseJwFile error", e);
        }
        throw new IOException("ไม่พบลิงก์วิดีโอใน content_jw6");
    }

    private static String normalize(String img) {
        if (img == null || img.isEmpty()) return "";
        if (img.startsWith("//")) return "https:" + img;
        return img;
    }

   

    private String domain;

    private Anime parseOldHtmlDetail(Document doc) {
        Anime anime = com.example.animeapp.parser.NativeParseBridge.parseAnimeDetail("watchlakorn", doc);
        anime.setEpisodes(parseEpisodesLegacy(doc, anime.getImageUrl()));
        return anime;
    }

    private List<Episode> parseEpisodesLegacy(Document doc, String imageUrl) {
        List<Episode> episodes = new ArrayList<>();
        String url = doc.baseUri();

        Pattern cmPattern = Pattern.compile("-cm-(\\d+)");
        Matcher cmMatcher = cmPattern.matcher(url);

        if (cmMatcher.find()) {
            String cmId = cmMatcher.group(1);
            try {
                String base = "https://" + domain;
                String ajaxUrl = base + "/ajax.php?module=movie_select&name=Catmovie&file=" + cmId;

                Request request = new Request.Builder()
                    .url(ajaxUrl)
                    .get()
                    .header("User-Agent", UA)
                    .header("Referer", base + "/")
                    .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                    .build();

                try (Response response = client.newCall(request).execute()) {
                    if (response.isSuccessful()) {
                        String html = response.body().string();
                        Document ajaxDoc = org.jsoup.Jsoup.parse(html, ajaxUrl);
                        parseEpisodeGrid(ajaxDoc, imageUrl, episodes);

                        Pattern stPattern = Pattern.compile("st=(\\d+)");
                        Matcher stMatcher = stPattern.matcher(html);
                        Set<String> fetched = new HashSet<>();
                        fetched.add("0");
                        while (stMatcher.find()) {
                            String st = stMatcher.group(1);
                            if (!fetched.add(st)) continue;
                            String pageUrl = base + "/ajax.php?module=movie_select&name=Catmovie&file=" + cmId + "&st=" + st;
                            Request pageReq = new Request.Builder()
                                .url(pageUrl)
                                .get()
                                .header("User-Agent", UA)
                                .header("Referer", base + "/")
                                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                                .build();
                            try (Response pageRes = client.newCall(pageReq).execute()) {
                                if (pageRes.isSuccessful()) {
                                    Document pageDoc = org.jsoup.Jsoup.parse(pageRes.body().string(), pageUrl);
                                    parseEpisodeGrid(pageDoc, imageUrl, episodes);
                                }
                            }
                        }
                    }
                }
            } catch (IOException e) {
                Log.e(TAG, "Failed to fetch episodes for cmId=" + cmId, e);
            }
        } else {
            String epTitle = "";
            Element ogTitle = doc.selectFirst("meta[property=og:title]");
            if (ogTitle != null) epTitle = ogTitle.attr("content");
            episodes.add(new Episode(
                epTitle.isEmpty() ? "วิดีโอ" : epTitle,
                url,
                imageUrl,
                "",
                "https://" + domain + "/",
                1
            ));
        }

        return episodes;
    }

    private void parseEpisodeGrid(Document ajaxDoc, String imageUrl, List<Episode> episodes) {
        Elements gridItems = ajaxDoc.select("div.grid_view.list_view");
        for (int i = 0; i < gridItems.size(); i++) {
            Element item = gridItems.get(i);
            Element thumbLink = item.selectFirst("div.vid_thumb a");
            if (thumbLink == null) continue;

            String episodeUrl = thumbLink.attr("abs:href");
            if (episodeUrl.isEmpty()) continue;

            Element titleSpan = item.selectFirst("div.vid_info_wrap h2.title a span.title");
            String episodeName = "";
            if (titleSpan != null) episodeName = titleSpan.text().trim();
            if (episodeName.isEmpty()) {
                Element titleLink = item.selectFirst("div.vid_info_wrap h2.title a");
                if (titleLink != null) episodeName = titleLink.text().trim();
            }
            if (episodeName.isEmpty()) episodeName = "ตอนที่ " + (episodes.size() + i + 1);

            Element img = thumbLink.selectFirst("img");
            String epImage = imageUrl;
            if (img != null) {
                String src = img.attr("src");
                if (src.startsWith("//")) src = "https:" + src;
                if (!src.isEmpty()) epImage = src;
            }

            episodes.add(new Episode(
                episodeName,
                episodeUrl,
                epImage,
                "",
                "https://" + domain + "/",
                episodes.size() + 1
            ));
        }
    }

    private String parseOldHtmlVideoPage(Document epDoc) throws IOException {
        if (domain == null || domain.isEmpty()) domain = getDomain();

        Element contentUrlMeta = epDoc.selectFirst("meta[itemprop=contentUrl]");
        if (contentUrlMeta != null) {
            String contentUrl = contentUrlMeta.attr("content");
            if (contentUrl != null && !contentUrl.isEmpty()) {
                if (contentUrl.startsWith("http")) {
                    return contentUrl;
                }
                String sdUrl = "https://" + domain + "/" + contentUrl;
                String hdUrl = sdUrl.replace("c2Q=/master.m3u8", "aGQ=/master.m3u8");
                if (!hdUrl.equals(sdUrl) && isUrlAccessible(hdUrl)) {
                    return hdUrl;
                }
                return sdUrl;
            }
        }

        Element fileMeta = epDoc.selectFirst("meta[name=file]");
        if (fileMeta != null) {
            String file = fileMeta.attr("content");
            if (file != null && !file.isEmpty()) {
                if (file.startsWith("http")) return file;
                return "https://" + domain + "/" + file;
            }
        }

        String html = epDoc.html();
        Pattern jwPattern = Pattern.compile("\"file\"\\s*:\\s*\"([^\"]+\\.m3u8)\"", Pattern.CASE_INSENSITIVE);
        Matcher jwMatcher = jwPattern.matcher(html);
        if (jwMatcher.find()) {
            return jwMatcher.group(1).replace("\\/", "/");
        }

        Pattern sourcesPattern = Pattern.compile(
            "sources:\\s*\\[\\s*\\{\\s*file:\\s*\"([^\"]+\\.m3u8)\"", Pattern.CASE_INSENSITIVE);
        Matcher sourcesMatcher = sourcesPattern.matcher(html);
        if (sourcesMatcher.find()) {
            return sourcesMatcher.group(1).replace("\\/", "/");
        }

        Pattern directM3u8 = Pattern.compile("(https?://[^\\s\"']+\\.m3u8[^\\s\"']*)", Pattern.CASE_INSENSITIVE);
        Matcher directMatcher = directM3u8.matcher(html);
        if (directMatcher.find()) {
            return directMatcher.group(1);
        }

        throw new IOException("ไม่พบลิงก์วิดีโอในหน้า");
    }

    private boolean isUrlAccessible(String url) {
        Request headRequest = new Request.Builder()
            .url(url)
            .method("HEAD", null)
            .header("User-Agent", "Mozilla/5.0")
            .header("Referer", "https://" + domain + "/")
            .build();
        try (Response resp = client.newCall(headRequest).execute()) {
            int code = resp.code();
            return code == 405 || resp.isSuccessful();
        } catch (Exception e) {
            return false;
        }
    }
}
