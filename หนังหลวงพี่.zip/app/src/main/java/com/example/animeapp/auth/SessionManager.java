package com.example.animeapp.auth;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {
    private static final String PREF = "AnimeAppAuth";
    private static final String KEY_TOKEN = "session_token";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_STATUS = "status";
    private static final String KEY_ROLE = "role";

    private SessionManager() {}

    public static void saveSession(Context context, String token, String username, String status, String role) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_TOKEN, token)
            .putString(KEY_USERNAME, username)
            .putString(KEY_STATUS, status)
            .putString(KEY_ROLE, role)
            .apply();
    }

    public static String getToken(Context context) {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_TOKEN, null);
    }

    public static String getUsername(Context context) {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_USERNAME, null);
    }

    public static String getStatus(Context context) {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_STATUS, "pending");
    }

    public static boolean hasSession(Context context) {
        String token = getToken(context);
        return token != null && !token.isEmpty();
    }

    public static void clear(Context context) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply();
    }
}
