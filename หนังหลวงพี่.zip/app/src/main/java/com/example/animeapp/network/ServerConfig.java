package com.example.animeapp.network;

public class ServerConfig {

    
    public static final String BASE_URL = "https://admin-spa-ten.vercel.app";

    public static String url(String path) {
        String base = BASE_URL.endsWith("/") ? BASE_URL.substring(0, BASE_URL.length() - 1) : BASE_URL;
        return base + "/" + path;
    }

    public static String authRegister() { return url("api/auth/register"); }
    public static String authLogin()    { return url("api/auth/login"); }
    public static String authSession()  { return url("api/auth/session"); }
    public static String authLogout()   { return url("api/auth/logout"); }
    public static String authHeartbeat(){ return url("api/auth/heartbeat"); }
    public static String config()       { return url("api/config"); }
}
