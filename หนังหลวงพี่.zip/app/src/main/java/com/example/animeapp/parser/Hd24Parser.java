package com.example.animeapp.parser;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import com.example.animeapp.models.Anime;
import com.example.animeapp.models.Episode;
import com.example.animeapp.network.OkHttpClientFactory;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.FormBody;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import com.example.animeapp.domain.DomainConfig;

public class Hd24Parser implements AnimeParser {
    
    private final OkHttpClient client;
    
    public Hd24Parser() {
        this.client = OkHttpClientFactory.getClientWithDoH();
    }
    
    private boolean isBlocked(Document doc) {
        if (doc.text().contains("Cloudflare") || 
            doc.text().contains("Access Denied")) {
            return true;
        }
        return false;
    }

    @Override
    public Anime parseAnimeDetail(Document doc) {
        return com.example.animeapp.parser.NativeParseBridge.parseAnimeDetail("movie24hd", doc);
    }

    @Override
    public List<Episode> parseEpisodes(Document doc, String imageUrl) {
        return com.example.animeapp.parser.NativeParseBridge.parseEpisodes("movie24hd", doc, imageUrl);
    }

    private void parseMovieEpisodes(Document doc, String imageUrl, String mainTitle, List<Episode> episodes) {
        Elements serverElements = doc.select("li.halim-episode span.halim-btn");
        Set<Integer> seenEps = new LinkedHashSet<>();

        for (Element server : serverElements) {
            try {
               
                if ("1000".equals(server.attr("data-server"))) continue;

                int epNum = Integer.parseInt(server.attr("data-episode").trim());
                if (!seenEps.add(epNum)) continue; // deduplicate

                String epTitle = !mainTitle.isEmpty() ? mainTitle : "ดูหนัง";
                episodes.add(new Episode(
                    epTitle, doc.baseUri(), imageUrl, "", doc.baseUri(), epNum
                ));
            } catch (Exception e) {
                continue;
            }
        }
    }

    @Override
    public String parseVideoUrl(Document epDoc, String referer, int episodeNumber) 
        throws IOException {
        
        try {
            if (isBlocked(epDoc)) {
                throw new IOException("Cloudflare บล็อกการเข้าถึง");
            }

            Element mainServer = epDoc.selectFirst("span.halim-btn[data-server='1']");
            if (mainServer == null) {
                return "";
            }

            String postId = mainServer.attr("data-post-id");
            String episode = mainServer.attr("data-episode");
            String nonce = extractNonce(epDoc.html());
            if (nonce.isEmpty()) {
                nonce = "none";
            }

            String lang = getLanguage(epDoc);

            FormBody formBody = new FormBody.Builder()
                .add("action", "halim_ajax_player")
                .add("nonce", nonce)
                .add("episode", episode)
                .add("postid", postId)
                .add("server", "1")
                .add("lang", lang)
                .build();
                
           
            Request request = new Request.Builder()
                .url(DomainConfig.ApiUrl.GET_API())
                .post(formBody)
                .addHeader("Referer", referer)
                .addHeader("Origin", "https://" + DomainConfig.BaseUrl.MOVIE24HD())
                .addHeader("X-Requested-With", "XMLHttpRequest")
                .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36")
                .build();

            try (Response response = client.newCall(request).execute()) {
                if (!response.isSuccessful()) {
                    throw new IOException("API request failed: " + response.code());
                }

                String html = response.body().string();
                Document responseDoc = Jsoup.parse(html);

                Element iframe = responseDoc.selectFirst("iframe");
                if (iframe == null) {
                    return "";
                }

                String videoUrl = iframe.attr("src");
                return convertToM3u8Url(videoUrl);
            }

        } catch (Exception e) {
            throw new IOException("การดึงวิดีโอล้มเหลว", e);
        }
    }
    
    private String extractNonce(String html) {
        Pattern pattern = Pattern.compile("var halim_nonce\\s*=\\s*['\"]([a-f0-9]+)['\"]");
        Matcher matcher = pattern.matcher(html);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return "";
    }

    private String getLanguage(Document doc) {
        Element langSelect = doc.selectFirst("#Lang_select");
        if (langSelect == null) {
            return "Sound Track";
        }

        boolean hasThai = false;
        boolean hasSoundTrack = false;

        for (Element option : langSelect.select("option")) {
            String value = option.attr("value").trim();
            if (value.equalsIgnoreCase("Thai")) {
                hasThai = true;
            } else if (value.equalsIgnoreCase("Sound Track")) {
                hasSoundTrack = true;
            }
        }

        if (hasThai) {
            return "Thai";
        } else if (hasSoundTrack) {
            return "Sound Track";
        } else {
            return "Sound Track";
        }
    }

    private String convertToM3u8Url(String url) {
        if (url.contains(".m3u8")) {
            return url;
        }

        Pattern pattern = Pattern.compile("id=([^&]+)");
        Matcher matcher = pattern.matcher(url);
        if (matcher.find()) {
            String id = matcher.group(1);
            return String.format(DomainConfig.ApiUrl.PLAY_API() + "%s/%s.m3u8", id, id);
        }
        return url;
    }
}
