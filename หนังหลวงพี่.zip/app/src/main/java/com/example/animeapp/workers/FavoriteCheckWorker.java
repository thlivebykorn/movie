package com.example.animeapp.workers;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.example.animeapp.R;
import com.example.animeapp.activities.AnimeDetailActivity;
import com.example.animeapp.database.DatabaseHelper;
import com.example.animeapp.models.Anime;
import com.example.animeapp.models.Episode;
import com.example.animeapp.network.AnimeApiClient;
import com.example.animeapp.utils.NotificationPermissionHelper;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

public class FavoriteCheckWorker extends Worker {

    private static final String TAG = "FavoriteCheckWorker";
    private static final String CHANNEL_ID = "favorite_notify";

    public FavoriteCheckWorker(@NonNull Context ctx, @NonNull WorkerParameters params) {
        super(ctx, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        Log.d(TAG, "เริ่มเช็ครายการโปรด...");
        Context ctx = getApplicationContext();

        if (!com.example.animeapp.domain.DomainConfig.isLoaded()) {
            Log.d(TAG, "DomainConfig ยังไม่โหลด เริ่ม initialize()");
            com.example.animeapp.domain.DomainConfig.initialize(ctx);
        }

        int waitMs = 0;
        while (!com.example.animeapp.domain.DomainConfig.isLoaded() && waitMs < 20000) {
            try { Thread.sleep(500); } catch (InterruptedException e) { break; }
            waitMs += 500;
            Log.d(TAG, "รอ DomainConfig... " + waitMs + "ms");
        }
        if (!com.example.animeapp.domain.DomainConfig.isLoaded()) {
            Log.w(TAG, "DomainConfig โหลดไม่สำเร็จ retry");
            return Result.retry();
        }

        
        int safeWait = 0;
        while (com.example.animeapp.domain.DomainConfig.getSources().isEmpty() && safeWait < 5000) {
            try { Thread.sleep(300); } catch (InterruptedException e) { break; }
            safeWait += 300;
            Log.d(TAG, "รอ sources โหลด... " + safeWait + "ms");
        }

        DatabaseHelper db = new DatabaseHelper(ctx);

       
        android.content.SharedPreferences domainPrefs =
            ctx.getSharedPreferences("KnownDomains", android.content.Context.MODE_PRIVATE);
        android.content.SharedPreferences.Editor editor = domainPrefs.edit();
        boolean anyMigrated = false;

        for (com.example.animeapp.model.Source src :
                com.example.animeapp.domain.DomainConfig.getSources()) {
            if (src.getDomain() == null || src.getDomain().isEmpty()) continue;
            String newDomain = src.getDomain().replaceFirst("^www\\.", "");
            String knownDomain = domainPrefs.getString(src.getId(), null);


            if (knownDomain == null) {
                
                int n = db.migrateToNewDomain(src.getName(), newDomain);
                if (n > 0) {
                    Log.d(TAG, "[" + src.getId() + "] first-run migrate " + n + " rows -> " + newDomain);
                    anyMigrated = true;
                }
                editor.putString(src.getId(), newDomain);
            } else if (!knownDomain.equals(newDomain)) {
                int n = db.migrateDomain(knownDomain, newDomain);
                Log.d(TAG, "[" + src.getId() + "] domain changed: "
                    + knownDomain + " -> " + newDomain + " (migrated " + n + " rows)");
                editor.putString(src.getId(), newDomain);
                anyMigrated = true;
            }
        }
        editor.apply();
        if (anyMigrated) com.example.animeapp.network.AnimeApiClient.resetParsers();

        List<DatabaseHelper.FavoriteItem> favorites = db.getAllFavorites();
        if (favorites.isEmpty()) {
            Log.d(TAG, "ไม่มีรายการโปรด");
            return Result.success();
        }

        createNotificationChannel(ctx);
        int notified = 0;

        for (DatabaseHelper.FavoriteItem fav : favorites) {
            try {
                Anime anime = AnimeApiClient.fetchAnimeData(fav.animeUrl, null);
                if (anime == null) continue;

                List<Episode> episodes = anime.getEpisodes();
                if (episodes == null || episodes.isEmpty()) continue;

                Episode latest = episodes.get(episodes.size() - 1);
                String latestName = latest.getTitle();

                String savedEp = fav.lastEpisode;

                if (savedEp == null || savedEp.isEmpty()) {
                    db.updateFavoriteLastEpisode(fav.animeUrl, latestName);
                    continue;
                }

                if (!savedEp.equals(latestName)) {
                    Log.d(TAG, fav.title + " → ตอนใหม่: " + latestName);
                    String imageUrl = (anime.getImageUrl() != null && !anime.getImageUrl().isEmpty())
                            ? anime.getImageUrl() : fav.imageUrl;
                   
                    boolean notifyEnabled = ctx.getSharedPreferences("AnimeAppPrefs",
                        android.content.Context.MODE_PRIVATE)
                        .getBoolean("notify_new_episode", true);
                    if (notifyEnabled) {
                        showNotification(ctx, fav.title, latestName, fav.animeUrl, imageUrl);
                    }
                    db.updateFavoriteLastEpisode(fav.animeUrl, latestName);
                    notified++;
                }

            } catch (Exception e) {
                Log.w(TAG, "เช็ค " + fav.title + " ล้มเหลว: " + e.getMessage());
            }
        }

        Log.d(TAG, "เสร็จ เจอตอนใหม่ " + notified + " เรื่อง");
        return Result.success();
    }


    private void showNotification(Context ctx, String title, String episode,
                                  String animeUrl, String imageUrl) {
       
        Intent intent = new Intent(ctx, AnimeDetailActivity.class);
        intent.putExtra("anime_url", animeUrl);
        intent.putExtra("anime_title", title);
        intent.putExtra("scroll_to_episode", episode);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);

        PendingIntent pi = PendingIntent.getActivity(
            ctx, animeUrl.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Bitmap coverBitmap = null;
        if (imageUrl != null && !imageUrl.isEmpty()) {
            Log.d(TAG, "กำลังโหลดรูป: " + imageUrl);
            coverBitmap = loadBitmapFromUrl(imageUrl);
            Log.d(TAG, "โหลดรูป " + (coverBitmap != null ? "สำเร็จ " + coverBitmap.getWidth() + "x" + coverBitmap.getHeight() : "ล้มเหลว"));
        } else {
            Log.w(TAG, "imageUrl ว่างเปล่า ไม่โหลดรูป");
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.drawable.app_yy)
            .setContentTitle("🆕 " + title)
            .setContentText(episode + " ออกแล้ว! 🎬")
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pi)
            .setGroup("anime_ep_" + animeUrl.hashCode()) 
            .setGroupSummary(false);

        if (coverBitmap != null) {
           
            Bitmap squareThumb = cropToSquare(coverBitmap);
            builder.setLargeIcon(squareThumb)
                .setStyle(new NotificationCompat.BigPictureStyle()
                    .bigPicture(coverBitmap)
                    .bigLargeIcon((Bitmap) null) 
                    .setSummaryText(episode + " ออกแล้ว! กดเพื่อดูเลย"));
        } else {
          
            builder.setStyle(new NotificationCompat.BigTextStyle()
                .bigText(episode + " ออกแล้ว! กดเพื่อดูเลย"));
        }

        NotificationManager nm = (NotificationManager)
            ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(animeUrl.hashCode(), builder.build());
    }

    
    private Bitmap cropToSquare(Bitmap src) {
        int w = src.getWidth();
        int h = src.getHeight();
        if (w == h) return src;
        int size = Math.min(w, h);
        int x = (w - size) / 2;
        int y = (h - size) / 2;
        return Bitmap.createBitmap(src, x, y, size, size);
    }

   
    private Bitmap loadBitmapFromUrl(String imageUrl) {
        try {
            URL url = new URL(imageUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(8000);
            conn.setRequestProperty("User-Agent",
                "Mozilla/5.0 (Android) AnimeApp/1.0");
            conn.setDoInput(true);
            conn.connect();

            if (conn.getResponseCode() != 200) {
                conn.disconnect();
                return null;
            }

            InputStream is = conn.getInputStream();
           
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = 1;
            Bitmap bmp = BitmapFactory.decodeStream(is, null, opts);
            is.close();
            conn.disconnect();

            if (bmp == null) return null;

           
            int maxW = 512;
            if (bmp.getWidth() > maxW) {
                float scale = (float) maxW / bmp.getWidth();
                int newH = Math.round(bmp.getHeight() * scale);
                Bitmap scaled = Bitmap.createScaledBitmap(bmp, maxW, newH, true);
                bmp.recycle();
                return scaled;
            }
            return bmp;

        } catch (Exception e) {
            Log.w(TAG, "โหลดรูปล้มเหลว: " + imageUrl + " → " + e.getMessage());
            return null;
        }
    }

    private void createNotificationChannel(Context ctx) {
       
        NotificationPermissionHelper.createChannels(ctx);
    }
}
