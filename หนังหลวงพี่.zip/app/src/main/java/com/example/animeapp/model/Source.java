package com.example.animeapp.model;

import com.example.animeapp.model.Category;
import java.util.List;

public class Source {
    private String id;
    private String name;
    private String domain;
    private List<Category> categories;

    public Source(String id, String name, String domain, List<Category> categories) {
        this.id = id;
        this.name = name;
        this.domain = domain;
        this.categories = categories;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDomain() {
        return domain;
    }

    public List<Category> getCategories() {
        return categories;
    }

    public String getFullUrl(String categoryId) {
        for (Category category : categories) {
            if (category.getId().equals(categoryId)) {
                return "https://" + domain + category.getPath();
            }
        }
        return "https://" + domain;
    }

    public String getCategoryTitle(String categoryId) {
        for (Category category : categories) {
            if (category.getId().equals(categoryId)) {
                return name + " " + category.getTitle();
            }
        }
        return name;
    }
}
