package com.example.animeapp.network;

import android.content.Context;

import com.example.animeapp.BuildConfig;
import com.example.animeapp.security.AppSecurityManager;
import com.example.animeapp.security.DeviceIdentity;
import com.example.animeapp.auth.SessionManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ServerApiClient {
    private static final String TAG = "ServerApiClient";
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    private static OkHttpClient client;

    private static synchronized OkHttpClient client() {
        if (client == null) {
            client = new OkHttpClient.Builder()
                    .connectTimeout(20, TimeUnit.SECONDS)
                    .readTimeout(20, TimeUnit.SECONDS)
                    .writeTimeout(20, TimeUnit.SECONDS)
                    .followRedirects(true)
                    .build();
        }
        return client;
    }

    public static class ApiException extends IOException {
        public final String code;
        public ApiException(String code, String message) {
            super(message);
            this.code = code;
        }
    }

    private static JSONObject post(Context context, String url, JSONObject body) throws IOException {
        RequestBody rb = RequestBody.create(body.toString(), JSON);
        Request req = new Request.Builder()
                .url(url)
                .post(rb)
                .header("Content-Type", "application/json")
                .build();
        return execute(req);
    }

    private static JSONObject get(Context context, String url) throws IOException {
        Request req = new Request.Builder()
                .url(url)
                .header("Authorization", "Bearer " + SessionManager.getToken(context))
                .header("X-Device-Id", DeviceIdentity.getDeviceId(context))
                .header("X-App-Sig", sig(context))
                .header("X-App-Ver", BuildConfig.VERSION_NAME)
                .build();
        return execute(req);
    }

    private static JSONObject execute(Request req) throws IOException {
        try (Response resp = client().newCall(req).execute()) {
            String bodyStr = resp.body() != null ? resp.body().string() : "{}";
            JSONObject json;
            try {
                json = new JSONObject(bodyStr);
            } catch (Exception e) {
                json = new JSONObject();
            }
            if (!resp.isSuccessful()) {
                String code = json.optString("code", "ERROR");
                String message = json.optString("message", "เกิดข้อผิดพลาด (" + resp.code() + ")");
                throw new ApiException(code, message);
            }
            return json;
        }
    }

    private static String executeRaw(Request req) throws IOException {
        try (Response resp = client().newCall(req).execute()) {
            String bodyStr = resp.body() != null ? resp.body().string() : "{}";
            if (!resp.isSuccessful()) {
                JSONObject json;
                try {
                    json = new JSONObject(bodyStr);
                } catch (Exception e) {
                    json = new JSONObject();
                }
                String code = json.optString("code", "ERROR");
                String message = json.optString("message", "เกิดข้อผิดพลาด (" + resp.code() + ")");
                throw new ApiException(code, message);
            }
            return bodyStr;
        }
    }

    private static String sig(Context context) {
        String h = AppSecurityManager.getAppSignatureHash(context);
        return h == null ? "" : h;
    }

    public static JSONObject register(Context context, String username, String password) throws IOException {
        JSONObject body = new JSONObject();
        try {
            body.put("username", username);
            body.put("password", password);
            body.put("device_id", DeviceIdentity.getDeviceId(context));
            body.put("signature_hash", sig(context));
            body.put("app_version", BuildConfig.VERSION_NAME);
            body.put("device_model", android.os.Build.MODEL);
        } catch (JSONException e) {
            throw new IOException("ไม่สามารถสร้างข้อมูลคำขอได้", e);
        }
        return post(context, ServerConfig.authRegister(), body);
    }

    public static JSONObject login(Context context, String username, String password) throws IOException {
        JSONObject body = new JSONObject();
        try {
            body.put("username", username);
            body.put("password", password);
            body.put("device_id", DeviceIdentity.getDeviceId(context));
            body.put("signature_hash", sig(context));
            body.put("app_version", BuildConfig.VERSION_NAME);
            body.put("device_model", android.os.Build.MODEL);
        } catch (JSONException e) {
            throw new IOException("ไม่สามารถสร้างข้อมูลคำขอได้", e);
        }
        return post(context, ServerConfig.authLogin(), body);
    }

    public static JSONObject checkSession(Context context) throws IOException {
        return get(context, ServerConfig.authSession());
    }

    public static void logout(Context context) {
        try {
            JSONObject body = new JSONObject().put("token", SessionManager.getToken(context));
            post(context, ServerConfig.authLogout(), body);
        } catch (Exception ignored) {}
    }

    public static JSONObject heartbeat(Context context) throws IOException {
        return post(context, ServerConfig.authHeartbeat(), new JSONObject());
    }

    public static JSONObject fetchConfig(Context context) throws IOException {
        return get(context, ServerConfig.config());
    }

    public static String fetchConfigRaw(Context context) throws IOException {
        Request req = new Request.Builder()
                .url(ServerConfig.config())
                .header("Authorization", "Bearer " + SessionManager.getToken(context))
                .header("X-Device-Id", DeviceIdentity.getDeviceId(context))
                .header("X-App-Sig", sig(context))
                .header("X-App-Ver", BuildConfig.VERSION_NAME)
                .build();
        return executeRaw(req);
    }
}
