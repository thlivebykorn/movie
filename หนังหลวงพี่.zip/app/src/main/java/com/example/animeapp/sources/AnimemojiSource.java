package com.example.animeapp.sources;

import android.content.Context;
import android.util.Log;

import com.example.animeapp.models.AnimeItem;
import com.example.animeapp.models.PageItem;
import com.example.animeapp.network.OkHttpClientFactory;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import com.example.animeapp.domain.DomainConfig;

public class AnimemojiSource implements AnimeSource {
    
    private static final String TAG = "AnimemojiSource";
    private final Context context;
    private final ExecutorService executorService;
    private final OkHttpClient client;

    public AnimemojiSource(Context context) {
        this.context = context;
        this.executorService = Executors.newSingleThreadExecutor();
        this.client = OkHttpClientFactory.getClientWithDoH();
    }

    @Override
    public String getSourceName() {
        return DomainConfig.SourceName.ANIMEMOJI();
    }

    @Override
    public String getBaseUrl() {
        return "https://" + DomainConfig.BaseUrl.ANIMEMOJI() + DomainConfig.HomePage.ANIMEMOJI();
    }

    @Override
    public String getSearchUrl(String keyword) {
        return "https://" + DomainConfig.BaseUrl.ANIMEMOJI() + "/?s=" + keyword;
    }

    @Override
    public void fetchAnimeList(String pageUrl, AnimeLoadCallback callback) {
        executorService.execute(() -> {
            try {
                
                
                Request request = new Request.Builder()
                    .url(pageUrl)
                    .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
                    .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
                    .header("Accept-Language", "th-TH,th;q=0.9,en-US;q=0.8,en;q=0.7")
                    .header("Referer", "https://www.google.com")
                    .build();

                Response response = client.newCall(request).execute();
                
                if (response.isSuccessful()) {
                    String html = response.body().string();
                    Document doc = Jsoup.parse(html, pageUrl);
                    
                    com.example.animeapp.parser.NativeParseBridge.SourceListResult nativeResult = com.example.animeapp.parser.NativeParseBridge.parseSourceList("animemoji", doc);
                    
                    List<AnimeItem> animeItems = nativeResult.animeItems;
                    
                    List<PageItem> pageItems = nativeResult.pageItems;
                    
                    
                    callback.onSuccess(animeItems, pageItems);
                } else {
                    
                    callback.onFailure("โหลดหน้าไม่สำเร็จ (HTTP " + response.code() + ")");
                }
                
                response.close();
                
            } catch (IOException e) {
                
                callback.onFailure("เกิดข้อผิดพลาดในการเชื่อมต่อ: " + e.getMessage());
            } catch (Exception e) {
                
                callback.onFailure("เกิดข้อผิดพลาด: " + e.getMessage());
            }
        });
    }

    private List<AnimeItem> parseAnimeItems(Document doc) {
        return com.example.animeapp.parser.NativeParseBridge.parseSourceList("animemoji", doc).animeItems;
    }

    private void parseGenericAnimeItems(Document doc, List<AnimeItem> items, Set<String> seenUrls) {
        Elements links = doc.select("a[href]:has(img)");
        Log.d(TAG, "Fallback found " + links.size() + " image links");

        for (Element link : links) {
            try {
                String url = link.absUrl("href");
                if (url.isEmpty()) url = link.attr("href");
                if (!isLikelyAnimeUrl(url) || !seenUrls.add(url)) continue;

                Element img = link.selectFirst("img");
                String title = firstNonEmpty(
                    link.attr("title"),
                    img != null ? img.attr("alt") : "",
                    link.text()
                );
                title = cleanTitle(title);
                if (title.isEmpty()) continue;

                String imageUrl = parseImageUrl(link);
                String subtitleText = extractEpisodeText(link.parent() != null ? link.parent() : link);
                items.add(new AnimeItem(title, url, imageUrl, subtitleText));
                Log.d(TAG, "Fallback added item: " + title);
            } catch (Exception e) {
                Log.e(TAG, "Error parsing fallback anime item: " + e.getMessage());
            }
        }
    }

    private List<PageItem> parsePageItems(Document doc) {
        return com.example.animeapp.parser.NativeParseBridge.parseSourceList("animemoji", doc).pageItems;
    }

    private boolean isNumeric(String s) {
        try { Integer.parseInt(s); return true; } catch (NumberFormatException e) { return false; }
    }

    private String parseImageUrl(Element link) {
        if (link == null) return "";
        
        Element img = link.selectFirst("img");
        if (img != null) {
            if (img.hasAttr("data-src")) {
                String dataSrc = img.absUrl("data-src");
                if (dataSrc.isEmpty()) dataSrc = img.attr("data-src");
                if (!dataSrc.isEmpty() && !dataSrc.startsWith("data:image")) {
                    return dataSrc;
                }
            }
            
            if (img.hasAttr("src")) {
                String src = img.absUrl("src");
                if (src.isEmpty()) src = img.attr("src");
                if (!src.isEmpty() && !src.startsWith("data:image")) {
                    return src;
                }
            }
            
            if (img.hasAttr("data-srcset")) {
                String srcset = img.attr("data-srcset");
                if (!srcset.isEmpty()) {
                    String[] urls = srcset.split(",");
                    if (urls.length > 0) {
                        String firstUrl = urls[0].trim().split(" ")[0];
                        if (!firstUrl.startsWith("data:image")) {
                            return firstUrl;
                        }
                    }
                }
            }
        }
        
        return "";
    }

    private boolean isLikelyAnimeUrl(String url) {
        if (url == null || url.isEmpty()) return false;
        String lower = url.toLowerCase();
        return !lower.contains("/episode/")
            && !lower.contains("/tag/")
            && !lower.contains("/genre/")
            && !lower.contains("/category/")
            && !lower.contains("/page/")
            && !lower.endsWith("#");
    }

    private String firstNonEmpty(String... values) {
        if (values == null) return "";
        for (String value : values) {
            if (value != null && !value.trim().isEmpty()) return value.trim();
        }
        return "";
    }

    private String cleanTitle(String title) {
        if (title == null) return "";
        return title.replace("Image:", "").replaceAll("\\s+", " ").trim();
    }

    private String extractEpisodeText(Element element) {
        if (element == null) return "";
        Matcher matcher = Pattern.compile("(ตอน(?:ที่)?\\s*\\d+|EP\\.?\\s*\\d+|Episode\\s*\\d+)", Pattern.CASE_INSENSITIVE)
            .matcher(element.text());
        return matcher.find() ? matcher.group(1).trim() : "";
    }

    public void cleanup() {
        if (executorService != null && !executorService.isShutdown()) {
            executorService.shutdown();
        }
    }
}
