package com.example.animeapp.utils;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;


public class NotificationPermissionHelper {

    private static final String TAG = "NotifPermission";
    public static final int REQUEST_CODE = 1001;

    public interface PermissionCallback {
        void onGranted();
        void onDenied();
    }

   
    public static boolean isGranted(Context ctx) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ContextCompat.checkSelfPermission(ctx,
                Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        }
       
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        return nm != null && nm.areNotificationsEnabled();
    }

   
    public static ActivityResultLauncher<String> registerLauncher(
        AppCompatActivity activity,
        PermissionCallback callback
    ) {
        return activity.registerForActivityResult(
            new ActivityResultContracts.RequestPermission(),
            granted -> {
                if (granted) {
                    Log.d(TAG, "POST_NOTIFICATIONS granted");
                    callback.onGranted();
                } else {
                    Log.w(TAG, "POST_NOTIFICATIONS denied");
                    callback.onDenied();
                }
            }
        );
    }

    
    public static void requestPermission(
        AppCompatActivity activity,
        ActivityResultLauncher<String> launcher,
        PermissionCallback callback
    ) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
           
            if (isGranted(activity)) {
                callback.onGranted();
            } else {
               
                showGoToSettingsDialog(activity);
                callback.onDenied();
            }
            return;
        }

      
        if (isGranted(activity)) {
            callback.onGranted();
            return;
        }

       
        if (activity.shouldShowRequestPermissionRationale(
                Manifest.permission.POST_NOTIFICATIONS)) {
            new AlertDialog.Builder(activity)
                .setTitle("เปิดการแจ้งเตือน")
                .setMessage("เปิดการแจ้งเตือนเพื่อรับแจ้งเตือนเมื่ออนิเมะในรายการโปรดออกตอนใหม่")
                .setPositiveButton("อนุญาต", (d, w) ->
                    launcher.launch(Manifest.permission.POST_NOTIFICATIONS))
                .setNegativeButton("ไม่ต้องการ", (d, w) -> callback.onDenied())
                .show();
        } else {
           
            launcher.launch(Manifest.permission.POST_NOTIFICATIONS);
        }
    }

   
    public static void showGoToSettingsDialog(Activity activity) {
        new AlertDialog.Builder(activity)
            .setTitle("เปิดการแจ้งเตือน")
            .setMessage("กรุณาเปิดการแจ้งเตือนในการตั้งค่าแอป เพื่อรับแจ้งเตือนตอนใหม่")
            .setPositiveButton("ไปที่การตั้งค่า", (d, w) -> {
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                intent.setData(Uri.fromParts("package", activity.getPackageName(), null));
                activity.startActivity(intent);
            })
            .setNegativeButton("ยกเลิก", null)
            .show();
    }

  
    public static void createChannels(Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;

        NotificationManager nm = ctx.getSystemService(NotificationManager.class);
        if (nm == null) return;

       
        NotificationChannel favChannel = new NotificationChannel(
            "favorite_notify",
            "รายการโปรด — ตอนใหม่",
            NotificationManager.IMPORTANCE_HIGH
        );
        favChannel.setDescription("แจ้งเตือนเมื่ออนิเมะในรายการโปรดออกตอนใหม่");
        favChannel.enableVibration(true);
        favChannel.setShowBadge(true);
        nm.createNotificationChannel(favChannel);

       
        NotificationChannel broadcastChannel = new NotificationChannel(
            "anime_notifications",
            "ประกาศจากแอดมิน",
            NotificationManager.IMPORTANCE_DEFAULT
        );
        broadcastChannel.setDescription("ประกาศและข่าวสารจากแอดมิน");
        nm.createNotificationChannel(broadcastChannel);

        Log.d(TAG, "Notification channels created");
    }

   
    public static boolean checkAndRequest(
        AppCompatActivity activity,
        ActivityResultLauncher<String> launcher
    ) {
        if (isGranted(activity)) return true;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            launcher.launch(Manifest.permission.POST_NOTIFICATIONS);
        }
        return false;
    }
}
