package com.example.animeapp.controllers;

import android.app.Activity;
import androidx.media3.ui.PlayerView;
import com.example.animeapp.managers.BrightnessVolumeManager;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.os.Handler;
import android.os.Looper;
import android.content.res.Resources;
import android.util.DisplayMetrics;

public class PlayerGestureController {
    private boolean enabled = true;

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
    private final Activity activity;
    private final PlayerView playerView;
    private final BrightnessVolumeManager brightnessVolumeManager;
    private final LinearLayout brightnessVolumeContainer;
    private final ImageView brightnessIcon;
    private final ImageView volumeIcon;
    private final TextView brightVolumeTV;
    private long seekPosition = -1;
    private boolean isSeeking = false;
    private boolean shouldShowController = true;
    private int touchPositionX;
    private static final int SHOW_MAX_BRIGHTNESS = 100;
    
    private enum GestureType { NONE, VERTICAL, HORIZONTAL }
    private GestureType activeGestureType = GestureType.NONE;
    
    private final GestureDetector gestureDetector;

    public PlayerGestureController(Activity activity, PlayerView playerView,
                                   BrightnessVolumeManager brightnessVolumeManager,
                                   LinearLayout brightnessVolumeContainer,
                                   ImageView brightnessIcon, ImageView volumeIcon, TextView brightVolumeTV) {
        this.activity = activity;
        this.playerView = playerView;
        this.brightnessVolumeManager = brightnessVolumeManager;
        this.brightnessVolumeContainer = brightnessVolumeContainer;
        this.brightnessIcon = brightnessIcon;
        this.volumeIcon = volumeIcon;
        this.brightVolumeTV = brightVolumeTV;
        this.gestureDetector = new GestureDetector(activity, gestureListener);
        setupGestureControls();
    }

    private void setupGestureControls() {
        playerView.setOnTouchListener((view, motionEvent) -> {
            if (enabled && gestureDetector.onTouchEvent(motionEvent)) {
                return true;
            }

            if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                brightnessVolumeContainer.setVisibility(View.GONE);
                activeGestureType = GestureType.NONE;

                if (isSeeking && playerView.getPlayer() != null) {
                    playerView.getPlayer().seekTo(seekPosition);
                    isSeeking = false;
                    seekPosition = -1;
                }

                if (!shouldShowController) {
                    playerView.setUseController(false);
                    new Handler(Looper.getMainLooper()).postDelayed(() -> {
                        shouldShowController = true;
                        playerView.setUseController(true);
                    }, 500);
                }
            }

            if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                touchPositionX = (int) motionEvent.getX();
            }
            return false;
        });
    }

    private final GestureDetector.SimpleOnGestureListener gestureListener = new GestureDetector.SimpleOnGestureListener() {
        @Override
        public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
            handleScrollGesture(distanceX, distanceY);
            return true;
        }
    };

    private void handleScrollGesture(float distanceX, float distanceY) {
        int deviceWidth = activity.getResources().getDisplayMetrics().widthPixels;

        
        if (activeGestureType == GestureType.NONE) {
            if (Math.abs(distanceX) > Math.abs(distanceY)) {
                if (Math.abs(distanceX) > 10) { 
                    activeGestureType = GestureType.HORIZONTAL;
                }
            } else {
                if (Math.abs(distanceY) > 10) { 
                    activeGestureType = GestureType.VERTICAL;
                }
            }
        }

        if (activeGestureType == GestureType.VERTICAL) {
           
            brightnessVolumeContainer.setVisibility(View.VISIBLE);
            shouldShowController = false;

            if (touchPositionX < deviceWidth / 2) {
                adjustBrightness(distanceY);
            } else {
                adjustVolume(distanceY);
            }
        } else if (activeGestureType == GestureType.HORIZONTAL) {
          
            handleSeekGesture(distanceX);
        }
    }

    private void handleSeekGesture(float distanceX) {
        if (playerView.getPlayer() == null) return;

        shouldShowController = false;
        isSeeking = true;

        long duration = playerView.getPlayer().getDuration();
        if (duration <= 0) return;

        if (seekPosition == -1) {
            seekPosition = playerView.getPlayer().getCurrentPosition();
        }

       
        long seekDelta = (long) (-distanceX * 100);
        seekPosition += seekDelta;

        if (seekPosition < 0) seekPosition = 0;
        if (seekPosition > duration) seekPosition = duration;

        showSeekFeedback(seekPosition, duration, seekDelta > 0);
    }

    private void showSeekFeedback(long position, long duration, boolean forward) {
        brightnessVolumeContainer.setVisibility(View.VISIBLE);
        brightnessIcon.setVisibility(View.GONE);
        volumeIcon.setVisibility(View.GONE);

        String timeStr = formatTime(position) + " / " + formatTime(duration);
        brightVolumeTV.setText(timeStr);
    }

    private String formatTime(long millis) {
        long seconds = (millis / 1000) % 60;
        long minutes = (millis / (1000 * 60)) % 60;
        long hours = (millis / (1000 * 60 * 60));

        if (hours > 0) {
            return String.format("%02d:%02d:%02d", hours, minutes, seconds);
        } else {
            return String.format("%02d:%02d", minutes, seconds);
        }
    }

    private void adjustBrightness(float distanceY) {
        volumeIcon.setVisibility(View.GONE);
        brightnessIcon.setVisibility(View.VISIBLE);

        boolean increase = distanceY > 0;
        int currentBrightness = brightnessVolumeManager.getBrightness();
        int newValue = increase ? currentBrightness + 1 : currentBrightness - 1;

        if (newValue >= 0 && newValue <= SHOW_MAX_BRIGHTNESS) {
            brightnessVolumeManager.setScreenBrightness(newValue);
        }

        brightVolumeTV.setText(String.valueOf(brightnessVolumeManager.getBrightness()));
    }

    private void adjustVolume(float distanceY) {
        volumeIcon.setVisibility(View.VISIBLE);
        brightnessIcon.setVisibility(View.GONE);

        boolean increase = distanceY > 0;
        int currentVolume = brightnessVolumeManager.getVolume();
        int maxVolume = brightnessVolumeManager.getMaxVolume();
        int newValue = increase ? currentVolume + 1 : currentVolume - 1;

        if (newValue >= 0 && newValue <= maxVolume) {
            brightnessVolumeManager.setVolume(newValue);
        }

        brightVolumeTV.setText(String.valueOf(brightnessVolumeManager.getVolume()));
    }
        }
