package com.example.animeapp.parser;

import com.example.animeapp.models.Anime;
import com.example.animeapp.models.Episode;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class HdMediaParser implements AnimeParser {

    private static final Pattern VDO_ID = Pattern.compile(
            "/(?:embed|e)/([A-Za-z0-9_-]+)");
    private static final Pattern EP_NUMBER = Pattern.compile(
            "(?:EP|ตอน)[.\\s]*(\\d+)", Pattern.CASE_INSENSITIVE);
    private static final String PLAYLIST_HOST = "vdohls.com";

    @Override
    public Anime parseAnimeDetail(Document doc) throws IOException {
        return com.example.animeapp.parser.NativeParseBridge.parseAnimeDetail("hdmedia", doc);
    }

    @Override
    public List<Episode> parseEpisodes(Document doc, String imageUrl) {
        return com.example.animeapp.parser.NativeParseBridge.parseEpisodes("hdmedia", doc, imageUrl);
    }

    @Override
    public String parseVideoUrl(Document doc, String referer, int episodeNumber) throws IOException {
        return com.example.animeapp.parser.NativeParseBridge.parseVideoUrl("hdmedia", doc, referer, episodeNumber);
    }

    private String findBoxPlayerEmbed(Document doc) {
        Element iframe = doc.selectFirst("iframe[name=box-player]");
        if (iframe != null) {
            String src = iframe.hasAttr("data-src") ? iframe.attr("data-src") : iframe.attr("src");
            if (src != null && !src.isEmpty()) {
                return src.startsWith("//") ? "https:" + src : src;
            }
        }
        Element link = doc.selectFirst("a.player-1-btn-link");
        if (link != null) {
            String href = link.attr("href");
            if (href != null && !href.isEmpty()) {
                return href.startsWith("//") ? "https:" + href : href;
            }
        }
        return "";
    }

    private String toPlaylistUrl(String embedUrl, String referer) {
        if (embedUrl.contains(".m3u8")) return embedUrl;

        Matcher m = VDO_ID.matcher(embedUrl);
        if (m.find()) {
            return "https://" + PLAYLIST_HOST + "/" + m.group(1) + "/playlist.m3u8";
        }
        return "";
    }

    private int extractEpisodeNumber(String text, int defaultNumber) {
        Matcher m = EP_NUMBER.matcher(text);
        if (m.find()) {
            try {
                return Integer.parseInt(m.group(1));
            } catch (NumberFormatException ignored) {}
        }
        return defaultNumber;
    }
}