package com.example.animeapp.security;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.pm.SigningInfo;
import android.os.Build;
import android.util.Log;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;


public class AppSecurityManager {

    private static final String TAG = "AppSecurityManager";

   
    private static final String EXPECTED_SIGNATURE_HASH =
        "552baa417da2acf0d41673289ed644240cd53a64d0edd797c956a81a193c58f6";

   
    private static final String HMAC_SECRET =
        "acb1750abeb26e6db1e5859c3dec174e70adf20bde67b43949d9e8ca22f263c0";

   
    public static boolean isSignatureValid(Context context) {
        try {
           
            boolean isDebug = (context.getApplicationInfo().flags & android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0;
            if (isDebug) return true;

            String hash = getAppSignatureHash(context);
            if (hash == null) return false;

            if (EXPECTED_SIGNATURE_HASH.startsWith("REPLACE_WITH")) {
                return true;
            }

            boolean valid = EXPECTED_SIGNATURE_HASH.equalsIgnoreCase(hash);
            if (!valid) {
                Log.e(TAG, "Actual Hash: " + hash);
               
                new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
                    android.widget.Toast.makeText(context, "Hash ไม่ตรง! ค่าจริงคือ: " + hash, android.widget.Toast.LENGTH_LONG).show();
                });
            }
            return valid;

        } catch (Exception e) {
            Log.e(TAG, "Signature check error: " + e.getMessage());
            return false;
        }
    }

  
    @SuppressWarnings("deprecation")
    public static String getAppSignatureHash(Context context) {
        try {
            Signature[] signatures;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                PackageInfo info = context.getPackageManager()
                        .getPackageInfo(context.getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
                SigningInfo signingInfo = info.signingInfo;
                if (signingInfo.hasMultipleSigners()) {
                    signatures = signingInfo.getApkContentsSigners();
                } else {
                    signatures = signingInfo.getSigningCertificateHistory();
                }
            } else {
                PackageInfo info = context.getPackageManager()
                        .getPackageInfo(context.getPackageName(), PackageManager.GET_SIGNATURES);
                signatures = info.signatures;
            }

            if (signatures != null && signatures.length > 0) {
                Signature sig = signatures[0];
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                md.update(sig.toByteArray());
                byte[] digest = md.digest();
                return bytesToHex(digest);
            }
        } catch (Exception e) {
            Log.e(TAG, "getAppSignatureHash error: " + e.getMessage());
        }
        return null;
    }

  
    public static JSONObject verifyAndExtract(String responseJson) {
        try {
            JSONObject response = new JSONObject(responseJson);

            if (!response.has("sig") || !response.has("data")) {
                
                return response;
            }

            String receivedSig = response.getString("sig");
            JSONObject data    = response.getJSONObject("data");
            String dataStr     = extractRawData(responseJson);
            if (dataStr == null) dataStr = data.toString();

            String expectedSig = computeHmac(dataStr);
            if (expectedSig == null) return null;

            if (!expectedSig.equalsIgnoreCase(receivedSig)) {
                Log.e(TAG, "🚫 HMAC ไม่ตรง! Response อาจถูกแก้ไข");
                return null;
            }

            return data;

        } catch (Exception e) {
            Log.e(TAG, "verifyAndExtract error: " + e.getMessage());
            return null;
        }
    }

    private static String extractRawData(String responseJson) {
        int from = 0;
        while (true) {
            int k = responseJson.indexOf("\"data\"", from);
            if (k < 0) return null;
            int i = k + 6;
            while (i < responseJson.length() && Character.isWhitespace(responseJson.charAt(i))) i++;
            if (i < responseJson.length() && responseJson.charAt(i) == ':') i++;
            while (i < responseJson.length() && Character.isWhitespace(responseJson.charAt(i))) i++;
            if (i >= responseJson.length() || responseJson.charAt(i) != '{') {
                from = k + 6;
                continue;
            }
            int depth = 0;
            boolean inString = false;
            boolean escaped = false;
            for (int j = i; j < responseJson.length(); j++) {
                char c = responseJson.charAt(j);
                if (inString) {
                    if (escaped) escaped = false;
                    else if (c == '\\') escaped = true;
                    else if (c == '"') inString = false;
                } else {
                    if (c == '"') inString = true;
                    else if (c == '{') depth++;
                    else if (c == '}') {
                        depth--;
                        if (depth == 0) return responseJson.substring(i, j + 1);
                    }
                }
            }
            from = k + 6;
        }
    }

   
    private static String computeHmac(String data) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            SecretKeySpec key = new SecretKeySpec(
                HMAC_SECRET.getBytes(StandardCharsets.UTF_8), "HmacSHA256");
            mac.init(key);
            byte[] result = mac.doFinal(data.getBytes(StandardCharsets.UTF_8));
            return bytesToHex(result);
        } catch (Exception e) {
            Log.e(TAG, "computeHmac error: " + e.getMessage());
            return null;
        }
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}
