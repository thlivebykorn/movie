package com.example.animeapp.security;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.UUID;

public class DeviceIdentity {
    private static final String PREF = "AnimeAppAuth";

    public static String getDeviceId(Context context) {
        SharedPreferences sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String id = sp.getString("device_id", null);
        if (id == null || id.isEmpty()) {
            id = "dev-" + UUID.randomUUID().toString();
            sp.edit().putString("device_id", id).apply();
        }
        return id;
    }
}
