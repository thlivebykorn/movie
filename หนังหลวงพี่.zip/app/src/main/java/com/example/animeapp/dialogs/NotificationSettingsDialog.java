package com.example.animeapp.dialogs;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

public class NotificationSettingsDialog {

    public static void show(Activity activity) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity, 0);

       
        LinearLayout card = new LinearLayout(activity);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(activity, 24), dp(activity, 28), dp(activity, 24), dp(activity, 20));

        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setShape(GradientDrawable.RECTANGLE);
        cardBg.setCornerRadius(dp(activity, 24));
        cardBg.setColor(Color.parseColor("#0E0E1A"));
        cardBg.setStroke(dp(activity, 1), Color.parseColor("#3D2B6B"));
        card.setBackground(cardBg);

        
        LinearLayout headerRow = new LinearLayout(activity);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams headerLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        headerLp.bottomMargin = dp(activity, 20);

       
        TextView iconBubble = new TextView(activity);
        iconBubble.setText("🔔");
        iconBubble.setTextSize(20);
        iconBubble.setGravity(Gravity.CENTER);
        int bubbleSize = dp(activity, 44);
        GradientDrawable bubbleBg = new GradientDrawable();
        bubbleBg.setShape(GradientDrawable.OVAL);
        bubbleBg.setColors(new int[]{Color.parseColor("#2A1F4A"), Color.parseColor("#1A1A2E")});
        bubbleBg.setStroke(dp(activity, 1), Color.parseColor("#7B5EA7"));
        iconBubble.setBackground(bubbleBg);
        LinearLayout.LayoutParams bubbleLp = new LinearLayout.LayoutParams(bubbleSize, bubbleSize);
        bubbleLp.rightMargin = dp(activity, 14);
        headerRow.addView(iconBubble, bubbleLp);

       
        LinearLayout titleCol = new LinearLayout(activity);
        titleCol.setOrientation(LinearLayout.VERTICAL);

        TextView titleTv = new TextView(activity);
        titleTv.setText("การแจ้งเตือน");
        titleTv.setTextSize(17);
        titleTv.setTextColor(Color.parseColor("#F5F0FF"));
        titleTv.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        titleCol.addView(titleTv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView subtitleTv = new TextView(activity);
        subtitleTv.setText("ตั้งค่าการแจ้งเตือนตอนใหม่");
        subtitleTv.setTextSize(12);
        subtitleTv.setTextColor(Color.parseColor("#5E5480"));
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        subLp.topMargin = dp(activity, 2);
        titleCol.addView(subtitleTv, subLp);

        headerRow.addView(titleCol, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(headerRow, headerLp);

       
        View div1 = new View(activity);
        div1.setBackgroundColor(Color.parseColor("#1F1635"));
        LinearLayout.LayoutParams divLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 1));
        divLp.bottomMargin = dp(activity, 18);
        card.addView(div1, divLp);

       
        boolean isBatteryOptDisabled = isIgnoringBatteryOptimizations(activity);
        View switchRow = buildSwitchRow(activity, card,
                "⚡", "ปิด Battery Optimization",
                "ช่วยให้แจ้งเตือนได้แม้ไม่เปิดแอปหลายวัน",
                isBatteryOptDisabled,
                (v, isChecked) -> {
                    if (isChecked && !isIgnoringBatteryOptimizations(activity)) {
                       
                        openBatterySettings(activity);
                    } else if (!isChecked && isIgnoringBatteryOptimizations(activity)) {
                      
                        try {
                            Intent intent = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                            activity.startActivity(intent);
                        } catch (Exception e) {
                            Intent fallback = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.fromParts("package", activity.getPackageName(), null));
                            activity.startActivity(fallback);
                        }
                    }
                });

       
        View div2 = new View(activity);
        div2.setBackgroundColor(Color.parseColor("#1F1635"));
        LinearLayout.LayoutParams div2Lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 1));
        div2Lp.topMargin = dp(activity, 6);
        div2Lp.bottomMargin = dp(activity, 16);
        card.addView(div2, div2Lp);

      
        LinearLayout statusRow = new LinearLayout(activity);
        statusRow.setOrientation(LinearLayout.HORIZONTAL);
        statusRow.setGravity(Gravity.CENTER_VERTICAL);

        View statusDot = new View(activity);
        int dotSize = dp(activity, 8);
        GradientDrawable dotBg = new GradientDrawable();
        dotBg.setShape(GradientDrawable.OVAL);
        dotBg.setColor(isBatteryOptDisabled
                ? Color.parseColor("#4DFFB0")
                : Color.parseColor("#FF5C8A"));
        statusDot.setBackground(dotBg);
        LinearLayout.LayoutParams dotLp = new LinearLayout.LayoutParams(dotSize, dotSize);
        dotLp.rightMargin = dp(activity, 8);
        statusRow.addView(statusDot, dotLp);

        TextView statusTv = new TextView(activity);
        statusTv.setText(isBatteryOptDisabled
                ? "พร้อมแจ้งเตือน ✓"
                : "การแจ้งเตือนอาจไม่ทำงานในบางเครื่อง");
        statusTv.setTextSize(12);
        statusTv.setTextColor(isBatteryOptDisabled
                ? Color.parseColor("#4DFFB0")
                : Color.parseColor("#FF5C8A"));
        statusRow.addView(statusTv, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        LinearLayout.LayoutParams statusRowLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        statusRowLp.bottomMargin = dp(activity, 18);
        card.addView(statusRow, statusRowLp);

       
        TextView btnClose = new TextView(activity);
        btnClose.setText("ปิด");
        btnClose.setTextSize(14);
        btnClose.setTextColor(Color.parseColor("#A89BC8"));
        btnClose.setGravity(Gravity.CENTER);
        btnClose.setPadding(0, dp(activity, 10), 0, dp(activity, 6));
        card.addView(btnClose, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

       
        ScrollView scrollView = new ScrollView(activity);
        scrollView.setVerticalScrollBarEnabled(false);
        int screenH = activity.getResources().getDisplayMetrics().heightPixels;
        scrollView.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, (int)(screenH * 0.85f)));
        scrollView.addView(card, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

       
        builder.setView(scrollView);
        builder.setCancelable(true);
        AlertDialog dialog = builder.create();

        Window win = dialog.getWindow();
        if (win != null) {
            win.setBackgroundDrawableResource(android.R.color.transparent);
            win.setDimAmount(0.7f);
            WindowManager.LayoutParams lp = win.getAttributes();
            lp.width = (int) (activity.getResources().getDisplayMetrics().widthPixels * 0.88f);
            win.setAttributes(lp);
        }

        btnClose.setOnClickListener(v -> dialog.dismiss());
        dialog.show();

       
        scrollView.setAlpha(0f);
        scrollView.setScaleX(0.88f);
        scrollView.setScaleY(0.88f);
        scrollView.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(380).setInterpolator(new OvershootInterpolator(1.1f)).start();
    }

   

    private static View buildSwitchRow(Activity ctx, LinearLayout parent,
                                       String emoji, String label, String desc,
                                       boolean initialState,
                                       CompoundButton.OnCheckedChangeListener listener) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rowLp.bottomMargin = dp(ctx, 4);

       
        LinearLayout topRow = new LinearLayout(ctx);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);

        
        TextView emojiBubble = new TextView(ctx);
        emojiBubble.setText(emoji);
        emojiBubble.setTextSize(15);
        emojiBubble.setGravity(Gravity.CENTER);
        int eSize = dp(ctx, 34);
        GradientDrawable eBg = new GradientDrawable();
        eBg.setShape(GradientDrawable.OVAL);
        eBg.setColor(Color.parseColor("#1F1635"));
        emojiBubble.setBackground(eBg);
        LinearLayout.LayoutParams eLp = new LinearLayout.LayoutParams(eSize, eSize);
        eLp.rightMargin = dp(ctx, 12);
        topRow.addView(emojiBubble, eLp);

       
        LinearLayout labelCol = new LinearLayout(ctx);
        labelCol.setOrientation(LinearLayout.VERTICAL);

        TextView labelTv = new TextView(ctx);
        labelTv.setText(label);
        labelTv.setTextSize(14.5f);
        labelTv.setTextColor(Color.parseColor("#F5F0FF"));
        labelTv.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        labelCol.addView(labelTv);

        TextView descTv = new TextView(ctx);
        descTv.setText(desc);
        descTv.setTextSize(11.5f);
        descTv.setTextColor(Color.parseColor("#5E5480"));
        LinearLayout.LayoutParams descLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        descLp.topMargin = dp(ctx, 2);
        labelCol.addView(descTv, descLp);

        topRow.addView(labelCol, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

       
        FrameLayout switchWrap = new FrameLayout(ctx);
        int trackW = dp(ctx, 50), trackH = dp(ctx, 28);
        switchWrap.setLayoutParams(new LinearLayout.LayoutParams(trackW, trackH));

        View track = new View(ctx);
        GradientDrawable trackBg = new GradientDrawable();
        trackBg.setShape(GradientDrawable.RECTANGLE);
        trackBg.setCornerRadius(dp(ctx, 14));
        trackBg.setColor(initialState ? Color.parseColor("#7B5EA7") : Color.parseColor("#2A2A3A"));
        track.setBackground(trackBg);
        switchWrap.addView(track, new FrameLayout.LayoutParams(trackW, trackH));

        View thumb = new View(ctx);
        int thumbSize = dp(ctx, 22);
        GradientDrawable thumbBg = new GradientDrawable();
        thumbBg.setShape(GradientDrawable.OVAL);
        thumbBg.setColor(Color.WHITE);
        thumb.setBackground(thumbBg);
        FrameLayout.LayoutParams thumbLp = new FrameLayout.LayoutParams(thumbSize, thumbSize);
        thumbLp.gravity = Gravity.CENTER_VERTICAL;
        thumbLp.leftMargin = initialState ? (trackW - thumbSize - dp(ctx, 3)) : dp(ctx, 3);
        thumb.setLayoutParams(thumbLp);
        switchWrap.addView(thumb);

        topRow.addView(switchWrap);
        row.addView(topRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        parent.addView(row, rowLp);

        
        final boolean[] state = {initialState};
        switchWrap.setOnClickListener(v -> {
            state[0] = !state[0];

           
            int toLeft = state[0] ? (trackW - thumbSize - dp(ctx, 3)) : dp(ctx, 3);
            ObjectAnimator anim = ObjectAnimator.ofInt(thumb, "left",
                    ((FrameLayout.LayoutParams) thumb.getLayoutParams()).leftMargin, toLeft);
            anim.setDuration(200);
            anim.setInterpolator(new DecelerateInterpolator());
            anim.addUpdateListener(a -> {
                FrameLayout.LayoutParams lp2 = (FrameLayout.LayoutParams) thumb.getLayoutParams();
                lp2.leftMargin = (int) a.getAnimatedValue();
                thumb.setLayoutParams(lp2);
            });
            anim.start();

            
            int fromColor = state[0] ? Color.parseColor("#2A2A3A") : Color.parseColor("#7B5EA7");
            int toColor   = state[0] ? Color.parseColor("#7B5EA7") : Color.parseColor("#2A2A3A");
            ValueAnimator colorAnim = ValueAnimator.ofArgb(fromColor, toColor);
            colorAnim.setDuration(200);
            colorAnim.addUpdateListener(a -> {
                trackBg.setColor((int) a.getAnimatedValue());
                track.setBackground(trackBg);
            });
            colorAnim.start();

            listener.onCheckedChanged(null, state[0]);
        });

        return row;
    }


    private static boolean isIgnoringBatteryOptimizations(Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
        return pm != null && pm.isIgnoringBatteryOptimizations(ctx.getPackageName());
    }

    private static void openBatterySettings(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                Intent intent = new Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + activity.getPackageName()));
                activity.startActivity(intent);
            } catch (Exception e) {
                Intent fallback = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.fromParts("package", activity.getPackageName(), null));
                activity.startActivity(fallback);
            }
        }
    }

    private static int dp(Context ctx, int value) {
        return (int) (value * ctx.getResources().getDisplayMetrics().density);
    }
}
