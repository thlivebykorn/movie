package com.example.animeapp.model;


public class Strings {
    
   
    private String home;
    private String nameAnimemoji;
    private String nameFixmono;
    private String nameGoseries4k;
    private String nameWowdrama;
    private String nameHdd1112;
    private String nameSeriesday;
    private String nameMovie123;
    private String nameMovie24hd;
    private String nameDoonang;
    private String nameWatchlakorn;
    private String nameHdmedia;
    
    private String getapi;
    private String playApi;
    private String playAnimemoji;
    private String getplayStreamApi;
   
    private String homeAnimemoji;
    private String homeFixmono;
    private String homeGoseries4k;
    private String homeWowdrama;
    private String homeHdd1112;
    private String homeSeriesday;
    private String homeMovie123;
    private String homeMovie24hd;
    private String homeDoonang;
    private String homeWatchlakorn;
    private String homeHdmedia;
    
    public Strings() {
    }
    
    public String getHome() {
        return home;
    }
    
    public void setHome(String home) {
        this.home = home;
    }
    
    public String getNameAnimemoji() {
        return nameAnimemoji;
    }
    
    public void setNameAnimemoji(String nameAnimemoji) {
        this.nameAnimemoji = nameAnimemoji;
    }
    
    public String getNameFixmono() {
        return nameFixmono;
    }
    
    public void setNameFixmono(String nameFixmono) {
        this.nameFixmono = nameFixmono;
    }
    
    public String getNameGoseries4k() {
        return nameGoseries4k;
    }
    
    public void setNameGoseries4k(String nameGoseries4k) {
        this.nameGoseries4k = nameGoseries4k;
    }
    
    public String getNameWowdrama() {
        return nameWowdrama;
    }
    
    public void setNameWowdrama(String nameWowdrama) {
        this.nameWowdrama = nameWowdrama;
    }
    
    public String getNameHdd1112() {
        return nameHdd1112;
    }
    
    public void setNameHdd1112(String nameHdd1112) {
        this.nameHdd1112 = nameHdd1112;
    }
    
    public String getNameSeriesday() {
        return nameSeriesday;
    }
    
    public void setNameSeriesday(String nameSeriesday) {
        this.nameSeriesday = nameSeriesday;
    }
    
    public String getNameMovie123() {
        return nameMovie123;
    }
    
    public void setNameMovie123(String nameMovie123) {
        this.nameMovie123 = nameMovie123;
    }
    
    public String getNameMovie24hd() {
        return nameMovie24hd;
    }
    
    public void setNameMovie24hd(String nameMovie24hd) {
        this.nameMovie24hd = nameMovie24hd;
    }

    public String getNameDoonang() {
        return nameDoonang;
    }

    public void setNameDoonang(String nameDoonang) {
        this.nameDoonang = nameDoonang;
    }

    public String getNameWatchlakorn() {
        return nameWatchlakorn;
    }

    public void setNameWatchlakorn(String nameWatchlakorn) {
        this.nameWatchlakorn = nameWatchlakorn;
    }

    public String getNameHdmedia() {
        return nameHdmedia;
    }

    public void setNameHdmedia(String nameHdmedia) {
        this.nameHdmedia = nameHdmedia;
    }
    
  
    public String getPlayApi() {
        return playApi;
    }
    
    public void setPlayApi(String playApi) {
        this.playApi = playApi;
    }
    
    public String getPlayAnimemoji() {
        return playAnimemoji;
    }
    
    public void setPlayAnimemoji(String playAnimemoji) {
        this.playAnimemoji = playAnimemoji;
    }
    
    public String getApi() {
        return getapi;
    }
    
    public void setApi(String getapi) {
        this.getapi = getapi;
    }

    public String getGetplayStreamApi() {
        return getplayStreamApi;
    }

    public void setGetplayStreamApi(String getplayStreamApi) {
        this.getplayStreamApi = getplayStreamApi;
    }
    
    public String getHomeAnimemoji() {
        return homeAnimemoji;
    }
    
    public void setHomeAnimemoji(String homeAnimemoji) {
        this.homeAnimemoji = homeAnimemoji;
    }
    
    public String getHomeFixmono() {
        return homeFixmono;
    }
    
    public void setHomeFixmono(String homeFixmono) {
        this.homeFixmono = homeFixmono;
    }
    
    public String getHomeGoseries4k() {
        return homeGoseries4k;
    }
    
    public void setHomeGoseries4k(String homeGoseries4k) {
        this.homeGoseries4k = homeGoseries4k;
    }
    
    public String getHomeWowdrama() {
        return homeWowdrama;
    }
    
    public void setHomeWowdrama(String homeWowdrama) {
        this.homeWowdrama = homeWowdrama;
    }
    
    public String getHomeHdd1112() {
        return homeHdd1112;
    }
    
    public void setHomeHdd1112(String homeHdd1112) {
        this.homeHdd1112 = homeHdd1112;
    }
    
    public String getHomeSeriesday() {
        return homeSeriesday;
    }
    
    public void setHomeSeriesday(String homeSeriesday) {
        this.homeSeriesday = homeSeriesday;
    }
    
    public String getHomeMovie123() {
        return homeMovie123;
    }
    
    public void setHomeMovie123(String homeMovie123) {
        this.homeMovie123 = homeMovie123;
    }
    
    public String getHomeMovie24hd() {
        return homeMovie24hd;
    }
    
    public void setHomeMovie24hd(String homeMovie24hd) {
        this.homeMovie24hd = homeMovie24hd;
    }

    public String getHomeDoonang() {
        return homeDoonang;
    }

    public void setHomeDoonang(String homeDoonang) {
        this.homeDoonang = homeDoonang;
    }

    public String getHomeWatchlakorn() {
        return homeWatchlakorn;
    }

    public void setHomeWatchlakorn(String homeWatchlakorn) {
        this.homeWatchlakorn = homeWatchlakorn;
    }

    public String getHomeHdmedia() {
        return homeHdmedia;
    }

    public void setHomeHdmedia(String homeHdmedia) {
        this.homeHdmedia = homeHdmedia;
    }
}
