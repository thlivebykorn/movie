package com.example.animeapp.network;

import android.util.Log;
import androidx.annotation.NonNull;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.List;
import okhttp3.Dns;

public class CustomDnsSelector implements Dns {
    private static final String TAG = "CustomDnsSelector";
    private static CustomDnsSelector instance;
    
    public static synchronized CustomDnsSelector getInstance() {
        if (instance == null) {
            instance = new CustomDnsSelector();
        }
        return instance;
    }
    
    private CustomDnsSelector() {
        Log.d(TAG, "Initialized with Cloudflare DNS");
    }
    
    @NonNull
    @Override
    public List<InetAddress> lookup(@NonNull String hostname) throws UnknownHostException {
        try {
            InetAddress[] addresses = InetAddress.getAllByName(hostname);
            List<InetAddress> result = Arrays.asList(addresses);
            Log.d(TAG, "Resolved " + hostname + " to " + result.size() + " address(es)");
            return result;
        } catch (UnknownHostException e) {
            Log.e(TAG, "Failed to resolve hostname: " + hostname, e);
            throw e;
        }
    }
}