package com.example.animeapp.network;

import android.util.Log;
import androidx.annotation.NonNull;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;
import okhttp3.Dns;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.dnsoverhttps.DnsOverHttps;

public class CloudflareDnsProvider {
    private static final String TAG = "CloudflareDnsProvider";
    private static CloudflareDnsProvider instance;
    private DnsOverHttps dnsOverHttps;
    
    public static synchronized CloudflareDnsProvider getInstance() {
        if (instance == null) {
            instance = new CloudflareDnsProvider();
        }
        return instance;
    }
    
    private CloudflareDnsProvider() {
        OkHttpClient bootstrapClient = new OkHttpClient.Builder().build();
        
        try {
            dnsOverHttps = new DnsOverHttps.Builder()
                    .client(bootstrapClient)
                    .url(HttpUrl.get("https://cloudflare-dns.com/dns-query"))
                    .bootstrapDnsHosts(
                            InetAddress.getByName("1.1.1.1"),
                            InetAddress.getByName("1.0.0.1")
                    )
                    .build();
            
            Log.d(TAG, "Cloudflare DNS over HTTPS initialized");
            
        } catch (UnknownHostException e) {
            Log.e(TAG, "Failed to initialize DoH", e);
        }
    }
    
    public Dns getDns() {
        return new Dns() {
            @NonNull
            @Override
            public List<InetAddress> lookup(@NonNull String hostname) throws UnknownHostException {
                if (dnsOverHttps != null) {
                    try {
                        List<InetAddress> addresses = dnsOverHttps.lookup(hostname);
                        Log.d(TAG, "DoH resolved " + hostname + " to " + addresses.size() + " addresses");
                        return addresses;
                    } catch (UnknownHostException e) {
                        Log.e(TAG, "DoH lookup failed for " + hostname, e);
                        throw e;
                    }
                }
                return Dns.SYSTEM.lookup(hostname);
            }
        };
    }
}