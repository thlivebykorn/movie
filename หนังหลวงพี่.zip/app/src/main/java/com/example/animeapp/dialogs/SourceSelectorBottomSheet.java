package com.example.animeapp.dialogs;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.animeapp.R;
import com.example.animeapp.model.Source;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.List;

public class SourceSelectorBottomSheet extends BottomSheetDialogFragment {

    public interface OnSourceSelectedListener {
        void onSourceSelected(Source source);
    }

    private OnSourceSelectedListener listener;
    private List<Source> sources;
    private Source currentSource;

    public static SourceSelectorBottomSheet newInstance(List<Source> sources, Source currentSource) {
        SourceSelectorBottomSheet fragment = new SourceSelectorBottomSheet();
        fragment.sources = sources;
        fragment.currentSource = currentSource;
        return fragment;
    }

    public void setOnSourceSelectedListener(OnSourceSelectedListener listener) {
        this.listener = listener;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.bottom_sheet_sources, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        RecyclerView recyclerView = view.findViewById(R.id.sources_recycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(new SourceAdapter(sources, currentSource, source -> {
            if (listener != null) {
                listener.onSourceSelected(source);
            }
            dismiss();
        }));
    }

    private static class SourceAdapter extends RecyclerView.Adapter<SourceAdapter.SourceViewHolder> {

        private final List<Source> sources;
        private final Source currentSource;
        private final OnSourceClickListener listener;

        public interface OnSourceClickListener {
            void onSourceClick(Source source);
        }

        public SourceAdapter(List<Source> sources, Source currentSource, OnSourceClickListener listener) {
            this.sources = sources;
            this.currentSource = currentSource;
            this.listener = listener;
        }

        @NonNull
        @Override
        public SourceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_source_bottom_sheet, parent, false);
            return new SourceViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull SourceViewHolder holder, int position) {
            Source source = sources.get(position);
            holder.bind(source, source.equals(currentSource), listener);
        }

        @Override
        public int getItemCount() {
            return sources.size();
        }

        static class SourceViewHolder extends RecyclerView.ViewHolder {

            private final ImageView iconView;
            private final TextView nameView;
            private final TextView statusView;
            private final TextView checkView;

            public SourceViewHolder(@NonNull View itemView) {
                super(itemView);
                iconView = itemView.findViewById(R.id.source_icon);
                nameView = itemView.findViewById(R.id.source_name);
                statusView = itemView.findViewById(R.id.source_status);
                checkView = itemView.findViewById(R.id.source_check);
            }

            public void bind(Source source, boolean isSelected, OnSourceClickListener listener) {
                nameView.setText(source.getName());
                statusView.setText("พร้อมใช้งาน");

               
                setSourceIcon(source.getName());

                checkView.setVisibility(isSelected ? View.VISIBLE : View.GONE);

                itemView.setOnClickListener(v -> {
                    if (listener != null) {
                        listener.onSourceClick(source);
                    }
                });
            }

            private void setSourceIcon(String sourceName) {
               
                iconView.setImageResource(R.drawable.ic_movie); // Default movie icon
            }
        }
    }
}
