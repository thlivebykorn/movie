package com.example.animeapp.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Looper;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;

import androidx.core.graphics.Insets;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.example.animeapp.database.DatabaseHelper;
import com.example.animeapp.dialogs.CustomLoadingDialog;
import com.example.animeapp.domain.DomainConfig;
import com.example.animeapp.workers.FavoriteCheckWorker;
import com.example.animeapp.utils.NotificationPermissionHelper;
import androidx.activity.result.ActivityResultLauncher;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import java.util.concurrent.TimeUnit;
import com.example.animeapp.security.AppSecurityManager;
import com.example.animeapp.fragments.AnimeListFragment;
import com.example.animeapp.models.PageItem;

import com.example.animeapp.ui.DynamicMenuBuilder;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.animeapp.R;
import com.example.animeapp.models.AnimeItem;

import com.example.animeapp.sources.AnimeSource;
import com.example.animeapp.sources.AnimemojiSource;
import com.example.animeapp.sources.FixmonoSource;
import com.example.animeapp.sources.GoSeriesSource;
import com.example.animeapp.sources.Hdd1112Source;
import com.example.animeapp.sources.Hdd123Source;
import com.example.animeapp.sources.Hd24Source;
import com.example.animeapp.sources.SeriesDaySource;
import com.example.animeapp.sources.WatchLakornSource;
import com.example.animeapp.sources.HdMediaSource;
import com.example.animeapp.sources.WowDramaSource;
import com.example.animeapp.startup.StartupDataCache;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayout;
import com.example.animeapp.model.Category;
import com.example.animeapp.model.Source;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import android.widget.FrameLayout;
import android.widget.LinearLayout;
import androidx.appcompat.app.AlertDialog;
import androidx.mediarouter.app.MediaRouteButton;
import com.example.animeapp.cast.CastManager;
import com.example.animeapp.managers.DeviceManager;
import com.example.animeapp.auth.SessionManager;
import com.example.animeapp.network.ServerApiClient;

import org.json.JSONObject;
import com.google.android.gms.cast.framework.CastButtonFactory;
import com.google.android.gms.cast.framework.CastContext;
import com.example.animeapp.dialogs.SourceSelectorBottomSheet;

public class MainActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private DrawerLayout drawerLayout;
  
    private AnimeListFragment animeListFragment;

    private TabLayout categoryTabs;

   
    private int currentPage = 1;
    private int maxPage     = 1;
    private List<PageItem> allPageItems = new ArrayList<>();
    private final Map<String, AnimeSource> animeSources = new HashMap<>();
    private AnimeSource currentSource;
    private Source currentDataSource;
    private boolean suppressTabSelectionLoad = false;
    
    private CustomLoadingDialog loadingDialog;
    private SharedPreferences prefs;
    private DynamicMenuBuilder menuBuilder;
    private CastManager castManager;
    private DeviceManager deviceManager;
    private AlertDialog domainLoadErrorDialog;
    private View mainContent;
    private View startupLoadingOverlay;
    private boolean startupLoadingVisible = true;
    
    private MenuItem currentSelectedMenuItem = null;
    private static final String PREF_NAME = "AnimeAppPrefs";
    private static final String KEY_DEFAULT_SOURCE = "default_source_id";
    
    private static final int DOMAIN_LOAD_TIMEOUT = 10000;

    private ActivityResultLauncher<String> notifPermLauncher;
    
    private DatabaseHelper  dbHelper;
    private ExecutorService executorService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

       
        NotificationPermissionHelper.createChannels(this);
       
        notifPermLauncher = NotificationPermissionHelper.registerLauncher(this,
            new NotificationPermissionHelper.PermissionCallback() {
                @Override public void onGranted() {
                    android.util.Log.d("MainActivity", "Notification permission granted");
                }
                @Override public void onDenied() {
                    android.util.Log.w("MainActivity", "Notification permission denied");
                }
            });

       
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        
        setContentView(R.layout.activity_main);

        com.example.animeapp.network.AnimeApiClient.init(this);
        setupStartupLoadingOverlay();

        if (!AppSecurityManager.isSignatureValid(this)) {
            new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("แอปมีการดัดแปลง")
                .setMessage("ไม่สามารถใช้งานแอปได้ กรุณาดาวน์โหลดจากต้นฉบับ")
                .setCancelable(false)
                .setPositiveButton("ปิด", (d, w) -> finishAffinity())
                .show();
            return;
        }

        prefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        castManager = new CastManager(this);
        loadingDialog = new CustomLoadingDialog(this);
        loadingDialog.setMessage("กำลังโหลดข้อมูล...");
        
       
        executorService = Executors.newFixedThreadPool(2);
        
        deviceManager = DeviceManager.getInstance(this);

        setupWindowInsets();
        continueInitialization();

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            if (!drawerLayout.isDrawerOpen(GravityCompat.START)) {
                drawerLayout.openDrawer(GravityCompat.START);
            } else {
                drawerLayout.closeDrawer(GravityCompat.START);
            }
            return true;
        }

        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        }

        return super.onKeyDown(keyCode, event);
    }

    private void setupWindowInsets() {
        View mainContent = findViewById(R.id.drawer_layout);
        ViewCompat.setOnApplyWindowInsetsListener(mainContent, (v, windowInsets) -> {
            Insets insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());

            Toolbar toolbar = findViewById(R.id.toolbar);
            if (toolbar != null) {
                toolbar.setPadding(
                    toolbar.getPaddingLeft(),
                    insets.top,
                    toolbar.getPaddingRight(),
                    0
                );
                int actionBarHeight = (int)(56 * getResources().getDisplayMetrics().density);
                ViewGroup.LayoutParams lp = toolbar.getLayoutParams();
                lp.height = insets.top + actionBarHeight;
                toolbar.setLayoutParams(lp);
            }

            NavigationView navView = findViewById(R.id.nav_view);
            if (navView != null) {
                navView.setPadding(0, insets.top, 0, insets.bottom);
            }


           
            return windowInsets;
        });
    }

    private void showDomainLoadError(String error) {
        if (domainLoadErrorDialog != null && domainLoadErrorDialog.isShowing()) return;

        String title = "ไม่สามารถโหลดข้อมูลได้";
        String message = error != null && !error.isEmpty()
                ? error
                : "ไม่สามารถเชื่อมต่อกับเซิร์ฟเวอร์ กรุณาตรวจสอบอินเทอร์เน็ต";
        if ("MAINTENANCE".equals(DomainConfig.getLastErrorCode())) {
            title = "แจ้งเตือน";
        }

        domainLoadErrorDialog = new AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("ลองใหม่", (dialog, which) -> {
                domainLoadErrorDialog = null;
                loadingDialog.setMessage("กำลังโหลดข้อมูล...");
                loadingDialog.show();
                loadDomainsThenData();
            })
            .setNegativeButton("ออก", (dialog, which) -> {
                domainLoadErrorDialog = null;
                finish();
            })
            .setOnDismissListener(dialog -> domainLoadErrorDialog = null)
            .setCancelable(false)
            .show();
    }

    private void dismissDomainLoadError() {
        if (domainLoadErrorDialog != null && domainLoadErrorDialog.isShowing()) {
            domainLoadErrorDialog.dismiss();
        }
        domainLoadErrorDialog = null;
    }

    private void continueInitialization() {
        menuBuilder = new DynamicMenuBuilder(this);

        setupToolbar();
        setupTabs();
        setupAnimeListFragment();
        setupNavigationDrawer();

        loadDomainsThenData();
        scheduleFavoriteCheck();

        NotificationPermissionHelper.checkAndRequest(MainActivity.this, notifPermLauncher);
    }

    private void setupStartupLoadingOverlay() {
        mainContent = findViewById(R.id.main_content);
        startupLoadingOverlay = findViewById(R.id.startup_loading_overlay);

        if (mainContent != null) mainContent.setVisibility(View.INVISIBLE);
        if (startupLoadingOverlay != null) startupLoadingOverlay.setVisibility(View.VISIBLE);
    }

    private void hideStartupLoadingOverlay() {
        if (!startupLoadingVisible) return;
        startupLoadingVisible = false;

        if (mainContent != null) mainContent.setVisibility(View.VISIBLE);
        if (startupLoadingOverlay != null) {
            startupLoadingOverlay.animate()
                .alpha(0f)
                .setDuration(180)
                .withEndAction(() -> startupLoadingOverlay.setVisibility(View.GONE))
                .start();
        }
    }

    private void loadDomainsThenData() {
        DomainConfig.setErrorListener(new DomainConfig.OnLoadErrorListener() {
            @Override
            public void onLoadFailed(String error) {
                runOnUiThread(() -> {
                    hideStartupLoadingOverlay();
                    if (loadingDialog != null && loadingDialog.isShowing()) loadingDialog.dismiss();
                    showDomainLoadError(error);
                });
            }
        });

        if (DomainConfig.isReady()) {
            runDomainMigrationIfNeeded();
            initializeAnimeSources();
            NavigationView navView = findViewById(R.id.nav_view);
            buildDynamicMenu(navView);
            if (!applyStartupDataIfAvailable()) {
                loadInitialData();
            }
            return;
        }

        DomainConfig.reset();
        DomainConfig.initialize(this);

        final long startTime = System.currentTimeMillis();
        final android.os.Handler handler = new android.os.Handler(Looper.getMainLooper());

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (DomainConfig.isReady()) {
                    runDomainMigrationIfNeeded();
                    initializeAnimeSources();
                    NavigationView navView = findViewById(R.id.nav_view);
                    buildDynamicMenu(navView);
                    if (!applyStartupDataIfAvailable()) {
                        loadInitialData();
                    }
                } else if (System.currentTimeMillis() - startTime < DOMAIN_LOAD_TIMEOUT) {
                    handler.postDelayed(this, 200);
                }
            }
        }, 200);
    }

    private void setupTabs() {
        categoryTabs = findViewById(R.id.category_tabs);
        categoryTabs.setFocusable(true);
        categoryTabs.setFocusableInTouchMode(false);

        categoryTabs.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() != KeyEvent.ACTION_DOWN) return false;
            if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) {
                int pos = categoryTabs.getSelectedTabPosition();
                if (pos <= 0) {
                    if (!drawerLayout.isDrawerOpen(GravityCompat.START)) {
                        drawerLayout.openDrawer(GravityCompat.START);
                    }
                    return true;
                }
                TabLayout.Tab tab = categoryTabs.getTabAt(pos - 1);
                if (tab != null) tab.select();
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                int pos = categoryTabs.getSelectedTabPosition();
                int next = pos + 1;
                if (next < categoryTabs.getTabCount()) {
                    TabLayout.Tab tab = categoryTabs.getTabAt(next);
                    if (tab != null) tab.select();
                    return true;
                }
            }
            return false;
        });

        categoryTabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (suppressTabSelectionLoad) return;
                if (currentDataSource != null) {
                    Category category = (Category) tab.getTag();
                    if (category != null) {
                        String url = currentDataSource.getFullUrl(category.getId());
                        String title = currentDataSource.getCategoryTitle(category.getId());
                        toolbar.setTitle(title);
                        currentPage = 1;        
                        allPageItems.clear();
                        loadPage(url);
                    }
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
               
                if (animeListFragment != null) {
                    animeListFragment.focusGrid();
                }
            }
        });
    }

    private void updateTabs(Source source) {
        categoryTabs.removeAllTabs();
        List<Category> categories = source.getCategories();
        if (categories != null) {
            for (Category category : categories) {
                TabLayout.Tab tab = categoryTabs.newTab();
                tab.setText(category.getTitle());
                tab.setTag(category);
                categoryTabs.addTab(tab);
            }
        }
        categoryTabs.post(this::setupCategoryTabFocus);
    }

    private void setupCategoryTabFocus() {
        if (categoryTabs == null || categoryTabs.getChildCount() == 0) return;

        ViewGroup tabStrip = (ViewGroup) categoryTabs.getChildAt(0);
        for (int i = 0; i < tabStrip.getChildCount(); i++) {
            View tabView = tabStrip.getChildAt(i);
            tabView.setFocusable(true);
            tabView.setFocusableInTouchMode(false);
            tabView.setClickable(true);
            tabView.setBackgroundResource(R.drawable.tab_item_background);
        }
    }

    private boolean applyStartupDataIfAvailable() {
        StartupDataCache.CachedData cachedData = StartupDataCache.peek();
        if (cachedData == null || cachedData.animeItems == null || cachedData.animeItems.isEmpty()) {
            return false;
        }

        Source source = DomainConfig.getSourceById(cachedData.sourceId);
        if (source == null) return false;

        currentDataSource = source;
        currentSource = getAnimeSource(source);
        currentPage = cachedData.pageNum > 0 ? cachedData.pageNum : 1;
        allPageItems.clear();

        suppressTabSelectionLoad = true;
        updateTabs(source);
        selectCachedCategoryTab(cachedData.categoryId);
        suppressTabSelectionLoad = false;

        if (toolbar != null && cachedData.categoryId != null) {
            toolbar.setTitle(source.getCategoryTitle(cachedData.categoryId));
        }

        updateAnimeList(new ArrayList<>(cachedData.animeItems));
        updatePageList(new ArrayList<>(cachedData.pageItems));
        hideStartupLoadingOverlay();
        StartupDataCache.clear();
        return true;
    }

    private void selectCachedCategoryTab(String categoryId) {
        if (categoryTabs == null || categoryTabs.getTabCount() == 0) return;

        for (int i = 0; i < categoryTabs.getTabCount(); i++) {
            TabLayout.Tab tab = categoryTabs.getTabAt(i);
            if (tab == null) continue;
            Object tag = tab.getTag();
            if (tag instanceof Category) {
                Category category = (Category) tag;
                if (category.getId().equals(categoryId)) {
                    tab.select();
                    return;
                }
            }
        }

        TabLayout.Tab firstTab = categoryTabs.getTabAt(0);
        if (firstTab != null) firstTab.select();
    }

    private void setupNavigationMenu(NavigationView navView) {
        navView.setNavigationItemSelectedListener(menuItem -> {
            drawerLayout.closeDrawers();
            
            if (currentSelectedMenuItem != null) {
                currentSelectedMenuItem.setChecked(false);
            }
            
            handleNavigationItemSelected(menuItem);
            return true;
        });
    }
    
    private void handleNavigationItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        
        if (itemId == R.id.action_history) {
            android.content.Intent intent = new android.content.Intent(this, HistoryActivity.class);
            startActivity(intent);
            return;
        }

        if (itemId == R.id.action_settings) {
            com.example.animeapp.activities.SettingsActivity.start(this);
            return;
        }

        Source source = menuBuilder.getSource(itemId);
        if (source != null) {
            item.setCheckable(true);
            item.setChecked(true);
            currentSelectedMenuItem = item;
            
            currentDataSource = source;
            updateTabs(source);
            if (categoryTabs.getTabCount() > 0) {
                categoryTabs.getTabAt(0).select();
            }
        }
    }

    private void showDefaultSourceDialog() {
        List<Source> sources = DomainConfig.getSources();
        if (sources == null || sources.isEmpty()) return;

        String currentDefaultId = prefs.getString(KEY_DEFAULT_SOURCE, sources.get(0).getId());
        int[] selectedIndex = {0};
        for (int i = 0; i < sources.size(); i++) {
            if (sources.get(i).getId().equals(currentDefaultId)) {
                selectedIndex[0] = i;
                break;
            }
        }

       
        android.widget.ScrollView scrollView = new android.widget.ScrollView(this);
        scrollView.setVerticalScrollBarEnabled(false);
        int screenH = getResources().getDisplayMetrics().heightPixels;
        scrollView.setLayoutParams(new android.widget.FrameLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT, (int)(screenH * 0.82f)));

        android.widget.LinearLayout card = new android.widget.LinearLayout(this);
        card.setOrientation(android.widget.LinearLayout.VERTICAL);
        card.setPadding(dp(24), dp(28), dp(24), dp(20));
        android.graphics.drawable.GradientDrawable cardBg = new android.graphics.drawable.GradientDrawable();
        cardBg.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
        cardBg.setCornerRadius(dp(24));
        cardBg.setColor(android.graphics.Color.parseColor("#0E0E1A"));
        cardBg.setStroke(dp(1), android.graphics.Color.parseColor("#3D2B6B"));
        card.setBackground(cardBg);
        scrollView.addView(card, new android.widget.FrameLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT));

      
        android.widget.LinearLayout headerRow = new android.widget.LinearLayout(this);
        headerRow.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        headerRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        android.widget.LinearLayout.LayoutParams headerLp = new android.widget.LinearLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        headerLp.bottomMargin = dp(20);

        android.widget.TextView iconBubble = new android.widget.TextView(this);
        iconBubble.setText("Web");
        iconBubble.setTextSize(20);
        iconBubble.setGravity(android.view.Gravity.CENTER);
        int bSize = dp(44);
        android.graphics.drawable.GradientDrawable bBg = new android.graphics.drawable.GradientDrawable();
        bBg.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        bBg.setColors(new int[]{android.graphics.Color.parseColor("#2A1F4A"), android.graphics.Color.parseColor("#1A1A2E")});
        bBg.setStroke(dp(1), android.graphics.Color.parseColor("#7B5EA7"));
        iconBubble.setBackground(bBg);
        android.widget.LinearLayout.LayoutParams bLp = new android.widget.LinearLayout.LayoutParams(bSize, bSize);
        bLp.rightMargin = dp(14);
        headerRow.addView(iconBubble, bLp);

        android.widget.LinearLayout titleCol = new android.widget.LinearLayout(this);
        titleCol.setOrientation(android.widget.LinearLayout.VERTICAL);
        android.widget.TextView titleTv = new android.widget.TextView(this);
        titleTv.setText("เลือกเว็บหน้าแรก");
        titleTv.setTextSize(17);
        titleTv.setTextColor(android.graphics.Color.parseColor("#F5F0FF"));
        titleTv.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        android.widget.TextView subTv = new android.widget.TextView(this);
        subTv.setText("แหล่งข้อมูลที่แสดงตอนเปิดแอป");
        subTv.setTextSize(12);
        subTv.setTextColor(android.graphics.Color.parseColor("#5E5480"));
        android.widget.LinearLayout.LayoutParams subLp2 = new android.widget.LinearLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        subLp2.topMargin = dp(2);
        titleCol.addView(titleTv);
        titleCol.addView(subTv, subLp2);
        headerRow.addView(titleCol, new android.widget.LinearLayout.LayoutParams(0,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(headerRow, headerLp);

        
        android.view.View div = new android.view.View(this);
        div.setBackgroundColor(android.graphics.Color.parseColor("#1F1635"));
        android.widget.LinearLayout.LayoutParams divLp = new android.widget.LinearLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        divLp.bottomMargin = dp(16);
        card.addView(div, divLp);

        
        java.util.concurrent.atomic.AtomicReference<androidx.appcompat.app.AlertDialog> dialogRef = new java.util.concurrent.atomic.AtomicReference<>();
        android.widget.LinearLayout[] rows = new android.widget.LinearLayout[sources.size()];
        for (int i = 0; i < sources.size(); i++) {
            final int idx = i;
            Source src = sources.get(i);
            boolean isSelected = (i == selectedIndex[0]);

            android.widget.LinearLayout row = new android.widget.LinearLayout(this);
            row.setOrientation(android.widget.LinearLayout.HORIZONTAL);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(12), dp(12), dp(12));
            android.widget.LinearLayout.LayoutParams rowLp = new android.widget.LinearLayout.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
            rowLp.bottomMargin = dp(6);

            android.graphics.drawable.GradientDrawable rowBg = new android.graphics.drawable.GradientDrawable();
            rowBg.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
            rowBg.setCornerRadius(dp(14));
            rowBg.setColor(isSelected ? android.graphics.Color.parseColor("#1F1040") : android.graphics.Color.parseColor("#13131F"));
            rowBg.setStroke(dp(1), isSelected ? android.graphics.Color.parseColor("#9B6FD4") : android.graphics.Color.parseColor("#1F1635"));
            row.setBackground(rowBg);

           
            android.widget.TextView radioDot = new android.widget.TextView(this);
            radioDot.setText(isSelected ? "●" : "○");
            radioDot.setTextSize(16);
            radioDot.setTextColor(isSelected ? android.graphics.Color.parseColor("#C084FC") : android.graphics.Color.parseColor("#3D3060"));
            android.widget.LinearLayout.LayoutParams dotLp = new android.widget.LinearLayout.LayoutParams(
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
            dotLp.rightMargin = dp(14);
            row.addView(radioDot, dotLp);

           
            android.widget.TextView nameTv = new android.widget.TextView(this);
            nameTv.setText(src.getName());
            nameTv.setTextSize(14.5f);
            nameTv.setTextColor(isSelected ? android.graphics.Color.parseColor("#F5F0FF") : android.graphics.Color.parseColor("#A89BC8"));
            if (isSelected) nameTv.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            row.addView(nameTv, new android.widget.LinearLayout.LayoutParams(0,
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

           
            if (isSelected) {
                android.widget.TextView check = new android.widget.TextView(this);
                check.setText("✓");
                check.setTextSize(16);
                check.setTextColor(android.graphics.Color.parseColor("#C084FC"));
                row.addView(check);
            }

            rows[i] = row;
            card.addView(row, rowLp);

            row.setOnClickListener(v -> {
               
                for (int j = 0; j < sources.size(); j++) {
                    android.graphics.drawable.GradientDrawable bg2 = new android.graphics.drawable.GradientDrawable();
                    bg2.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
                    bg2.setCornerRadius(dp(14));
                    bg2.setColor(android.graphics.Color.parseColor("#13131F"));
                    bg2.setStroke(dp(1), android.graphics.Color.parseColor("#1F1635"));
                    rows[j].setBackground(bg2);
                    rows[j].removeAllViews();

                    android.widget.TextView rd = new android.widget.TextView(this);
                    rd.setText("○");
                    rd.setTextSize(16);
                    rd.setTextColor(android.graphics.Color.parseColor("#3D3060"));
                    android.widget.LinearLayout.LayoutParams rdLp = new android.widget.LinearLayout.LayoutParams(
                            android.view.ViewGroup.LayoutParams.WRAP_CONTENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
                    rdLp.rightMargin = dp(14);
                    rows[j].addView(rd, rdLp);

                    android.widget.TextView nt = new android.widget.TextView(this);
                    nt.setText(sources.get(j).getName());
                    nt.setTextSize(14.5f);
                    nt.setTextColor(android.graphics.Color.parseColor("#A89BC8"));
                    rows[j].addView(nt, new android.widget.LinearLayout.LayoutParams(0,
                            android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                }

               
                android.graphics.drawable.GradientDrawable selBg = new android.graphics.drawable.GradientDrawable();
                selBg.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
                selBg.setCornerRadius(dp(14));
                selBg.setColor(android.graphics.Color.parseColor("#1F1040"));
                selBg.setStroke(dp(1), android.graphics.Color.parseColor("#9B6FD4"));
                rows[idx].setBackground(selBg);
                rows[idx].removeAllViews();

                android.widget.TextView rd2 = new android.widget.TextView(this);
                rd2.setText("●");
                rd2.setTextSize(16);
                rd2.setTextColor(android.graphics.Color.parseColor("#C084FC"));
                android.widget.LinearLayout.LayoutParams rd2Lp = new android.widget.LinearLayout.LayoutParams(
                        android.view.ViewGroup.LayoutParams.WRAP_CONTENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
                rd2Lp.rightMargin = dp(14);
                rows[idx].addView(rd2, rd2Lp);

                android.widget.TextView nt2 = new android.widget.TextView(this);
                nt2.setText(sources.get(idx).getName());
                nt2.setTextSize(14.5f);
                nt2.setTextColor(android.graphics.Color.parseColor("#F5F0FF"));
                nt2.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                rows[idx].addView(nt2, new android.widget.LinearLayout.LayoutParams(0,
                        android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

                android.widget.TextView ck = new android.widget.TextView(this);
                ck.setText("✓");
                ck.setTextSize(16);
                ck.setTextColor(android.graphics.Color.parseColor("#C084FC"));
                rows[idx].addView(ck);

               
                Toast.makeText(this, sources.get(idx).getName() + " เป็นหน้าแรกแล้ว ✓", Toast.LENGTH_SHORT).show();
                if (dialogRef.get() != null) dialogRef.get().dismiss();
            });
        }

       
        androidx.appcompat.app.AlertDialog.Builder builder2 = new androidx.appcompat.app.AlertDialog.Builder(this, 0);
        builder2.setView(scrollView);
        builder2.setCancelable(true);
        androidx.appcompat.app.AlertDialog dialog = builder2.create();
        dialogRef.set(dialog);

        android.view.Window win = dialog.getWindow();
        if (win != null) {
            win.setBackgroundDrawableResource(android.R.color.transparent);
            win.setDimAmount(0.7f);
            android.view.WindowManager.LayoutParams lp = win.getAttributes();
            lp.width = (int)(getResources().getDisplayMetrics().widthPixels * 0.88f);
            win.setAttributes(lp);
        }

        dialog.show();

        scrollView.setAlpha(0f);
        scrollView.setScaleX(0.88f);
        scrollView.setScaleY(0.88f);
        scrollView.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(350)
                .setInterpolator(new android.view.animation.OvershootInterpolator(1.1f))
                .start();
    }

    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density);
    }

    private void runDomainMigrationIfNeeded() {
        DatabaseHelper db = new DatabaseHelper(this);
        boolean anyMigrated = false;
        SharedPreferences knownDomains = getSharedPreferences("KnownDomains", MODE_PRIVATE);
        SharedPreferences.Editor editor = knownDomains.edit();

        for (com.example.animeapp.model.Source src : DomainConfig.getSources()) {
            if (src.getDomain() == null || src.getDomain().isEmpty()) continue;
            String newDomain = src.getDomain().replaceFirst("^www\\.", "");
            String knownDomain = knownDomains.getString(src.getId(), null);


            if (knownDomain == null) {
                int n = db.migrateToNewDomain(src.getName(), newDomain);
                if (n > 0) {
                    android.util.Log.d("MainActivity",
                        "[" + src.getId() + "] first-run migrate " + n + " rows -> " + newDomain);
                    anyMigrated = true;
                }
                editor.putString(src.getId(), newDomain);
            } else if (!knownDomain.equals(newDomain)) {
                int count = db.migrateDomain(knownDomain, newDomain);
                android.util.Log.d("MainActivity",
                    "[" + src.getId() + "] domain changed: " + knownDomain + " -> " + newDomain
                    + " (migrated " + count + " rows)");
                editor.putString(src.getId(), newDomain);
                anyMigrated = true;
            }
        }
        editor.apply();
        if (anyMigrated) com.example.animeapp.network.AnimeApiClient.resetParsers();
    }

    private void scheduleFavoriteCheck() {
      
        PeriodicWorkRequest work = new PeriodicWorkRequest.Builder(
            FavoriteCheckWorker.class, 3, TimeUnit.HOURS, 30, TimeUnit.MINUTES)
            .build();
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "favorite_check",
            ExistingPeriodicWorkPolicy.UPDATE,
            work
        );

       
        androidx.work.OneTimeWorkRequest oneTime = new androidx.work.OneTimeWorkRequest.Builder(
            FavoriteCheckWorker.class).build();
        WorkManager.getInstance(this).enqueueUniqueWork(
            "favorite_check_once",
            androidx.work.ExistingWorkPolicy.REPLACE,
            oneTime
        );
        android.util.Log.d("MainActivity", "Favorite check scheduled every 3h + running now");
    }

    
    public void runFavoriteCheckNow() {
        androidx.work.OneTimeWorkRequest oneTime = new androidx.work.OneTimeWorkRequest.Builder(
            FavoriteCheckWorker.class).build();
        WorkManager.getInstance(this).enqueueUniqueWork(
            "favorite_check_manual",
            androidx.work.ExistingWorkPolicy.REPLACE,
            oneTime
        );
        android.widget.Toast.makeText(this, "กำลังเช็กรายการโปรด...", android.widget.Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (castManager != null) castManager.onResume();
        if (animeListFragment != null) animeListFragment.refreshGridColumns();
        startSessionWatchdog();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (castManager != null) castManager.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopSessionWatchdog();
        if (loadingDialog != null && loadingDialog.isShowing()) {
            loadingDialog.dismiss();
        }
        if (dbHelper != null) {
            dbHelper.close();
        }
        if (executorService != null && !executorService.isShutdown()) {
            executorService.shutdown();
        }
    }

    private final android.os.Handler sessionHandler = new android.os.Handler(Looper.getMainLooper());
    private boolean kickedRedirecting = false;
    private final Runnable sessionCheckRunnable = new Runnable() {
        @Override
        public void run() {
            checkSessionAndKick();
            sessionHandler.postDelayed(this, 60000L);
        }
    };

    private void startSessionWatchdog() {
        if (!SessionManager.hasSession(this)) return;
        sessionHandler.removeCallbacks(sessionCheckRunnable);
        sessionHandler.postDelayed(sessionCheckRunnable, 30000L);
    }

    private void stopSessionWatchdog() {
        sessionHandler.removeCallbacks(sessionCheckRunnable);
    }

    private void checkSessionAndKick() {
        if (!SessionManager.hasSession(this) || kickedRedirecting) return;
        new Thread(() -> {
            try {
                JSONObject res = ServerApiClient.checkSession(MainActivity.this);
                String status = res.optString("status", "approved");
                if ("pending".equals(status)) {
                    kickToLogin("บัญชีของคุณยังไม่ได้รับการอนุมัติจากแอดมิน");
                } else if ("banned".equals(status)) {
                    kickToLogin("บัญชีของคุณถูกระงับการใช้งาน");
                }
            } catch (ServerApiClient.ApiException e) {
                if ("KICKED".equals(e.code) || "BANNED".equals(e.code) || "AUTH_REQUIRED".equals(e.code)) {
                    kickToLogin(mapSessionMessage(e.code, e.getMessage()));
                }
            } catch (Exception ignored) {
                // ออฟไลน์ ข้ามไป
            }
        }).start();
    }

    private String mapSessionMessage(String code, String message) {
        if ("KICKED".equals(code)) return "บัญชีนี้ถูกใช้บนเครื่องอื่น";
        if ("BANNED".equals(code)) return "บัญชีของคุณถูกระงับการใช้งาน";
        if ("AUTH_REQUIRED".equals(code)) return "เซสชันหมดอายุ กรุณาเข้าสู่ระบบใหม่";
        return message != null ? message : "เซสชันหมดอายุ";
    }

    private void kickToLogin(String message) {
        if (kickedRedirecting) return;
        kickedRedirecting = true;
        runOnUiThread(() -> {
            stopSessionWatchdog();
            SessionManager.clear(MainActivity.this);
            ServerApiClient.logout(MainActivity.this);
            new AlertDialog.Builder(MainActivity.this)
                .setTitle("แจ้งเตือน")
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton("ตกลง", (d, w) -> {
                    Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finishAffinity();
                })
                .show();
        });
    }

    private void initializeAnimeSources() {
        animeSources.clear();

        registerAnimeSource("animemoji", DomainConfig.SourceName.ANIMEMOJI(), new AnimemojiSource(this));
        registerAnimeSource("fixmono", DomainConfig.SourceName.FIXMONO(), new FixmonoSource());
        registerAnimeSource("goseries4k", DomainConfig.SourceName.GOSERIES4K(), new GoSeriesSource());
        registerAnimeSource("wowdrama", DomainConfig.SourceName.WOWDRAMA(), new WowDramaSource());
        registerAnimeSource("seriesday", DomainConfig.SourceName.SERIESDAY(), new SeriesDaySource());
        registerAnimeSource("movie123", DomainConfig.SourceName.MOVIE123(), new Hdd123Source());
        registerAnimeSource("hdd123", DomainConfig.SourceName.MOVIE123(), new Hdd123Source());
        registerAnimeSource("movie24hd", DomainConfig.SourceName.MOVIE24HD(), new Hd24Source());
        registerAnimeSource("24hd", DomainConfig.SourceName.MOVIE24HD(), new Hd24Source());
        registerAnimeSource("hdd1112", DomainConfig.SourceName.HDD1112(), new Hdd1112Source());
        String wlName = DomainConfig.SourceName.WATCHLAKORN();
        registerAnimeSource("watchlakorn", wlName, new WatchLakornSource());
        if (wlName != null && !wlName.isEmpty()) {
            registerAnimeSource(wlName, wlName, new WatchLakornSource());
        }
        registerAnimeSource("hdmedia", DomainConfig.SourceName.HDMEDIA(), new HdMediaSource());
    }

    private void registerAnimeSource(String id, String displayName, AnimeSource source) {
        if (id != null && !id.trim().isEmpty()) {
            animeSources.put(id.trim().toLowerCase(), source);
        }
        if (displayName != null && !displayName.trim().isEmpty()) {
            animeSources.put(displayName.trim(), source);
        }
    }

    private AnimeSource getAnimeSource(Source source) {
        if (source == null) return null;

        String id = source.getId();
        if (id != null) {
            AnimeSource byId = animeSources.get(id.trim().toLowerCase());
            if (byId != null) return byId;
        }

        String name = source.getName();
        if (name != null) {
            AnimeSource byName = animeSources.get(name.trim());
            if (byName != null) return byName;
        }

        return null;
    }

    private void setupToolbar() {
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitleTextColor(Color.WHITE);
        setSupportActionBar(toolbar);
        toolbar.post(this::setupToolbarFocusTargets);

    }

    private void setupToolbarFocusTargets() {
        if (toolbar == null) return;

        for (int i = 0; i < toolbar.getChildCount(); i++) {
            View child = toolbar.getChildAt(i);
            if (child instanceof android.widget.ImageButton
                    || child instanceof androidx.appcompat.view.menu.ActionMenuItemView) {
                makeToolbarButtonTvFocusable(child);
            }
        }
    }

    private void makeToolbarButtonTvFocusable(View view) {
        view.setFocusable(true);
        view.setFocusableInTouchMode(false);
        view.setClickable(true);
        view.setBackgroundResource(R.drawable.focus_background);
        int pad = dp(8);
        view.setPadding(pad, pad, pad, pad);
    }

    private void setupAnimeListFragment() {
        animeListFragment = AnimeListFragment.newInstance();
        animeListFragment.setAnimeClickCallback(this::onAnimeClick);
        animeListFragment.setLoadPageCallback((url, pageNum) -> loadPage(url, pageNum));

        getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.anime_fragment_container, animeListFragment)
            .commitNow();
    }

    private void updateAnimeList(List<AnimeItem> newItems) {
        if (animeListFragment != null) animeListFragment.updateAnimeList(newItems);
    }

    private void updatePageList(List<PageItem> newPages) {
        
        allPageItems = newPages;
        int max = 1;
        for (PageItem item : newPages) {
            try {
                int num = Integer.parseInt(item.getPageNumber().trim());
                if (num > max) max = num;
                if (item.isCurrent()) currentPage = num;
            } catch (NumberFormatException ignored) {}
        }
        maxPage = Math.max(max, currentPage);

        if (animeListFragment != null)
            animeListFragment.updatePageList(newPages, currentPage);
    }


    private void setupNavigationDrawer() {
        drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navView = findViewById(R.id.nav_view);

        setupDrawerToggle();
        setupDrawerDeviceId(navView);
        setupNavigationMenu(navView);
    }

    private void setupDrawerDeviceId(NavigationView navView) {
        View headerView = navView.getHeaderView(0);
        TextView tvDeviceId    = headerView.findViewById(R.id.tv_device_id);
        LinearLayout idContainer = headerView.findViewById(R.id.device_id_container);

        String fullId  = deviceManager.getDeviceId();
        String shortId = deviceManager.getShortDeviceId();
        tvDeviceId.setText(shortId);

        idContainer.setOnClickListener(v -> {
            android.content.ClipboardManager cb =
                (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cb.setPrimaryClip(android.content.ClipData.newPlainText("Device ID", fullId));
            Toast.makeText(this, "คัดลอก Device ID แล้ว", Toast.LENGTH_SHORT).show();
        });
    }

    private void buildDynamicMenu(NavigationView navView) {
        Menu menu = navView.getMenu();
        navView.setItemIconTintList(null); 
        menu.clear();
        getMenuInflater().inflate(R.menu.drawer_menu, menu);
        menuBuilder.buildDynamicMenu(menu);

       
        MenuItem historyItem  = menu.findItem(R.id.action_history);
        MenuItem settingsItem = menu.findItem(R.id.action_settings);
        if (historyItem  != null && historyItem.getIcon()  != null)
            historyItem.getIcon().setTint(0xFFB88EF5);
        if (settingsItem != null && settingsItem.getIcon() != null)
            settingsItem.getIcon().setTint(0xFFB88EF5);
    }

    private void setupDrawerToggle() {
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this,
                drawerLayout,
                toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
    }


    private void loadInitialData() {
        List<Source> sources = DomainConfig.getSources();
        if (sources != null && !sources.isEmpty()) {
            String defaultSourceId = prefs.getString(KEY_DEFAULT_SOURCE, sources.get(0).getId());
            Source defaultSource = sources.get(0);
            for (Source s : sources) {
                if (s.getId().equals(defaultSourceId)) {
                    defaultSource = s;
                    break;
                }
            }
            
            currentDataSource = defaultSource;
            currentSource = getAnimeSource(defaultSource);
            updateTabs(defaultSource);
            if (categoryTabs.getTabCount() > 0) {
                categoryTabs.getTabAt(0).select();
            }
        }
    }

    private void loadPage(String pageUrl) {
        loadPage(pageUrl, currentPage);
    }

    private void loadPage(String pageUrl, int pageNum) {
        if (currentDataSource != null) {
            currentSource = getAnimeSource(currentDataSource);
        }
        if (currentSource == null) {
            Toast.makeText(this, "กรุณาเลือกแหล่งข้อมูล", Toast.LENGTH_SHORT).show();
            if (loadingDialog != null && loadingDialog.isShowing()) loadingDialog.dismiss();
            return;
        }

        if (loadingDialog != null && loadingDialog.isShowing()) loadingDialog.dismiss();
        if (animeListFragment != null) animeListFragment.showLoadingIndicator();

        currentSource.fetchAnimeList(pageUrl, new AnimeSource.AnimeLoadCallback() {
            @Override
            public void onSuccess(List<AnimeItem> animeItems, List<PageItem> pageItems) {
                runOnUiThread(() -> {
                    if (pageNum != currentPage) currentPage = pageNum;
                    updateAnimeList(animeItems);
                    updatePageList(pageItems);
                    hideStartupLoadingOverlay();
                    if (loadingDialog != null && loadingDialog.isShowing()) loadingDialog.dismiss();
                });
            }
            @Override
            public void onFailure(String errorMessage) {
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, errorMessage, Toast.LENGTH_SHORT).show();
                    if (animeListFragment != null) animeListFragment.updateAnimeList(new java.util.ArrayList<>());
                    hideStartupLoadingOverlay();
                    if (loadingDialog != null && loadingDialog.isShowing()) loadingDialog.dismiss();
                });
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);

        MenuItem searchItem = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) searchItem.getActionView();
        searchView.setQueryHint("ค้นหาอนิเมะ...");

        searchView.setFocusable(true);
        searchView.setFocusableInTouchMode(false);
        searchView.setIconifiedByDefault(true);
        toolbar.post(() -> {
            View searchActionView = findViewById(R.id.action_search);
            if (searchActionView != null) makeToolbarButtonTvFocusable(searchActionView);
            setupToolbarFocusTargets();
        });

        EditText searchEditText = searchView.findViewById(androidx.appcompat.R.id.search_src_text);
        searchEditText.setTextColor(Color.WHITE); 
        searchEditText.setHintTextColor(Color.LTGRAY); 

        ImageView searchIcon = searchView.findViewById(androidx.appcompat.R.id.search_mag_icon);
        searchIcon.setColorFilter(Color.WHITE);

        searchView.setOnQueryTextListener(
                new SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String query) {
                        performSearch(query);
                        return true;
                    }

                    @Override
                    public boolean onQueryTextChange(String newText) {
                        return false;
                    }
                });

        return true;
    }

    private void performSearch(String keyword) {
        if (currentSource == null) {
            Toast.makeText(this, "กรุณาเลือกแหล่งข้อมูล", Toast.LENGTH_SHORT).show();
            return;
        }
        
        String searchUrl = currentSource.getSearchUrl(keyword);
        loadPage(searchUrl);
    }

    private void onAnimeClick(AnimeItem animeItem) {
        AnimeDetailActivity.start(this, animeItem.getUrl(), animeItem.getTitle());
    }

    private void showSourceSelectorBottomSheet() {
        List<Source> sources = DomainConfig.getSources();
        if (sources == null || sources.isEmpty()) {
            Toast.makeText(this, "ไม่มีแหล่งข้อมูลให้เลือก", Toast.LENGTH_SHORT).show();
            return;
        }

        SourceSelectorBottomSheet bottomSheet = SourceSelectorBottomSheet.newInstance(sources, currentDataSource);
        bottomSheet.setOnSourceSelectedListener(source -> {
          
            if (currentSelectedMenuItem != null) {
                currentSelectedMenuItem.setChecked(false);
            }

            currentDataSource = source;
            currentSource = getAnimeSource(source);
            updateTabs(source);

            if (categoryTabs.getTabCount() > 0) {
                categoryTabs.getTabAt(0).select();
            }

            Toast.makeText(this, "เปลี่ยนเป็น " + source.getName() + " แล้ว", Toast.LENGTH_SHORT).show();
        });
        bottomSheet.show(getSupportFragmentManager(), "SourceSelectorBottomSheet");
    }
}
