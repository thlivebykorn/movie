package com.example.animeapp.parser;

import org.jsoup.nodes.Document;
import com.example.animeapp.models.Anime;
import java.util.List;
import com.example.animeapp.models.Episode;
import com.example.animeapp.network.OkHttpClientFactory;
import java.io.IOException;
import java.util.ArrayList;
import org.jsoup.select.Elements;
import org.jsoup.nodes.Element;
import org.jsoup.Jsoup;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import com.example.animeapp.domain.DomainConfig;

public class SeriesDayParser implements AnimeParser {
    
   
    private final OkHttpClient client;
    
    public SeriesDayParser() {
       
        this.client = OkHttpClientFactory.getClientWithDoH();
    }
    
    @Override
    public Anime parseAnimeDetail(Document doc) {
        return com.example.animeapp.parser.NativeParseBridge.parseAnimeDetail("seriesday", doc);
    }

    @Override
    public List<Episode> parseEpisodes(Document doc, String imageUrl) {
        return com.example.animeapp.parser.NativeParseBridge.parseEpisodes("seriesday", doc, imageUrl);
    }

    @Override
    public String parseVideoUrl(Document epDoc, String referer, int episodeNumber) throws IOException {
        Element langSelect = epDoc.selectFirst("select#Lang_select");
        Element defaultOption = langSelect.select("option[value=Thai]").first();
        if (defaultOption == null) {
            defaultOption = langSelect.select("option[value=Sound Track]").first();
        }
        
        String defaultLang = defaultOption.attr("value");
        Element lsub = epDoc.selectFirst("span.halim-btn.halim-btn-2.active.halim-info-2-1.box-shadow");
        
        String dataPostId = lsub.attr("data-post-id");
        String dataServer = lsub.attr("data-server");
        String dataType = lsub.attr("data-type");
        
        String postUrl = "https://" + DomainConfig.BaseUrl.SERIESDAY() + "/api/get.php";
        
        try {
            
            String videoUrl = fetchVideoUrl(postUrl, dataType, episodeNumber, dataPostId, 
                                           defaultLang, dataServer, referer);
            if (videoUrl != null && !videoUrl.isEmpty()) {
                return videoUrl;
            }
            
           
            videoUrl = fetchVideoUrl(postUrl, dataType, episodeNumber, dataPostId, 
                                    defaultLang, "3", referer);
            if (videoUrl != null && !videoUrl.isEmpty()) {
                return videoUrl;
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return "";
    }

    private String fetchVideoUrl(String postUrl, String dataType, int episodeNumber, 
                                 String dataPostId, String defaultLang, String server, 
                                 String referer) throws IOException {
        
        FormBody formBody = new FormBody.Builder()
            .add("action", "halim_ajax_player")
            .add("nonce", dataType)
            .add("episode", String.valueOf(episodeNumber))
            .add("postid", dataPostId)
            .add("lang", defaultLang)
            .add("server", server)
            .build();
        
        Request request = new Request.Builder()
            .url(postUrl)
            .post(formBody)
            .header("Content-Type", "application/x-www-form-urlencoded")
            .header("User-Agent", "Mozilla/5.0")
            .header("Referer", referer)
            .build();
        
        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                return null;
            }
            
            String html = response.body().string();
            Document doc = Jsoup.parse(html);
            
            Element iframe = doc.selectFirst("iframe");
            if (iframe != null) {
                String videoUrl = iframe.attr("src");
                return convertUrl(videoUrl);
            }
        }
        
        return null;
    }

    private String convertUrl(String inputUrl) {
        Pattern pattern = Pattern.compile("id=([^&]+)");
        Matcher matcher = pattern.matcher(inputUrl);
        
        if (matcher.find()) {
            String id = matcher.group(1);
            return String.format(DomainConfig.ApiUrl.PLAY_API() + "%s/%s.m3u8",  id, id);
        }
        
        return inputUrl;
    }
}