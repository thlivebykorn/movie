package com.example.animeapp.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.example.animeapp.models.HistoryItem;
import java.util.ArrayList;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "anime_history.db";
    private static final int DATABASE_VERSION = 3;
    
    private static final String TABLE_HISTORY = "watch_history";
    private static final String TABLE_FAVORITES = "favorites";
    private static final String COL_FAV_ID = "id";
    private static final String COL_FAV_TITLE = "title";
    private static final String COL_FAV_URL = "anime_url";
    private static final String COL_FAV_IMAGE = "image_url";
    private static final String COL_FAV_SOURCE = "source_name";
    private static final String COL_FAV_LAST_EP = "last_episode";
    private static final String COL_FAV_ADDED = "added_at";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_IMAGE_URL = "image_url";
    private static final String COLUMN_TITLE = "title";
    private static final String COLUMN_EPISODE = "episode";
    private static final String COLUMN_TIMESTAMP = "timestamp";
    private static final String COLUMN_ANIME_URL = "anime_url";
    private static final String COLUMN_EPISODE_URL = "episode_url";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_HISTORY_TABLE = "CREATE TABLE " + TABLE_HISTORY + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_TITLE + " TEXT,"
                + COLUMN_EPISODE + " TEXT,"
                + COLUMN_TIMESTAMP + " DATETIME DEFAULT CURRENT_TIMESTAMP,"
                + COLUMN_ANIME_URL + " TEXT,"
                + COLUMN_IMAGE_URL + " TEXT,"
                + COLUMN_EPISODE_URL + " TEXT"
                + ")";
        db.execSQL(CREATE_HISTORY_TABLE);
        db.execSQL(CREATE_FAVORITES_TABLE());
    }
    
    private String CREATE_FAVORITES_TABLE() {
        return "CREATE TABLE IF NOT EXISTS " + TABLE_FAVORITES + "("
            + COL_FAV_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COL_FAV_TITLE + " TEXT NOT NULL,"
            + COL_FAV_URL + " TEXT NOT NULL UNIQUE,"
            + COL_FAV_IMAGE + " TEXT,"
            + COL_FAV_SOURCE + " TEXT,"
            + COL_FAV_LAST_EP + " TEXT,"
            + COL_FAV_ADDED + " DATETIME DEFAULT CURRENT_TIMESTAMP"
            + ")";
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL(CREATE_FAVORITES_TABLE());
        }
        if (oldVersion < 3) {
            String newDomain = com.example.animeapp.domain.DomainConfig.isLoaded()
                ? getDomainFromSources() : null;
            if (newDomain != null && !newDomain.isEmpty()) {
                migrateDomainInternal(db, "anime-good.com", newDomain);
            }
        }
    }

    private String getDomainFromSources() {
        java.util.List<com.example.animeapp.model.Source> srcs =
            com.example.animeapp.domain.DomainConfig.getSources();
        if (srcs == null || srcs.isEmpty()) return null;
        for (com.example.animeapp.model.Source s : srcs) {
            String d = s.getDomain();
            if (d != null && !d.isEmpty()) return d;
        }
        return null;
    }

    private void migrateDomainInternal(SQLiteDatabase db, String oldDomain, String newDomain) {
        db.execSQL("UPDATE " + TABLE_FAVORITES +
            " SET " + COL_FAV_URL + " = REPLACE(" + COL_FAV_URL + ", ?, ?)",
            new Object[]{oldDomain, newDomain});
        db.execSQL("UPDATE " + TABLE_HISTORY +
            " SET " + COLUMN_ANIME_URL + " = REPLACE(" + COLUMN_ANIME_URL + ", ?, ?)," +
            "     " + COLUMN_EPISODE_URL + " = REPLACE(" + COLUMN_EPISODE_URL + ", ?, ?)",
            new Object[]{oldDomain, newDomain, oldDomain, newDomain});
        android.util.Log.d("DatabaseHelper", "migrateDomain: " + oldDomain + " -> " + newDomain);
    }

    public int migrateDomain(String oldDomain, String newDomain) {
        if (oldDomain == null || newDomain == null || oldDomain.equals(newDomain)) return 0;
        SQLiteDatabase db = this.getWritableDatabase();

        db.execSQL("UPDATE " + TABLE_FAVORITES +
            " SET " + COL_FAV_URL + " = REPLACE(" + COL_FAV_URL + ", ?, ?)",
            new Object[]{oldDomain, newDomain});
        db.execSQL("UPDATE " + TABLE_HISTORY +
            " SET " + COLUMN_ANIME_URL + " = REPLACE(" + COLUMN_ANIME_URL + ", ?, ?)," +
            "     " + COLUMN_EPISODE_URL + " = REPLACE(" + COLUMN_EPISODE_URL + ", ?, ?)",
            new Object[]{oldDomain, newDomain, oldDomain, newDomain});

        Cursor c = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_FAVORITES +
            " WHERE " + COL_FAV_URL + " LIKE ?", new String[]{"%" + newDomain + "%"});
        int count = 0;
        if (c.moveToFirst()) count = c.getInt(0);
        c.close();
        android.util.Log.d("DatabaseHelper", "migrateDomain updated=" + count);
        return count;
    }

    public void addOrUpdateHistory(String title, String episode, String animeUrl, String imageUrl, String episodeUrl) {
        SQLiteDatabase db = this.getWritableDatabase();
        
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, title);
        values.put(COLUMN_EPISODE, episode);
        values.put(COLUMN_ANIME_URL, animeUrl);
        values.put(COLUMN_IMAGE_URL, imageUrl);
        values.put(COLUMN_EPISODE_URL, episodeUrl);
        values.put(COLUMN_TIMESTAMP, getCurrentThaiTime());
        
        int rowsAffected = db.update(TABLE_HISTORY, values, 
                COLUMN_ANIME_URL + " = ?", new String[]{animeUrl});
        
        if (rowsAffected == 0) {
            db.insert(TABLE_HISTORY, null, values);
        }
        
        db.close();
    }

    public void updateHistory(String title, String episode, String animeUrl, String imageUrl, String episodeUrl) {
        SQLiteDatabase db = this.getWritableDatabase();
        
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, title);
        values.put(COLUMN_EPISODE, episode);
        values.put(COLUMN_ANIME_URL, animeUrl);
        values.put(COLUMN_IMAGE_URL, imageUrl);
        values.put(COLUMN_EPISODE_URL, episodeUrl);
        values.put(COLUMN_TIMESTAMP, getCurrentThaiTime());
        
        db.update(TABLE_HISTORY, values, 
                COLUMN_ANIME_URL + " = ?", new String[]{animeUrl});
        
        db.close();
    }
    
    private String getCurrentThaiTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        sdf.setTimeZone(TimeZone.getTimeZone("Asia/Bangkok"));
        return sdf.format(new Date());
    }

    public List<HistoryItem> getAllHistory() {
        List<HistoryItem> historyList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_HISTORY + " ORDER BY " + COLUMN_TIMESTAMP + " DESC";
        
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        
        if (cursor.moveToFirst()) {
            do {
                HistoryItem item = new HistoryItem();
                item.setId(cursor.getInt(0));
                item.setTitle(cursor.getString(1));
                item.setEpisode(cursor.getString(2));
                item.setTimestamp(cursor.getString(3));
                item.setAnimeUrl(cursor.getString(4));
                item.setImageUrl(cursor.getString(5));
                item.setEpisodeUrl(cursor.getString(6));
                
                historyList.add(item);
            } while (cursor.moveToNext());
        }
        
        cursor.close();
        db.close();
        return historyList;
    }


    public void clearHistory() {
        SQLiteDatabase db = getWritableDatabase();
        db.delete("watch_history", null, null);
        db.close();
    }

    public boolean isFavorite(String animeUrl) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.query(TABLE_FAVORITES, new String[]{COL_FAV_ID},
            COL_FAV_URL + "=?", new String[]{animeUrl}, null, null, null);
        boolean result = c.getCount() > 0;
        c.close(); db.close();
        return result;
    }

    public void addFavorite(String title, String animeUrl, String imageUrl, String sourceName, String lastEpisode) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put(COL_FAV_TITLE, title);
        v.put(COL_FAV_URL, animeUrl);
        v.put(COL_FAV_IMAGE, imageUrl);
        v.put(COL_FAV_SOURCE, sourceName);
        v.put(COL_FAV_LAST_EP, lastEpisode);
        db.insertWithOnConflict(TABLE_FAVORITES, null, v, SQLiteDatabase.CONFLICT_REPLACE);
        db.close();
    }

    public void removeFavorite(String animeUrl) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_FAVORITES, COL_FAV_URL + "=?", new String[]{animeUrl});
        db.close();
    }

    public void updateFavoriteLastEpisode(String animeUrl, String lastEpisode) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put(COL_FAV_LAST_EP, lastEpisode);
        db.update(TABLE_FAVORITES, v, COL_FAV_URL + "=?", new String[]{animeUrl});
        db.close();
    }

    public java.util.List<FavoriteItem> getAllFavorites() {
        java.util.List<FavoriteItem> list = new java.util.ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.query(TABLE_FAVORITES, null, null, null, null, null,
            COL_FAV_ADDED + " DESC");
        while (c.moveToNext()) {
            list.add(new FavoriteItem(
                c.getInt(c.getColumnIndexOrThrow(COL_FAV_ID)),
                c.getString(c.getColumnIndexOrThrow(COL_FAV_TITLE)),
                c.getString(c.getColumnIndexOrThrow(COL_FAV_URL)),
                c.getString(c.getColumnIndexOrThrow(COL_FAV_IMAGE)),
                c.getString(c.getColumnIndexOrThrow(COL_FAV_SOURCE)),
                c.getString(c.getColumnIndexOrThrow(COL_FAV_LAST_EP))
            ));
        }
        c.close(); db.close();
        return list;
    }

    public static class FavoriteItem {
        public int id;
        public String title, animeUrl, imageUrl, sourceName, lastEpisode;
        public FavoriteItem(int id, String t, String u, String img, String s, String le) {
            this.id = id; title = t; animeUrl = u; imageUrl = img; sourceName = s; lastEpisode = le;
        }
    }

    public void deleteHistory(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_HISTORY, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
    }

  
    public int migrateToNewDomain(String sourceName, String newDomain) {
        SQLiteDatabase db = this.getWritableDatabase();
        int total = 0;

      
        Cursor c = db.rawQuery(
            "SELECT id, " + COL_FAV_URL + " FROM " + TABLE_FAVORITES +
            " WHERE " + COL_FAV_SOURCE + " = ?" +
            " AND " + COL_FAV_URL + " NOT LIKE ?",
            new String[]{sourceName, "%" + newDomain + "%"});
        while (c.moveToNext()) {
            int id = c.getInt(0);
            String oldUrl = c.getString(1);
            String newUrl = oldUrl.replaceFirst("https?://[^/]+/", "https://" + newDomain + "/");
            if (!newUrl.equals(oldUrl)) {
                ContentValues cv = new ContentValues();
                cv.put(COL_FAV_URL, newUrl);
                db.update(TABLE_FAVORITES, cv, "id=?", new String[]{String.valueOf(id)});
                total++;
                android.util.Log.d("DatabaseHelper",
                    "migrateToNew [" + sourceName + "]: " + oldUrl + " -> " + newUrl);
            }
        }
        c.close();
        return total;
    }

}