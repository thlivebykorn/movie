package com.example.animeapp.parser;

import com.example.animeapp.models.Anime;
import com.example.animeapp.models.AnimeItem;
import com.example.animeapp.models.Episode;
import com.example.animeapp.models.PageItem;
import com.example.animeapp.domain.DomainConfig;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import org.jsoup.nodes.Document;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class NativeParseBridge {
    private static final Gson GSON = new Gson();
    private static final Type EPISODE_LIST = new TypeToken<ArrayList<Episode>>() {}.getType();

    static {
        System.loadLibrary("animeparser");
    }

    private NativeParseBridge() {}

    private static native String nativeParse(String sourceId, int operation, Document doc,
                                             String referer, int episodeNumber);

    private static String run(String sourceId, int operation, Document doc,
                              String referer, int episodeNumber) {
        if (doc == null) throw new IllegalArgumentException("Document must not be null");
        String result = nativeParse(sourceId, operation, doc,
                                    referer == null ? "" : referer, episodeNumber);
        return result == null ? "{}" : result;
    }

    public static Anime parseAnimeDetail(String sourceId, Document doc) {
        return GSON.fromJson(run(sourceId, 1, doc, "", 0), Anime.class);
    }

    public static List<Episode> parseEpisodes(String sourceId, Document doc, String imageUrl) {
        List<Episode> result = GSON.fromJson(run(sourceId, 2, doc, imageUrl, 0), EPISODE_LIST);
        return result == null ? Collections.emptyList() : result;
    }

    public static String parseVideoUrl(String sourceId, Document doc, String referer, int episodeNumber) {
        String nativeContext = "animemoji".equals(sourceId)
                ? DomainConfig.ApiUrl.PLAY_ANIMEMOJI() : referer;
        JsonObject result = GSON.fromJson(run(sourceId, 3, doc, nativeContext, episodeNumber), JsonObject.class);
        return result == null || !result.has("url") || result.get("url").isJsonNull()
                ? "" : result.get("url").getAsString();
    }

    public static SourceListResult parseSourceList(String sourceId, Document doc) {
        SourceListResult result = GSON.fromJson(run(sourceId, 4, doc, "", 0), SourceListResult.class);
        return result == null ? new SourceListResult() : result;
    }

    public static final class SourceListResult {
        public List<AnimeItem> animeItems = new ArrayList<>();
        public List<PageItem> pageItems = new ArrayList<>();
    }
}
