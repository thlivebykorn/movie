package com.example.animeapp.domain;

import android.content.Context;
import android.util.Log;
import com.example.animeapp.model.Category;
import com.example.animeapp.model.Source;
import com.example.animeapp.model.Strings;
import com.example.animeapp.network.ServerApiClient;
import com.example.animeapp.security.AppSecurityManager;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DomainFetcher {
    private static final String TAG = "DomainFetcher";

    private static DomainFetcher instance;
    private final ExecutorService executorService;
    private DomainLoadListener listener;
    private Context appContext;

    private static Strings strings = new Strings();

    public interface DomainLoadListener {
        void onSourcesLoaded(List<Source> sources, Strings strings);
        void onSourcesLoadFailed(String error, String code);
    }

    public DomainFetcher() {
        this.executorService = Executors.newSingleThreadExecutor();
    }

    public static synchronized DomainFetcher getInstance() {
        if (instance == null) {
            instance = new DomainFetcher();
        }
        return instance;
    }

    public void setContext(Context context) {
        this.appContext = context != null ? context.getApplicationContext() : null;
    }

    public void setListener(DomainLoadListener listener) {
        this.listener = listener;
    }

    public void fetchSources() {
        executorService.execute(() -> {
            String error = null;
            String errorCode = null;
            try {
                if (appContext == null) {
                    throw new IllegalStateException("DomainFetcher context ไม่ถูกตั้งค่า");
                }

                String raw = ServerApiClient.fetchConfigRaw(appContext);
                JSONObject data = AppSecurityManager.verifyAndExtract(raw);
                if (data == null) {
                    error = "คอนฟิกไม่ผ่านการตรวจสอบความปลอดภัย";
                } else {
                    List<Source> sources = parseSources(data);
                    if (sources != null && !sources.isEmpty()) {
                        if (listener != null) listener.onSourcesLoaded(sources, strings);
                        return;
                    }
                    error = "คอนฟิกว่างเปล่า";
                }
            } catch (ServerApiClient.ApiException e) {
                errorCode = e.code;
                error = friendlyError(e.code, e.getMessage());
            } catch (Exception e) {
                Log.e(TAG, "fetchSources error", e);
                error = "ไม่สามารถโหลดคอนฟิกจากเซิร์ฟเวอร์ได้";
            }

            if (listener != null) listener.onSourcesLoadFailed(error, errorCode);
        });
    }

    private String friendlyError(String code, String message) {
        switch (code) {
            case "PENDING":   return "บัญชีของคุณยังไม่ได้รับการอนุมัติจากแอดมิน";
            case "BANNED":    return "บัญชีของคุณถูกระงับการใช้งาน";
            case "KICKED":    return "บัญชีนี้ถูกใช้บนเครื่องอื่น";
            case "TAMPERED":  return "ตรวจพบแอปที่ถูกแก้ไข";
            case "OUTDATED":  return message;
            case "MAINTENANCE": return message;
            default:          return message != null ? message : "ไม่สามารถโหลดคอนฟิกจากเซิร์ฟเวอร์ได้";
        }
    }

    private List<Source> parseSources(JSONObject root) {
        try {
            List<Source> sources = new ArrayList<>();

            if (root.has("metadata")) {
                parseMetadata(root.getJSONObject("metadata"));
            }

            if (root.has("sources")) {
                JSONArray sourcesArray = root.getJSONArray("sources");

                for (int i = 0; i < sourcesArray.length(); i++) {
                    Source source = parseSource(sourcesArray.getJSONObject(i));
                    if (source != null) {
                        sources.add(source);
                    }
                }
            }

            return sources;

        } catch (JSONException e) {
            Log.e(TAG, "Failed to parse sources JSON", e);
            return null;
        }
    }

    private void parseMetadata(JSONObject metadata) {
        try {
            Strings newStrings = new Strings();

            if (metadata.has("source_names")) {
                JSONObject sourceNames = metadata.getJSONObject("source_names");

                if (sourceNames.has("default")) {
                    newStrings.setHome(sourceNames.getString("default"));
                }
                if (sourceNames.has("animemoji")) {
                    newStrings.setNameAnimemoji(sourceNames.getString("animemoji"));
                }
                if (sourceNames.has("fixmono")) {
                    newStrings.setNameFixmono(sourceNames.getString("fixmono"));
                }
                if (sourceNames.has("goseries4k")) {
                    newStrings.setNameGoseries4k(sourceNames.getString("goseries4k"));
                }
                if (sourceNames.has("wowdrama")) {
                    newStrings.setNameWowdrama(sourceNames.getString("wowdrama"));
                }
                if (sourceNames.has("hdd1112")) {
                    newStrings.setNameHdd1112(sourceNames.getString("hdd1112"));
                }
                if (sourceNames.has("seriesday")) {
                    newStrings.setNameSeriesday(sourceNames.getString("seriesday"));
                }
                if (sourceNames.has("movie123")) {
                    newStrings.setNameMovie123(sourceNames.getString("movie123"));
                }
                if (sourceNames.has("movie24hd")) {
                    newStrings.setNameMovie24hd(sourceNames.getString("movie24hd"));
                }
                if (sourceNames.has("doonang")) {
                    newStrings.setNameDoonang(sourceNames.getString("doonang"));
                }
                if (sourceNames.has("watchlakorn")) {
                    newStrings.setNameWatchlakorn(sourceNames.getString("watchlakorn"));
                }
                if (sourceNames.has("hdmedia")) {
                    newStrings.setNameHdmedia(sourceNames.getString("hdmedia"));
                }
            }

            if (metadata.has("api_urls")) {
                JSONObject apiUrls = metadata.getJSONObject("api_urls");

                if (apiUrls.has("get_api")) {
                    newStrings.setApi(apiUrls.getString("get_api"));
                }
                if (apiUrls.has("play_api")) {
                    newStrings.setPlayApi(apiUrls.getString("play_api"));
                }
                if (apiUrls.has("play_animemoji")) {
                    newStrings.setPlayAnimemoji(apiUrls.getString("play_animemoji"));
                }
                if (apiUrls.has("getplay_stream_api")) {
                    newStrings.setGetplayStreamApi(apiUrls.getString("getplay_stream_api"));
                }
            }

            if (metadata.has("home_paths")) {
                JSONObject homePaths = metadata.getJSONObject("home_paths");

                if (homePaths.has("animemoji")) {
                    newStrings.setHomeAnimemoji(homePaths.getString("animemoji"));
                }
                if (homePaths.has("fixmono")) {
                    newStrings.setHomeFixmono(homePaths.getString("fixmono"));
                }
                if (homePaths.has("goseries4k")) {
                    newStrings.setHomeGoseries4k(homePaths.getString("goseries4k"));
                }
                if (homePaths.has("wowdrama")) {
                    newStrings.setHomeWowdrama(homePaths.getString("wowdrama"));
                }
                if (homePaths.has("hdd1112")) {
                    newStrings.setHomeHdd1112(homePaths.getString("hdd1112"));
                }
                if (homePaths.has("seriesday")) {
                    newStrings.setHomeSeriesday(homePaths.getString("seriesday"));
                }
                if (homePaths.has("movie123")) {
                    newStrings.setHomeMovie123(homePaths.getString("movie123"));
                }
                if (homePaths.has("movie24hd")) {
                    newStrings.setHomeMovie24hd(homePaths.getString("movie24hd"));
                }
                if (homePaths.has("doonang")) {
                    newStrings.setHomeDoonang(homePaths.getString("doonang"));
                }
                if (homePaths.has("watchlakorn")) {
                    newStrings.setHomeWatchlakorn(homePaths.getString("watchlakorn"));
                }
                if (homePaths.has("hdmedia")) {
                    newStrings.setHomeHdmedia(homePaths.getString("hdmedia"));
                }
            }

            strings = newStrings;

        } catch (Exception e) {
            Log.e(TAG, "Error parsing metadata", e);
        }
    }

    private Source parseSource(JSONObject sourceObj) {
        try {
            if (!sourceObj.has("id")) {
                return null;
            }

            String id = sourceObj.getString("id");
            String name = sourceObj.getString("name");
            String domain = sourceObj.getString("domain");

            JSONArray categoriesArray = sourceObj.optJSONArray("categories");
            List<Category> categories = new ArrayList<>();

            if (categoriesArray != null) {
                for (int i = 0; i < categoriesArray.length(); i++) {
                    JSONObject categoryObj = categoriesArray.getJSONObject(i);

                    String categoryId = categoryObj.getString("id");
                    String title = categoryObj.getString("title");
                    String path = categoryObj.getString("path");

                    categories.add(new Category(categoryId, title, path));
                }
            }

            return new Source(id, name, domain, categories);

        } catch (JSONException e) {
            Log.e(TAG, "Error parsing source", e);
            return null;
        }
    }

    public static Strings getStrings() {
        return strings;
    }
}
