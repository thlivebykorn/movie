package com.example.animeapp.activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;

import com.example.animeapp.databinding.ActivityAnimeDetailBinding;
import com.example.animeapp.R;
import com.example.animeapp.adapters.EpisodeAdapter;
import com.example.animeapp.managers.AnimeDataManager;
import com.example.animeapp.models.AnimeItem;
import com.example.animeapp.models.Episode;
import com.example.animeapp.network.AnimeApiClient;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.example.animeapp.database.DatabaseHelper;
import android.view.animation.OvershootInterpolator;

public class AnimeDetailActivity extends AppCompatActivity implements AnimeDataManager.DataLoadListener {

    private ActivityAnimeDetailBinding binding;
    private String animeUrl;
    private List<Episode> episodes = new ArrayList<>();
    private EpisodeAdapter episodeAdapter;
    private int currentEpisodeIndex = -1;
    private boolean isTelevision;
    private AnimeDataManager animeDataManager;
    private AnimeItem currentAnime;
    private DatabaseHelper dbHelper;
    private boolean isFavorite = false;
    private android.view.MenuItem favoriteMenuItem;
    private String scrollToEpisode = null;  

    public static void start(Context context, String url, String title) {
        Intent intent = new Intent(context, AnimeDetailActivity.class);
        intent.putExtra("anime_url", url);
        intent.putExtra("anime_title", title);
        context.startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

       
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);

        setupWindow();
        setupBinding();
        setupWindowInsets();
        dbHelper = new DatabaseHelper(this);
        setupToolbar();
        setupHelpers();
        setupRecyclerView();
        loadAnimeData();
        
        isTelevision = getPackageManager().hasSystemFeature(PackageManager.FEATURE_LEANBACK);
       
        scrollToEpisode = getIntent().getStringExtra("scroll_to_episode");
    }

    @Override
    public void onDataLoadFailed(String errorMessage) {
        runOnUiThread(() -> {
            Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show();
            hideProgress();
        });
    }

    private void setupWindow() {
       
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            WindowManager.LayoutParams layoutParams = getWindow().getAttributes();
            layoutParams.layoutInDisplayCutoutMode = 
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(layoutParams);
        }
    }

    private void setupBinding() {
        binding = ActivityAnimeDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
    }

    private void setupWindowInsets() {
        View rootView = binding.getRoot();
        
        ViewCompat.setOnApplyWindowInsetsListener(rootView, (v, windowInsets) -> {
            Insets insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());

           
            if (binding.toolbar != null) {
                binding.toolbar.setPadding(
                    0,
                    insets.top,  
                    0,
                    0
                );
            }

           
            if (binding.episodesRecyclerView != null) {
                binding.episodesRecyclerView.setPadding(
                    binding.episodesRecyclerView.getPaddingLeft(),
                    binding.episodesRecyclerView.getPaddingTop(),
                    binding.episodesRecyclerView.getPaddingRight(),
                    insets.bottom
                );
                binding.episodesRecyclerView.setClipToPadding(false);
            }
            
            return WindowInsetsCompat.CONSUMED;
        });
    }

    private void setupToolbar() {
        Toolbar toolbar = binding.toolbar;
        toolbar.setTitleTextColor(Color.WHITE);
        setSupportActionBar(toolbar);
        toolbar.post(this::setupToolbarFocusTargets);
        
        String title = getIntent().getStringExtra("anime_title");
        String filteredTitle = filterThaiAndNumbers(title);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(filteredTitle);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    private void setupToolbarFocusTargets() {
        Toolbar toolbar = binding.toolbar;
        if (toolbar == null) return;

        for (int i = 0; i < toolbar.getChildCount(); i++) {
            View child = toolbar.getChildAt(i);
            if (child instanceof android.widget.ImageButton
                    || child instanceof androidx.appcompat.view.menu.ActionMenuItemView) {
                makeToolbarButtonTvFocusable(child);
            }
        }
    }

    private void makeToolbarButtonTvFocusable(View view) {
        view.setFocusable(true);
        view.setFocusableInTouchMode(false);
        view.setClickable(true);
        view.setBackgroundResource(R.drawable.focus_background);
        int pad = dp(8);
        view.setPadding(pad, pad, pad, pad);
    }

    private void setupHelpers() {
        animeUrl = getIntent().getStringExtra("anime_url");
        
        animeDataManager = new AnimeDataManager(
            this, 
            binding.progressText, 
            binding.progressBar, 
            binding.progressContainer
        );
    }

    private void setupRecyclerView() {
        episodeAdapter = new EpisodeAdapter(episodes, this::onEpisodeClick);

        int itemWidth = (int) (180 * getResources().getDisplayMetrics().density);
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int spanCount = Math.max(1, screenWidth / itemWidth);

        binding.episodesRecyclerView.setLayoutManager(new GridLayoutManager(this, spanCount));
        binding.episodesRecyclerView.setAdapter(episodeAdapter);
        binding.episodesRecyclerView.post(() -> binding.episodesRecyclerView.requestFocus());
    }

    private void loadAnimeData() {
        animeDataManager.loadAnimeData(animeUrl, this);
    }

    private java.util.concurrent.ExecutorService episodeExecutor =
        java.util.concurrent.Executors.newSingleThreadExecutor();

    private void onEpisodeClick(Episode episode) {
        currentEpisodeIndex = episodes.indexOf(episode);

        com.example.animeapp.dialogs.CustomLoadingDialog loadingDialog = 
            new com.example.animeapp.dialogs.CustomLoadingDialog(this);
        loadingDialog.setMessage("กำลังโหลดลิงก์วิดีโอ...");
        loadingDialog.show();

        episodeExecutor.execute(() -> {
            try {
                Log.d("EpisodeClick", "เริ่มดึงลิงก์วิดีโอจาก: " + episode.getInfoUrl());

                String videoUrl = AnimeApiClient.fetchVideoUrl(
                    episode.getInfoUrl(),
                    episode.getReferer(),
                    episode.getEpisodeNumber()
                );

                Log.d("EpisodeClick", "videoUrl: " + videoUrl);

                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    if (loadingDialog.isShowing()) loadingDialog.dismiss();
                    if (videoUrl != null && !videoUrl.isEmpty()) {
                        episode.setVideoUrl(videoUrl);
                        Log.d("EpisodeClick", "กำลังเริ่ม VideoPlayerActivity ด้วยลิงก์: " + videoUrl);
                        VideoPlayerActivity.start(this, episodes, currentEpisodeIndex, getTitle().toString(), animeUrl);
                    } else {
                        Log.e("EpisodeClick", "ลิงก์วิดีโอเป็น null หรือว่าง");
                        Toast.makeText(this, "ไม่พบลิงก์วิดีโอ", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                Log.e("EpisodeClick", "เกิดข้อผิดพลาดในการโหลดลิงก์วิดีโอ", e);
                String errMessage = e.getMessage();
                if (errMessage == null || errMessage.isEmpty()) errMessage = "ไม่สามารถโหลดลิงก์วิดีโอ";
                String toastMessage = errMessage;
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    if (loadingDialog.isShowing()) loadingDialog.dismiss();
                    Toast.makeText(this, toastMessage, Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    @Override
    public void onTitleLoaded(String title) {
        setTitle(title);
    }

    @Override
    public void onEpisodesLoaded(List<Episode> episodes) {
      
        android.content.SharedPreferences prefs =
            getSharedPreferences("AnimeAppPrefs", MODE_PRIVATE);
        boolean sortDesc = prefs.getBoolean("episode_sort_desc", false);
        List<Episode> sorted = new ArrayList<>(episodes);
        if (sortDesc) Collections.reverse(sorted);

        this.episodes = sorted;
        episodeAdapter.updateEpisodes(sorted);

        if (scrollToEpisode != null && !scrollToEpisode.isEmpty()) {
            scrollToEpisodeName(scrollToEpisode);
            scrollToEpisode = null;
        }
    }
    
    private void scrollToEpisodeName(String episodeName) {
        for (int i = 0; i < episodes.size(); i++) {
            if (episodes.get(i).getTitle().equals(episodeName)) {
                final int pos = i;
                binding.episodesRecyclerView.post(() -> {
                    binding.episodesRecyclerView.smoothScrollToPosition(pos);
                  
                    android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());
                    handler.postDelayed(() -> {
                        android.view.View v = binding.episodesRecyclerView
                            .getLayoutManager().findViewByPosition(pos);
                        if (v != null) {
                            v.animate().scaleX(1.05f).scaleY(1.05f).setDuration(200)
                                .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f)
                                    .setDuration(200).start()).start();
                            v.requestFocus();
                        }
                    }, 400);
                });
                break;
            }
        }
    }

    public static String filterThaiAndNumbers(String input) {
        boolean hasThai = input.matches(".*[ก-๙].*");
        if (hasThai) {
            return input.replaceAll("[^ก-๙0-9\\s]", "").trim();
        } else {
            return input.replaceAll("[^a-zA-Z0-9\\s]", "").trim();
        }
    }

    private void hideProgress() {
        binding.progressContainer.setVisibility(View.GONE);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        episodeExecutor.shutdownNow();
        if (dbHelper != null) dbHelper.close();
    }

    @Override
    public boolean onSupportNavigateUp() {
        getOnBackPressedDispatcher().onBackPressed();
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.anime_detail_menu, menu);
        favoriteMenuItem = menu.findItem(R.id.action_favorite);
        updateFavoriteIcon();
        binding.toolbar.post(() -> {
            View favoriteActionView = findViewById(R.id.action_favorite);
            if (favoriteActionView != null) makeToolbarButtonTvFocusable(favoriteActionView);
            View refreshActionView = findViewById(R.id.action_refresh);
            if (refreshActionView != null) makeToolbarButtonTvFocusable(refreshActionView);
            setupToolbarFocusTargets();
        });
        return true;
    }
    
    private void updateFavoriteIcon() {
        if (favoriteMenuItem == null || animeUrl == null) return;
        isFavorite = dbHelper.isFavorite(animeUrl);
        favoriteMenuItem.setIcon(isFavorite
            ? android.R.drawable.btn_star_big_on
            : android.R.drawable.btn_star_big_off);
        favoriteMenuItem.setTitle(isFavorite ? "ลบออกจากรายการโปรด" : "เพิ่มรายการโปรด");
    }
    
    private void toggleFavorite() {
        if (animeUrl == null) return;
        if (isFavorite) {
            dbHelper.removeFavorite(animeUrl);
            isFavorite = false;
            android.widget.Toast.makeText(this, "ลบออกจากรายการโปรดแล้ว", android.widget.Toast.LENGTH_SHORT).show();
        } else {
           
            String title = getIntent().getStringExtra("anime_title");
            if (title == null && binding.toolbar != null) title = String.valueOf(binding.toolbar.getTitle());
            String imageUrl = currentAnime != null ? currentAnime.getImageUrl() : "";
            String sourceName = detectSourceName(animeUrl);
            String lastEp = episodes.isEmpty() ? "" : episodes.get(episodes.size()-1).getTitle();
            dbHelper.addFavorite(title != null ? title : "", animeUrl, imageUrl, sourceName, lastEp);
            isFavorite = true;
            android.widget.Toast.makeText(this, "⭐ เพิ่มในรายการโปรดแล้ว", android.widget.Toast.LENGTH_SHORT).show();
           
            if (favoriteMenuItem != null) {
                android.view.View icon = findViewById(R.id.action_favorite);
                if (icon != null) {
                    icon.animate().scaleX(1.4f).scaleY(1.4f).setDuration(150)
                        .withEndAction(() -> icon.animate().scaleX(1f).scaleY(1f).setDuration(150).start()).start();
                }
            }
        }
        updateFavoriteIcon();
    }
    
    private String detectSourceName(String url) {
        if (url == null) return "unknown";
        try {
            java.net.URI uri = new java.net.URI(url);
            String host = uri.getHost() != null ? uri.getHost().toLowerCase() : "";
            if (host.startsWith("www.")) host = host.substring(4);
            for (com.example.animeapp.model.Source s : com.example.animeapp.domain.DomainConfig.getSources()) {
                String d = s.getDomain().toLowerCase().replace("www.", "");
                if (host.equals(d)) return s.getId();
            }
        } catch (Exception ignored) {}
        return "unknown";
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_refresh) {
            animeDataManager.refreshAnimeData(animeUrl, this);
            return true;
        }
        if (item.getItemId() == R.id.action_favorite) {
            toggleFavorite();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
