package com.example.animeapp.sources;

import com.example.animeapp.models.AnimeItem;
import com.example.animeapp.models.PageItem;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import com.example.animeapp.network.OkHttpClientFactory;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import com.example.animeapp.domain.DomainConfig;

public class GoSeriesSource implements AnimeSource {

    private static final String TAG = "GoSeriesSource";
    private final ExecutorService executorService;
    private final OkHttpClient client;

    public GoSeriesSource() {
        this.executorService = Executors.newSingleThreadExecutor();
        this.client = OkHttpClientFactory.getClientWithDoH();
    }

    @Override
    public String getSourceName() {
        return DomainConfig.SourceName.GOSERIES4K();
    }

    @Override
    public String getBaseUrl() {
        return "https://" + DomainConfig.BaseUrl.GOSERIES4K() + DomainConfig.HomePage.GOSERIES4K();
    }

    @Override
    public String getSearchUrl(String keyword) {
        return "https://" + DomainConfig.BaseUrl.GOSERIES4K() + "/?s=" + keyword;
    }

    @Override
    public void fetchAnimeList(String pageUrl, AnimeLoadCallback callback) {
        executorService.execute(() -> {
            try {
                
                
                
                Request request = new Request.Builder()
                    .url(pageUrl)
                    .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                    .build();

                Response response = client.newCall(request).execute();
                
                if (response.isSuccessful()) {
                    String html = response.body().string();
                    Document doc = Jsoup.parse(html, pageUrl);
                    
                    com.example.animeapp.parser.NativeParseBridge.SourceListResult nativeResult = com.example.animeapp.parser.NativeParseBridge.parseSourceList("goseries4k", doc);
                    
                    List<AnimeItem> animeItems = nativeResult.animeItems;
                    
                    List<PageItem> pageItems = nativeResult.pageItems;
                    
                    
                    callback.onSuccess(animeItems, pageItems);
                } else {
                    
                    callback.onFailure("โหลดหน้าไม่สำเร็จ (HTTP " + response.code() + ")");
                }
                
                response.close();
                
            } catch (IOException e) {
                
                callback.onFailure("เกิดข้อผิดพลาดในการเชื่อมต่อ: " + e.getMessage());
            } catch (Exception e) {
                
                callback.onFailure("เกิดข้อผิดพลาด: " + e.getMessage());
            }
        });
    }

    private List<AnimeItem> parseAnimeItems(Document doc) {
        return com.example.animeapp.parser.NativeParseBridge.parseSourceList("goseries4k", doc).animeItems;
    }


    private List<PageItem> parsePageItems(Document doc) {
        return com.example.animeapp.parser.NativeParseBridge.parseSourceList("goseries4k", doc).pageItems;
    }

    private boolean isNumeric(String s) {
        try { Integer.parseInt(s); return true; } catch (NumberFormatException e) { return false; }
    }
}