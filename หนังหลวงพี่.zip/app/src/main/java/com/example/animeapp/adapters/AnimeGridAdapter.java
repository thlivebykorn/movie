package com.example.animeapp.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.example.animeapp.R;
import com.example.animeapp.models.AnimeItem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AnimeGridAdapter extends RecyclerView.Adapter<AnimeGridAdapter.ViewHolder> {

    private List<AnimeItem> animeItems = new ArrayList<>();
    private OnAnimeClickListener listener;
    private Map<String, String> favoritesMap = new HashMap<>();
    private boolean showEpNum = true;

    private static final RequestOptions GLIDE_OPTIONS = new RequestOptions()
        .placeholder(R.drawable.warning)
        .error(R.drawable.warning)
        .diskCacheStrategy(DiskCacheStrategy.ALL)
        .override(300, 420)
        .centerCrop();

    public interface OnAnimeClickListener {
        void onAnimeClick(AnimeItem animeItem);
    }

    public AnimeGridAdapter(List<AnimeItem> animeItems, OnAnimeClickListener listener) {
        this.animeItems = new ArrayList<>(animeItems);
        this.listener   = listener;
        setHasStableIds(true);
    }

    public void setFavoritesMap(Map<String, String> favoritesMap) {
        this.favoritesMap = favoritesMap != null ? favoritesMap : new HashMap<>();
        notifyDataSetChanged();
    }

    public void setShowEpisodeNumber(boolean show) {
        this.showEpNum = show;
        notifyDataSetChanged();
    }

    @Override
    public long getItemId(int position) {
        return animeItems.get(position).getUrl().hashCode();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.item_anime_grid, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AnimeItem item = animeItems.get(position);
        holder.title.setText(item.getTitle());

        Glide.with(holder.itemView.getContext())
            .load(item.getImageUrl())
            .apply(GLIDE_OPTIONS)
            .into(holder.image);

       
        if (item.getDubText() != null && !item.getDubText().isEmpty()) {
            holder.dubTextView.setVisibility(View.VISIBLE);
            holder.dubTextView.setText(item.getDubText());
        } else {
            holder.dubTextView.setVisibility(View.GONE);
        }

        if (!showEpNum) {
            holder.latestEpText.setVisibility(View.GONE);
        } else {
            String ep = item.getLatestEpisode();
            if ((ep == null || ep.isEmpty()) && favoritesMap.containsKey(item.getUrl())) {
                ep = favoritesMap.get(item.getUrl());
            }

            if (ep != null && !ep.isEmpty()) {
                holder.latestEpText.setVisibility(View.VISIBLE);
                holder.latestEpText.setText(ep);
            } else {
                holder.latestEpText.setVisibility(View.GONE);
            }
        }

        holder.itemView.setOnClickListener(v -> listener.onAnimeClick(item));
        holder.itemView.setOnFocusChangeListener((v, hasFocus) -> {
            v.animate().scaleX(hasFocus ? 1.05f : 1f)
                       .scaleY(hasFocus ? 1.05f : 1f)
                       .setDuration(150).start();

        });
    }

    @Override
    public void onViewRecycled(@NonNull ViewHolder holder) {
        super.onViewRecycled(holder);
        Glide.with(holder.itemView.getContext()).clear(holder.image);
    }

    @Override
    public int getItemCount() { return animeItems.size(); }

    public void updateItems(List<AnimeItem> newItems) {
        List<AnimeItem> oldItems = this.animeItems;
        List<AnimeItem> safeNew  = newItems != null ? newItems : new ArrayList<>();

        DiffUtil.DiffResult diff = DiffUtil.calculateDiff(new DiffUtil.Callback() {
            @Override public int getOldListSize() { return oldItems.size(); }
            @Override public int getNewListSize() { return safeNew.size(); }

            @Override
            public boolean areItemsTheSame(int oldPos, int newPos) {
                return oldItems.get(oldPos).getUrl().equals(safeNew.get(newPos).getUrl());
            }

            @Override
            public boolean areContentsTheSame(int oldPos, int newPos) {
                AnimeItem o = oldItems.get(oldPos);
                AnimeItem n = safeNew.get(newPos);
                return o.getTitle().equals(n.getTitle())
                    && o.getImageUrl().equals(n.getImageUrl());
            }
        });

        this.animeItems = new ArrayList<>(safeNew);
        diff.dispatchUpdatesTo(this);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView image;
        public TextView  title, dubTextView, latestEpText;

        public ViewHolder(View view) {
            super(view);
            image        = view.findViewById(R.id.anime_image);
            title        = view.findViewById(R.id.anime_title);
            dubTextView  = view.findViewById(R.id.dub_text);
            latestEpText = view.findViewById(R.id.latest_episode_text);
        }
    }
}
