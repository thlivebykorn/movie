package com.example.animeapp.models;

public class PageItem {
    private String  pageNumber;
    private String  url;
    private boolean isCurrent;   

    public PageItem(String pageNumber, String url) {
        this(pageNumber, url, false);
    }

    public PageItem(String pageNumber, String url, boolean isCurrent) {
        this.pageNumber = pageNumber;
        this.url        = url;
        this.isCurrent  = isCurrent;
    }

    public String  getPageNumber() { return pageNumber; }
    public String  getUrl()        { return url; }
    public boolean isCurrent()     { return isCurrent; }
}
