package com.example.animeapp.sources;

import android.util.Base64;
import android.util.Log;
import com.example.animeapp.domain.DomainConfig;
import com.example.animeapp.models.AnimeItem;
import com.example.animeapp.models.PageItem;
import com.example.animeapp.network.OkHttpClientFactory;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class HdMediaSource implements AnimeSource {

    private static final String TAG = "HdMediaSource";
    private static final String FALLBACK_DOMAIN = "www.24hd.media";
    private static final String UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36";
    private static final String REST_PREFIX = "/wp-json/wp/v2/posts?";
    private static final int REST_PAGE_SIZE = 20;
    private static final int REST_MAX_PAGES = 100;
    private static final Pattern CSS_IMAGE = Pattern.compile(
            "background-image\\s*:\\s*url\\([\"']?([^\"')]+)[\"']?\\)");
    private static final Pattern PAGE_PATTERN = Pattern.compile("/page/(\\d+)/");

    private final OkHttpClient client;

    public HdMediaSource() {
        this.client = OkHttpClientFactory.getClientWithDoH();
    }

    private String getDomain() {
        String domain = DomainConfig.BaseUrl.HDMEDIA();
        if (domain == null || domain.isEmpty()) return FALLBACK_DOMAIN;
        return domain;
    }

    private String baseUrl() {
        return "https://" + getDomain();
    }

    @Override
    public String getSourceName() {
        return DomainConfig.SourceName.HDMEDIA();
    }

    @Override
    public String getBaseUrl() {
        return baseUrl();
    }

    @Override
    public String getSearchUrl(String keyword) {
        try {
            return baseUrl() + "/?s=" + URLEncoder.encode(keyword, "UTF-8");
        } catch (Exception e) {
            return baseUrl() + "/?s=" + keyword;
        }
    }

    @Override
    public void fetchAnimeList(String pageUrl, AnimeLoadCallback callback) {
        new Thread(() -> {
            try {
                if (isRestEligible(pageUrl)) {
                    fetchRestList(pageUrl, callback);
                } else {
                    fetchHtmlList(pageUrl, callback);
                }
            } catch (Exception e) {
                Log.e(TAG, "Error fetching list: " + e.getMessage(), e);
                callback.onFailure("เกิดข้อผิดพลาด: " + e.getMessage());
            }
        }).start();
    }

    private void fetchHtmlList(String pageUrl, AnimeLoadCallback callback) throws Exception {
        Log.d(TAG, "Fetching list from: " + pageUrl);

        Request request = new Request.Builder()
            .url(pageUrl)
            .header("User-Agent", UA)
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .header("Accept-Language", "th-TH,th;q=0.9,en-US;q=0.8")
            .header("Referer", baseUrl() + "/")
            .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                callback.onFailure("HTTP error: " + response.code());
                return;
            }

            String html = response.body().string();
            if (html.length() < 100) {
                callback.onFailure("ได้รับข้อมูลน้อยเกินไป");
                return;
            }

            Document doc = Jsoup.parse(html, pageUrl);
            com.example.animeapp.parser.NativeParseBridge.SourceListResult nativeResult = com.example.animeapp.parser.NativeParseBridge.parseSourceList("hdmedia", doc);
            List<AnimeItem> items = nativeResult.animeItems;
            List<PageItem> pages = nativeResult.pageItems;

            callback.onSuccess(items, pages);
        }
    }

   

    private boolean isRestEligible(String pageUrl) {
        if (pageUrl == null) return false;
        if (pageUrl.contains(REST_PREFIX)) return true;
        String abs = pageUrl.startsWith("http") ? pageUrl : baseUrl() + pageUrl;
        if (abs.equals(baseUrl()) || abs.equals(baseUrl() + "/")) return true;
        return abs.contains("/category/") || abs.contains("?s=");
    }

    private void fetchRestList(String pageUrl, AnimeLoadCallback callback) throws Exception {
        String restUrl = toRestUrl(pageUrl);
        if (restUrl == null || restUrl.isEmpty()) {
            fetchHtmlList(pageUrl, callback);
            return;
        }

        Log.d(TAG, "Fetching rest list from: " + restUrl);
        Request request = new Request.Builder()
            .url(restUrl)
            .header("User-Agent", UA)
            .header("Accept", "application/json")
            .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
               
                fetchHtmlList(pageUrl, callback);
                return;
            }

            String body = response.body().string();
            List<AnimeItem> items = parseRestItems(new JSONArray(body));

            int totalPages = 0;
            String tp = response.header("X-WP-TotalPages");
            if (tp != null) {
                try {
                    totalPages = Integer.parseInt(tp.trim());
                } catch (NumberFormatException ignored) {}
            }
            List<PageItem> pages = buildRestPages(restUrl, Math.min(totalPages, REST_MAX_PAGES));

            callback.onSuccess(items, pages);
        } catch (org.json.JSONException e) {
            Log.e(TAG, "REST json error: " + e.getMessage());
            callback.onFailure("ข้อมูลผิดปกติ: " + e.getMessage());
        }
    }

    private String toRestUrl(String pageUrl) throws IOException {
        String abs = pageUrl.startsWith("http") ? pageUrl : baseUrl() + pageUrl;
        if (abs.contains(REST_PREFIX)) return abs;

        if (abs.equals(baseUrl()) || abs.equals(baseUrl() + "/")) {
            return restQuery("");
        }

        Matcher cm = Pattern.compile("/category/([^/]+)/?(?:page/(\\d+)/?)?$").matcher(abs);
        if (cm.find()) {
            int catId = lookupCategoryId(cm.group(1));
            if (catId <= 0) return null;
            String rest = restQuery("categories=" + catId);
            if (cm.group(2) != null) rest += "&page=" + cm.group(2);
            return rest;
        }

        if (abs.contains("?s=")) {
            String kw = abs.substring(abs.indexOf("?s=") + 3);
            return restQuery("search=" + kw);
        }

        return null;
    }

    private String restQuery(String params) {
        StringBuilder sb = new StringBuilder(baseUrl()).append(REST_PREFIX);
        if (params != null && !params.isEmpty()) sb.append(params).append("&");
        return sb.append("per_page=").append(REST_PAGE_SIZE).append("&_embed").toString();
    }

    private int lookupCategoryId(String slug) throws IOException {
        String url = baseUrl() + "/wp-json/wp/v2/categories?slug=" + slug + "&_fields=id,name";
        Request req = new Request.Builder()
            .url(url)
            .header("User-Agent", UA)
            .header("Accept", "application/json")
            .build();
        try (Response resp = client.newCall(req).execute()) {
            if (!resp.isSuccessful()) return 0;
            JSONArray arr = new JSONArray(resp.body().string());
            if (arr.length() > 0) return arr.getJSONObject(0).optInt("id", 0);
        } catch (org.json.JSONException e) {
            Log.w(TAG, "Category lookup failed: " + e.getMessage());
        }
        return 0;
    }

    private List<AnimeItem> parseRestItems(JSONArray arr) {
        List<AnimeItem> items = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            try {
                JSONObject obj = arr.getJSONObject(i);
                String title = obj.optJSONObject("title") != null
                        ? obj.optJSONObject("title").optString("rendered", "") : "";
                String url = obj.optString("link", "");
                String image = restImage(obj);
                if (!title.isEmpty() && !url.isEmpty()) {
                    items.add(new AnimeItem(title, url, image, ""));
                }
            } catch (Exception e) {
                Log.e(TAG, "Parse rest item error: " + e.getMessage());
            }
        }
        return items;
    }

    private String restImage(JSONObject obj) {
        try {
            JSONObject emb = obj.optJSONObject("_embedded");
            if (emb == null) return "";
            JSONArray fm = emb.optJSONArray("wp:featuredmedia");
            if (fm == null || fm.length() == 0) return "";
            JSONObject media = fm.optJSONObject(0);
            if (media == null) return "";
            String src = media.optString("source_url", "");
            if (src.isEmpty()) {
                JSONObject sizes = media.optJSONObject("media_details") != null
                        ? media.optJSONObject("media_details").optJSONObject("sizes") : null;
                if (sizes != null) {
                    JSONObject medium = sizes.optJSONObject("medium");
                    if (medium != null) src = medium.optString("source_url", "");
                }
            }
            return src;
        } catch (Exception e) {
            return "";
        }
    }

    private List<PageItem> buildRestPages(String restUrl, int totalPages) {
        List<PageItem> pages = new ArrayList<>();
        if (totalPages < 2) return pages;

        int current = 1;
        Matcher m = Pattern.compile("[?&]page=(\\d+)").matcher(restUrl);
        if (m.find()) {
            try {
                current = Integer.parseInt(m.group(1));
            } catch (NumberFormatException ignored) {}
        }
        String base = restUrl.replaceAll("[?&]page=\\d+", "");
        for (int p = 1; p <= totalPages; p++) {
            String url = (p == 1) ? base : base + (base.contains("?") ? "&" : "?") + "page=" + p;
            pages.add(new PageItem(String.valueOf(p), url, p == current));
        }
        return pages;
    }

    private List<AnimeItem> parseAnimeItems(Document doc) {
        return com.example.animeapp.parser.NativeParseBridge.parseSourceList("hdmedia", doc).animeItems;
    }

    private String extractCardImage(Element card) {
        try {
            Element cssEl = card.selectFirst("[data-vip24hd-css]");
            if (cssEl != null) {
                String css = new String(
                    Base64.decode(cssEl.attr("data-vip24hd-css"), Base64.DEFAULT), "UTF-8");
                Matcher m = CSS_IMAGE.matcher(css);
                if (m.find()) {
                    String img = m.group(1).trim();
                    if (img.startsWith("//")) img = "https:" + img;
                    return img;
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "Card image decode failed: " + e.getMessage());
        }
        return "";
    }

    private List<PageItem> parsePageItems(Document doc, String pageUrl) {
        return com.example.animeapp.parser.NativeParseBridge.parseSourceList("hdmedia", doc).pageItems;
    }
}