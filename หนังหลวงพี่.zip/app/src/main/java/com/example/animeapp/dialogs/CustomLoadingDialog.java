package com.example.animeapp.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.animeapp.R;

public class CustomLoadingDialog {

    private final Dialog    dialog;
    private       TextView  messageText;
    private       ImageView loadingIcon;
    private       Animation rotateAnim;
    private       Animation pulseAnim;
    private       com.facebook.shimmer.ShimmerFrameLayout shimmerView;

    public CustomLoadingDialog(Context context) {
        dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        View view = LayoutInflater.from(context).inflate(R.layout.dialog_custom_loading, null);
        dialog.setContentView(view);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
           
            dialog.getWindow().setWindowAnimations(android.R.style.Animation_Dialog);
        }

        messageText = view.findViewById(R.id.loading_message);
        loadingIcon = view.findViewById(R.id.loading_icon);
        shimmerView = view.findViewById(R.id.shimmer_view);
        dialog.setCancelable(false);

       
        rotateAnim = new RotateAnimation(
            0, 360,
            Animation.RELATIVE_TO_SELF, 0.5f,
            Animation.RELATIVE_TO_SELF, 0.5f
        );
        rotateAnim.setDuration(1200);
        rotateAnim.setRepeatCount(Animation.INFINITE);
        rotateAnim.setInterpolator(new LinearInterpolator());

       
        pulseAnim = new android.view.animation.ScaleAnimation(
            1.0f, 1.15f, 1.0f, 1.15f,
            Animation.RELATIVE_TO_SELF, 0.5f,
            Animation.RELATIVE_TO_SELF, 0.5f
        );
        pulseAnim.setDuration(800);
        pulseAnim.setRepeatMode(Animation.REVERSE);
        pulseAnim.setRepeatCount(Animation.INFINITE);
        pulseAnim.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
    }

    public void setMessage(String message) {
        if (messageText != null) messageText.setText(message);
    }

    public void show() {
        if (dialog != null && !dialog.isShowing()) {
            dialog.show();
          
            if (shimmerView != null) shimmerView.startShimmer();
            
            if (loadingIcon != null) {
                android.view.animation.AnimationSet animSet = new android.view.animation.AnimationSet(false);
                animSet.addAnimation(rotateAnim);
                animSet.addAnimation(pulseAnim);
                loadingIcon.startAnimation(animSet);
            }
        }
    }

    public void dismiss() {
        if (dialog != null && dialog.isShowing()) {
            if (shimmerView != null) shimmerView.stopShimmer();
            if (loadingIcon != null) loadingIcon.clearAnimation();
            try { dialog.dismiss(); } catch (Exception ignored) {}
        }
    }

    public boolean isShowing() {
        return dialog != null && dialog.isShowing();
    }
}
